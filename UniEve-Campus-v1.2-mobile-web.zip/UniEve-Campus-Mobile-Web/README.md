# UniEve Campus V1.2 PWA

Built static preview. Serve at an HTTPS origin for phone installation; connected accounts need the combined source backend under the same origin. This is not an APK. Private university access remains unverified.
