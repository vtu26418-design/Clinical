$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
foreach ($reportTool in @('pdflatex', 'bibtex')) {
    if (-not (Get-Command $reportTool -ErrorAction SilentlyContinue)) {
        throw "Install MiKTeX or TeX Live with $reportTool, or upload this ZIP to Overleaf."
    }
}
& pdflatex -interaction=nonstopmode -halt-on-error -file-line-error main.tex
if ($LASTEXITCODE -ne 0) { throw 'Initial LaTeX pass failed. See main.log.' }
& bibtex main
if ($LASTEXITCODE -ne 0) { throw 'IEEE bibliography generation failed. See main.blg.' }
for ($reportPass = 1; $reportPass -le 2; $reportPass++) {
    & pdflatex -interaction=nonstopmode -halt-on-error -file-line-error main.tex
    if ($LASTEXITCODE -ne 0) { throw "LaTeX pass $reportPass failed. See main.log." }
}
Write-Host 'Report ready: main.pdf. Personal details are in project-info.tex.'
