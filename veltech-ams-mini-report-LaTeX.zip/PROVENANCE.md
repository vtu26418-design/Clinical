# Content and formatting provenance

## User-supplied material

- `veltech_ams_mini_report_LaTeX.zip`: authoritative project content, project title, three student entries, guide details, source excerpt, diagrams, screenshots and bibliography.
- `web_report2 rupa.pdf`: faculty presentation reference. Its college front-matter sequence, centred chapter headings, A4 layout, Times-family text, nine-chapter structure and Chapter 3 figure-and-explanation layout inform the report. The shared university seal is extracted from its cover with the original PDF transparency mask. Its E-Payment project facts, student details, project screenshots and test claims are not copied.

The uploaded archive's project title **Smart College Management Platform** is retained, with **veltech-ams-mini** identified as the implementation. Student/guide values are retained from the latest uploaded archive. The submission month `10, 2026` is formatted as `October, 2026`. No project release number is added.

## Project figures

- `veltech-seal.png`: shared university seal extracted from the reference cover image and its PDF soft mask. This preserves the original transparency and reproduces the institution's round emblem. The extraction does not copy a faculty project screenshot.
- `architecture.tex` and `data-flow.tex`: original project TikZ diagrams supplied in the archive, describing the project's own services. `sitemap.tex` is a new editable diagram of this project's navigation.
- `home-desktop.png`: project screenshot supplied in the archive, using fictional preview records.
- `events-discovery-mobile.png` and `community-mobile.png`: actual combined-application preview screenshots with fictional records, retained from the previous report preparation.
- `login-desktop.png` and `launch-events.png`: actual local application screenshots from the preceding mobile/admin UI update. Login fields are blank.
- `form-validation.png`, `event-registration.png` and `subject-routing.png`: fresh captures of the actual local React preview. The validation illustration records its real whitespace-name error. Registration and subject navigation use fictional demonstration records. The capture check records zero page errors and zero private API requests; remote network requests were blocked or served from the project's own local assets.
- `results-overall.png`: captured from the same application using a labelled fictional two-semester demonstration: 44 credit points / 6 credits, then 84 / 10 cumulatively. The CGPA of 8.40 gives 79% using the user's requested conversion. No original screenshot pixels were retouched.

`code/node-server.js` is an explicitly shortened excerpt from the current Express service. `code/services.yaml` contains selected keys from the actual Compose configuration, not a standalone deployment file. `code/deployment-log.txt` contains recorded output from the preceding successful Docker build and local Mailpit SMTP test, not a new Internet-delivery claim. `code/security.js` is retained from the supplied project source; Chapter 8 shows selected complete helper functions.

The faculty reference PDF and unrelated screenshots are excluded from the deliverable. Project figures and tables have no fixed five-item limit. The compiled report has 32 physical pages, 16 numbered figures (12 in Chapter 3) and 3 tables. Chapter 3 matches the sample's physical pages 14–25 and printed pages 4–15. Its subsection topics are adapted to the project's implemented stack rather than claiming Angular/MySQL features.

## Evidence boundary

The 607-test record, historical AMS account observations and local synthetic benchmark are retained from the uploaded project report. They are described as recorded evidence. No new AMS authentication, university record change, live payment, Internet email delivery or deployment is claimed by this report update. No passwords, tokens or private configuration are included.

## Bibliography

References use the unmodified IEEEtran.bst style by Michael Shell under LPPL 1.3; original notices are retained. IEEE style governs reference formatting, while the college report layout remains intact. The cited sources are actual project repositories, project documentation, AMS and framework/security documentation, not invented IEEE papers or DOIs.

Original style mirror:
https://raw.githubusercontent.com/rstudio/rticles/accdfa39225570a8ad9b786fbb3077060d1e12a5/inst/rmarkdown/templates/ieee/skeleton/IEEEtran.bst

IEEEtran.bst SHA-256: `314f0ece704568faf827011bac498650691b2b5ee06320720830e782416d5a5f`.
