"""Cross-platform project commands; run `python -m src.cli --help`."""
import argparse
import json
from pathlib import Path
from .data import ROOT, generate_demo, prepare


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    demo = commands.add_parser('demo', help='Generate explicitly synthetic practice sales')
    demo.add_argument('--output', type=Path, default=ROOT / 'data/raw/demo_sales.csv')
    demo.add_argument('--days', type=int, default=730)
    data = commands.add_parser('prepare', help='Validate CSV, save EDA and raw-source provenance')
    data.add_argument('--input', type=Path, default=ROOT / 'data/raw/demo_sales.csv')
    data.add_argument('--output', type=Path, default=ROOT / 'reports/week01')
    baseline = commands.add_parser('baseline', help='Evaluate naive/seasonal-naive seven-day validation forecasts')
    baseline.add_argument('--input', type=Path, default=ROOT / 'data/raw/demo_sales.csv')
    baseline.add_argument('--output', type=Path, default=ROOT / 'reports/week02')
    args = parser.parse_args()
    try:
        if args.command == 'demo':
            result = generate_demo(args.output, args.days)
        elif args.command == 'baseline':
            from .forecasting import baseline_report
            result = baseline_report(args.input, args.output)
        else:
            result = prepare(args.input, args.output)
    except (ValueError, FileNotFoundError) as exc:
        parser.exit(2, f'Input error: {exc}\n')
    print(json.dumps(result, indent=2, default=str))


if __name__ == '__main__':
    main()
