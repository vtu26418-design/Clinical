# Demand Forecasting — cumulative Week 1/4

This ZIP is the working Week 1 milestone of one cumulative Python/Jupyter project. Later weeks include earlier stages. Read weeks/week01/README.md and WEEKLY_LEARNING_PLAN.md for tasks, topics, YouTube links, websites and deliverables.

## Install once (Python 3.12)

Windows PowerShell, from this folder:
```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
.\.venv\Scripts\python.exe run_week.py
.\.venv\Scripts\python.exe -m jupyterlab
```

macOS/Linux:
```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-lock.txt
python run_week.py
python -m jupyterlab
```

## Work through this stage

Run notebooks 01 through 01 in order using the project Python kernel. Available terminal commands after activation:
```text
python run_week.py
python -m jupyterlab
python -m pytest -q
```

Week 1 produces audits, cleaned data and charts; Week 2 adds features and validation baselines; Week 3 adds learned models, held-out evaluation, future forecasts and inventory scenarios. The dashboard/API start at Week 4. The api/app/models folders are included for the final layout; availability is stated in each folder.

Bundled sales are synthetic practice data, not real retail findings. Import licensed historical sales following docs/DATA_GUIDE.md. Do not invent observed stock or supplier fields. Models are included in Week 3 and later under models/demo/; they are not expected in the data-only Weeks 1–2. For real-data model jobs use separate models/retail and reports/evaluation/retail directories.

Preserve your .git, .venv, local data and personal edits when upgrading; compare before copying. Weekly milestones do not replace meaningful daily Git activity required by your execution PDF. docs/COMPLETE_PROJECT_GUIDE.md describes the final application's later commands, not features already available in this stage.
