"""Public FastAPI entrypoint package."""
