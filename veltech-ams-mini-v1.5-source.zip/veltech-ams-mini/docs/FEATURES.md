# Active feature coverage in V1.5

| Area | Delivered behavior | Source or remaining dependency |
| --- | --- | --- |
| Home | Normal top current/next-class card, ten facts, private portrait, India clock, optional Home reels | Source class times; missing marks stay neutral; reels off by default |
| Official identity | Read-only source student details with no profile export | University data and administrative scope remain separate from editable social fields |
| Social profile | Display name, username, bio, social department, photo, links and privacy | Social edits never grant faculty/department permissions |
| Attendance | Overview/subject calendars, touch-hold day details, full subject pages, filters, bunk allowance, independent calculator/formulas, PDF/XLSX | Only source periods; no invented absence; PDF Latin text, XLSX Unicode; overview target card removed |
| Academics | Registered courses, discovered AMS results/grades, fees/receipts, documents and examinations; separate faculty publications | Explicit source provenance; unavailable/unsupported sections remain empty; private live retrieval unverified |
| Sync | Overall plus eight per-module attempt/success/error states; retained records identified | One successful section does not establish that all modules synced |
| Document access | Owner-only bounded signature-checked PDF/PNG/JPEG cache from safe associated AMS links | Maximum eight files / 16 MB per student, current fee/document sections; counts against Atlas quota |
| Course registration | Source courses, warnings and official AMS handoff | No guessed registration write endpoint; official submission remains in AMS |
| Events | Events/Reels tabs, free/paid filters, details/registration/ticket pages, media, bookmarks, waitlist, QR/manual check-in | Real paid tickets require merchant configuration and verified webhook |
| Community | Mixed feed, contextual comments, full-screen reels, like/save/share, three-dot menus, report workflow, connections and private follower requests | Private official fields excluded from public author DTOs |
| Comments | Immediate comment DTO, owner edit under five minutes, permitted delete, idempotent likes | Server timestamps/ownership apply to campus posts, legacy posts and reels |
| Suggestions | Weighted follows/interests/recency/engagement, refresh diversity and suggestions between content | Heuristic recommender; no trained Instagram/LinkedIn model claimed |
| Forms | Faculty/admin only authoring, scope, required typed questions, time windows, one response/account, sign-in preserving direct links | Organizer privileges alone cannot create forms |
| Proof and response export | Fresh camera challenge for all attachments, private owner-bound image capture, scoped faculty review and Excel workbook | Camera/GPS cannot guarantee physical presence; 10,000 export rows maximum |
| Event attendance | Fresh location/radius/accuracy/time checks, active ticket, faculty review and scoped faculty QR scanning | Challenge replay and duplicate check-in denied; no anti-cheating guarantee |
| Settings | Category navigation, account/social/media/appearance, Home reels, notifications and requested hardware permissions | Connections contains no importing UI; HTTPS and browser support needed |
| Device library | Passphrase-encrypted owned basic profile, academic metadata, attendance and timetable with expiry/deletion | Excludes secrets, contact/family, proof and document bytes; finite browser quota |
| Management | Account provisioning, staff scope, activation/password tools, notices/audit, event operations and community reports | Persisted server authority; faculty publications scoped separately |
| Placements | Developing state | No fictional live jobs |
| Windows/web | PowerShell + Docker Desktop + Atlas, React/Vite dev workflow, responsive PWA and bottom navigation | No Ubuntu requirement; no APK |

Home of VelTech's public listing describes a student-developed AMS client. No separate documented Home API was found. Public AMS login is reachable; a successful private student session and complete upstream coverage were not verified. A login in another browser does not supply this server's session. Storage is finite: Atlas holds database records and bounded private AMS file bytes; the persistent media volume holds uploaded social media and evidence.
