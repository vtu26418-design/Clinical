# Deployment and upgrades

Deploy the two application containers with MongoDB Atlas. The campus container is public through an HTTPS reverse proxy; the academic service is private to Docker's application network. Set the external HTTPS origin in `CAMPUS_ORIGINS` and `CAMPUS_COOKIE_SECURE=true`. Review the reverse proxy trust configuration before adding forwarded client IP headers. Keep TLS and provider certificate verification enabled.

The supplied localhost Compose file is a development configuration. Do not simply bind its HTTP port to every network interface. Rate limits are per process; multi-instance deployments need shared enforcement/session behavior and persistent shared media storage. Local uploads in `campus-media` survive container replacement but need backups, storage monitoring and a shared object-storage adapter before horizontal scaling.

Back up Atlas data, `.private/campus.env`, `.private/academic.env`, and uploaded media. Secrets and personal data are excluded from downloadable source. Restore the original `CAMPUS_LINK_KEY`, `CAMPUS_SERVICE_KEY`, academic `JWT_SECRET`, and `PORTAL_CREDENTIAL_ENCRYPTION_KEY` before reconnecting existing encrypted data. Keep bridge keys identical in the two private files. The two V1.2 database names are intentionally unchanged so existing Atlas data can be reused.

Before exposing real student access, configure actual email delivery, HTTPS, exact allowed origins, current Atlas IP permissions, backup/recovery and the university's permission for portal integration. Manually verify the connected source records and source timestamps. An academic parser test with synthetic HTML is not a live portal validation.

For campus event payments, complete merchant test-mode validation, webhook testing, pending-order handling, reconciliation and refund procedures before collecting money. The app cannot infer whether an external provider transaction succeeded from a browser message alone.
