# veltech-ams-mini V1.3

Authorized design: original logo; navy sidebar, teal accents and clean white workspace, mobile bottom tabs. Home exposes ten basic facts, attendance and the current/next class driven by the Asia/Kolkata clock. Events open a vertical reel feed with registration on each event. Community mixes posts, reels, stories, connections and explainable recommendations. Academic and contact records remain private. Original event scope roles are enforced by persisted accounts.

The cloud workspace was replaced on 15 October; the immutable V1.2 ZIP was restored and verified by SHA-256 before rebuilding. Test evidence from the lost workspace is not evidence for this build. The independent modules are being rebuilt with meaningful API, security and browser checks.

Live limitations: a browser AMS session on the user's computer is not shared with this runtime. Actual private AMS data and undocumented Home of VelTech APIs cannot be claimed verified from fixtures. Missing source modules stay explicit. Course planning and official handoff do not claim unsupported portal submission. Merchant payments, real email delivery and Atlas require the user's provider configuration.
