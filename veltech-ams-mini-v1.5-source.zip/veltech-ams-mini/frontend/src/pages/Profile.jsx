import {Link} from 'react-router-dom';
import {ShieldCheck,LockKeyhole,ArrowUpRight,GraduationCap,UserRound,ContactRound} from 'lucide-react';
import {useCampus} from '../context/CampusContext';
import {PageHeader,Avatar,SectionTitle} from '../components/UI';
import {officialStudentProfile} from '../lib/social-profile';
import '../profile-v14.css';

function Info({label,value}) {const missing=value===undefined||value===null||value==='';return <div className="profile-field"><dt>{label}</dt><dd className={missing?'profile-awaiting':''}>{missing?'Awaiting AMS':value}</dd></div>;}
export default function Profile() {
 const {data,mode}=useCampus(),p=officialStudentProfile(data.profile,mode);
 const imported=p.source==='student-import';
 const studentId=p.studentId || p.vtuNumber || p.rollNumber,department=p.department || p.branch,photo=p.photo || p.photoDataURI || p.photoDataUri || p.photoUrl;
 return <div className="profile-v14"><PageHeader title="Student information" description={imported?'A student-supplied copy, kept read only here.':'Your official college record, supplied by AMS.'}><Link className="button secondary" to="/profile/social/edit"><UserRound size={16}/>Edit social profile<ArrowUpRight size={15}/></Link></PageHeader>
  <section className="panel profile-official-hero"><Avatar name={p.name || 'Student'} src={photo} size="xl"/><div><span className="profile-eyebrow"><ShieldCheck size={15}/>{imported?'Student-supplied copy':'Official college record'}</span><h2>{p.name || 'Awaiting AMS'}</h2><p>{studentId || 'Awaiting AMS'}{department?` · ${department}`:''}</p><span className="muted">{mode==='demo'?'Fictional student information for preview':imported?'Not university verified':'Sourced from your authorized college portal'}</span></div><span className="profile-readonly"><LockKeyhole size={14}/>Read only</span></section>
  <div className="profile-record-note"><ShieldCheck size={20}/><p>{imported?'This is a student-supplied copy, not a university-verified record. It stays read only here.':'These details are managed by your college. If a record needs correcting, contact your institution.'} Your social profile has its own name, photo and introduction.</p></div>
  <div className="profile-grid"><section className="panel profile-section"><div className="profile-section-label"><UserRound size={18}/><SectionTitle title="Basic information"/></div><dl><Info label="Full name" value={p.name}/><Info label="Student / VTU ID" value={studentId}/><Info label="College roll number" value={p.rollNumber}/><Info label="Email" value={p.email}/><Info label="Mobile" value={p.phoneNumber || p.phone}/><Info label="Date of birth" value={p.dateOfBirth || p.dob}/><Info label="Gender" value={p.gender}/></dl></section>
  <section className="panel profile-section"><div className="profile-section-label"><GraduationCap size={18}/><SectionTitle title="Academic details"/></div><dl><Info label="Degree" value={p.degree}/><Info label="Department / branch" value={department}/><Info label="Year of study" value={p.year}/><Info label="Semester" value={p.semester}/><Info label="Section" value={p.section}/><Info label="Batch" value={p.batch}/><Info label="Mentor / faculty advisor" value={p.mentor || p.mentorName}/></dl></section>
  <section className="panel profile-section"><div className="profile-section-label"><ContactRound size={18}/><SectionTitle title="Family & emergency contact"/></div><dl><Info label="Father’s name" value={p.fatherName}/><Info label="Mother’s name" value={p.motherName}/><Info label="Parent / guardian" value={p.parentName}/><Info label="Parent contact" value={p.parentPhone}/></dl></section>
  <section className="panel profile-section profile-privacy-card"><span className="profile-privacy-icon"><LockKeyhole size={25}/></span><h2>Private to your account</h2><p>Your student information, academic records and contact details stay separate from your campus social profile.</p><Link className="social-inline-link" to={`/members/${encodeURIComponent(data.profile.username || data.profile.id || 'me')}`}>View your social profile<ArrowUpRight size={15}/></Link></section></div>
 </div>;
}
