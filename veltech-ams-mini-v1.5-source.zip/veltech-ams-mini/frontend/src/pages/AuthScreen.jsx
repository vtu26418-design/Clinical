import {useState} from 'react';
import {GraduationCap,ShieldCheck,ArrowLeft,Mail,KeyRound} from 'lucide-react';
import {Button,Field,Feedback} from '../components/UI';
import {useCampus} from '../context/CampusContext';
import {request,setCsrf} from '../lib/api';
import '../identity.css';

export default function AuthScreen({onClose=()=>{},onSuccess,compact=false,initialTab='login'}) {
 const campus=useCampus();
 const [tab,setTab]=useState(initialTab),[step,setStep]=useState('details'),[challenge,setChallenge]=useState('');
 const [form,setForm]=useState({identity:'',email:'',username:'',name:'',password:'',confirm:'',code:''});
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[success,setSuccess]=useState('');
 const update=(key,value)=>setForm(current=>({...current,[key]:value}));
 const changeTab=value=>{setTab(value);setStep('details');setChallenge('');setError('');setSuccess('');setForm(current=>({...current,password:'',confirm:'',code:''}));};
 async function submit(event){
  event.preventDefault();setBusy(true);setError('');setSuccess('');
  try {
   if(tab==='login') {if(await campus.signIn(form.identity,form.password)){onClose();onSuccess?.();}return;}
   const purpose=tab==='signup'?'signup':'reset';
   if(step==='details'){
    const payload=purpose==='signup'?{email:form.email,name:form.name,username:form.username,password:form.password}:{email:form.email};
    const result=await request(`/identity/${purpose}/request`,{method:'POST',body:payload});
    setChallenge(result.challengeId);setStep('code');setForm(current=>({...current,password:'',confirm:'',code:''}));setSuccess(result.message);return;
   }
   if(step==='code'){
    const result=await request(`/identity/${purpose}/verify`,{method:'POST',body:{challengeId:challenge,code:form.code}});
    setForm(current=>({...current,code:''}));
    if(purpose==='signup'){setCsrf(result.csrfToken);await campus.resume();onClose();onSuccess?.();}
    else {setStep('password');setSuccess(result.message);}
    return;
   }
   if(form.password!==form.confirm)throw new Error('The new passwords do not match.');
   const result=await request('/identity/reset/complete',{method:'POST',body:{password:form.password}});
   setCsrf('');campus.switchDemo?.();changeTab('login');setSuccess(result.message);
  } catch(error){setError(error.message || 'Please retry.');}
  finally {setBusy(false);}
 }
 const title=tab==='login'?'Welcome to your campus':tab==='signup'?'Create your campus account':'Reset your password';
 const content=<section className="identity-form-panel">
  <div className="identity-form-brand"><img src="/assets/original-logo.png" alt="UniEve original logo"/><span>veltech-ams-mini<small>Your campus, connected.</small></span></div>
  <div className="identity-tabs" role="tablist" aria-label="Campus account">
   <button role="tab" aria-selected={tab==='login'} onClick={()=>changeTab('login')} disabled={busy}>Sign in</button>
   <button role="tab" aria-selected={tab==='signup'} onClick={()=>changeTab('signup')} disabled={busy}>Create account</button>
  </div>
  <div className="identity-heading"><span className="identity-step-icon">{step==='code'?<Mail size={23}/>:tab==='reset'?<KeyRound size={23}/>:<GraduationCap size={24}/>}</span><h1>{step==='code'?'Check your email':step==='password'?'Choose a new password':title}</h1><p>{step==='code'?'Enter the six-digit code here within five minutes. Keep this browser open.':tab==='login'?'Use your project account to join campus events and your community.':tab==='signup'?'Verify your email to start with a secure student account.':'We will email a verification code if an account matches.'}</p></div>
  <form onSubmit={submit} className="identity-form">
   {step==='details' && tab==='login'?<><Field label="Email or username"><input autoComplete="username" value={form.identity} maxLength={200} required onChange={event=>update('identity',event.target.value)}/></Field><Field label="Password"><input type="password" autoComplete="current-password" value={form.password} maxLength={100} required onChange={event=>update('password',event.target.value)}/></Field></>:null}
   {step==='details' && tab!=='login'?<>
    {tab==='signup'?<><Field label="Full name"><input autoComplete="name" value={form.name} maxLength={100} required onChange={event=>update('name',event.target.value)}/></Field><Field label="Username"><input autoComplete="username" value={form.username} minLength={3} maxLength={30} pattern="[a-zA-Z0-9][a-zA-Z0-9._-]{2,29}" required onChange={event=>update('username',event.target.value)}/></Field></>:null}
    <Field label="Email address"><input type="email" autoComplete="email" value={form.email} maxLength={254} required onChange={event=>update('email',event.target.value)}/></Field>
    {tab==='signup'?<Field label="Password · at least 10 characters"><input type="password" autoComplete="new-password" value={form.password} minLength={10} maxLength={72} required onChange={event=>update('password',event.target.value)}/></Field>:null}
   </>:null}
   {step==='code'?<Field label="Six-digit email code"><input className="identity-code" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={form.code} required autoFocus onChange={event=>update('code',event.target.value.replace(/\D/g,''))}/></Field>:null}
   {step==='password'?<><Field label="New password · at least 10 characters"><input type="password" autoComplete="new-password" value={form.password} minLength={10} maxLength={72} required onChange={event=>update('password',event.target.value)}/></Field><Field label="Confirm new password"><input type="password" autoComplete="new-password" value={form.confirm} minLength={10} maxLength={72} required onChange={event=>update('confirm',event.target.value)}/></Field></>:null}
   <Feedback error={error} success={success}/>
   <Button type="submit" busy={busy}>{tab==='login'?'Sign in':step==='details'?'Send verification code':step==='code'?'Verify email':'Save new password'}</Button>
  </form>
  <div className="identity-assistance">{tab==='login'?<button className="text-button" onClick={()=>changeTab('reset')} disabled={busy}>Forgot your password?</button>:<button className="text-button" onClick={()=>changeTab(step==='details'?'login':tab)} disabled={busy}><ArrowLeft size={15}/>{step==='details'?'Back to sign in':'Start again'}</button>}</div>
  <p className="identity-security"><ShieldCheck size={16}/>Email codes expire in five minutes. Password resets sign out other devices.</p>
 </section>;
 if(compact)return <div className="identity-compact">{content}</div>;
 return <main className="identity-page"><aside className="identity-art"><div className="identity-orbit"/><img src="/assets/original-logo.png" alt=""/><span className="identity-eyebrow">ONE CONNECTED CAMPUS</span><h2>Study. Discover.<br/>Belong.</h2><p>Classes and attendance, memorable events, and a community that moves you forward.</p><div className="identity-art-footer"><ShieldCheck size={20}/><span>Your student records stay in your own account.</span></div></aside>{content}</main>;
}
