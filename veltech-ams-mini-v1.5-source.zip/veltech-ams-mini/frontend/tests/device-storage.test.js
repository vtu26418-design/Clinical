import test from 'node:test';
import assert from 'node:assert/strict';
import {createDeviceSnapshot,sealSnapshot,openSnapshot} from '../src/lib/device-storage.js';
test('snapshot keeps only selected academic fields and excludes secrets and private contact data',()=>{
 const snapshot=createDeviceSnapshot({profile:{name:'Student',studentId:'ID',email:'private',fatherName:'Private',portalPassword:'secret',photo:'private-url'},subjects:[{id:'s',name:'Math',present:9,total:10,token:'secret'}],classes:[],records:[{password:'secret'}]},'connected');
 assert.equal(snapshot.profile.name,'Student');assert.ok(!JSON.stringify(snapshot).includes('private'));assert.ok(!JSON.stringify(snapshot).includes('secret'));assert.ok(!snapshot.records);
});
test('AES device envelope unlocks only with correct passphrase and contains no plaintext records',async()=>{
 const payload={profile:{name:'Student'},source:'connected'};const envelope=await sealSnapshot(payload,'DevicePassphrase123',1,1000);
 assert.ok(!JSON.stringify(envelope).includes('Student'));assert.deepEqual(await openSnapshot(envelope,'DevicePassphrase123',2000),payload);
 await assert.rejects(openSnapshot(envelope,'wrong-password',2000));
});
test('expiry and tampered metadata cannot be bypassed',async()=>{
 const envelope=await sealSnapshot({profile:{name:'Student'}},'DevicePassphrase123',1,1000);
 await assert.rejects(openSnapshot(envelope,'DevicePassphrase123',envelope.expiresAt+1),/expired/);
 await assert.rejects(openSnapshot({...envelope,expiresAt:envelope.expiresAt+1},'DevicePassphrase123',2000));
});
test('owned offline library preserves available academic sections while removing nested credentials and private files',()=>{
 const snapshot=createDeviceSnapshot({profile:{name:'Student',studentId:'ID',officialProfile:{name:'Official',branch:'CSE',section:'B',portalPassword:'sensitive'}},subjects:[],classes:[],records:[{date:'2026-10-15',subjectCode:'CS101',status:'present',token:'sensitive'}],timetable:[{day:'Thursday',subjectCode:'CS101',startTime:'10:00',endTime:'10:50',password:'sensitive'}],academic:{courses:[{code:'CS101',name:'Algorithms',credits:3,token:'sensitive'}],results:[{courseCode:'CS101',grade:'A',semester:'3',secret:'sensitive'}],fees:[{name:'Exam fee',amount:1000,status:'Paid',reference:'receipt',password:'sensitive'}],documents:[{name:'Transcript',type:'Results',url:'https://example.test?token=sensitive',sealedToken:'sensitive'}]}},'connected');
 assert.equal(snapshot.profile.name,'Official');assert.equal(snapshot.records[0].status,'present');assert.equal(snapshot.timetable[0].day,'Thursday');
 assert.equal(snapshot.academic.results[0].grade,'A');assert.equal(snapshot.academic.fees[0].amount,1000);assert.equal(snapshot.academic.documents[0].name,'Transcript');
 assert.ok(!JSON.stringify(snapshot).includes('sensitive'));assert.ok(!JSON.stringify(snapshot).includes('url'));
});
