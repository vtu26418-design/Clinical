import crypto from 'node:crypto';
import bcrypt from 'bcrypt';
import User from '../../models/User.js';
import {AcademicLink,Session} from '../models.js';
import {publicUser,campusRole} from '../policy.js';
import {encryptToken,hashToken,newToken,fail} from '../security.js';
const cookieName='campus_portal_browser';
const cookiePath='/api/campus/portal';
function browserOwner(req,config){
 const token=(req.headers.cookie || '').split(';').map(v=>v.trim()).find(v=>v.startsWith(cookieName+'='))?.slice(cookieName.length+1);
 if(!/^[a-f0-9]{64}$/.test(token || ''))fail(409,'Load a fresh AMS challenge in this browser.');
 return crypto.createHmac('sha256',config.linkKey).update(token).digest('hex');
}
export async function resolveCampusPortal(result){
 const principal=result.portalPrincipal;
 if(typeof principal!=='string' || !principal.trim() || principal.length>100 || !/^[a-f0-9]{24}$/i.test(result.user?.id || '') || typeof result.token!=='string' || !result.user?.email)fail(502,'AMS did not confirm a supported student identity.');
 let user=await User.findOne({portalPrincipal:principal});
 if(user){
  if(user.role!=='student' || campusRole(user)==='admin' || user.isActive===false || !user.portalPrincipalVerifiedAt || user.portalAcademicId!==result.user.id)fail(403,'Use campus password sign-in for this account, or contact the administrator.');
  return user;
 }
 try{user=await User.create({username:'ams_'+newToken().slice(0,24),email:result.user.email,password:await bcrypt.hash(newToken(),12),name:String(result.user.name || 'Student').slice(0,120),role:'student',isActive:true,portalOnly:true,portalPrincipal:principal,portalAcademicId:result.user.id,portalPrincipalVerifiedAt:new Date()});}
 catch(error){if(error.code!==11000)throw error;user=await User.findOne({portalPrincipal:principal});if(!user || user.role!=='student' || campusRole(user)==='admin' || user.isActive===false || !user.portalPrincipalVerifiedAt || user.portalAcademicId!==result.user.id)fail(409,'An existing campus identity needs a verified migration. No account was merged by email.');}
 return user;
}
export function registerPortalLogin(router,config){
 router.post('/portal/challenge',async(req,res)=>{
  if(!config.linkKey)fail(503,'Configure the persistent academic encryption key before AMS sign-in.');
  const browser=newToken(),owner=crypto.createHmac('sha256',config.linkKey).update(browser).digest('hex');
  const result=await config.academic.internal('/campus/portal-login/challenge',{owner});
  res.cookie(cookieName,browser,{httpOnly:true,sameSite:'strict',secure:config.cookieSecure,maxAge:5*60000,path:cookiePath});
  res.json(result);
 });
 router.post('/portal/login',async(req,res)=>{
  if(!config.linkKey)fail(503,'Configure the persistent academic encryption key before AMS sign-in.');
  const owner=browserOwner(req,config),{username,password,challengeId,answer=''}=req.body || {};
  if(typeof username!=='string' || !username.trim() || username.length>100 || typeof password!=='string' || !password || password.length>200 || typeof challengeId!=='string' || challengeId.length<20 || challengeId.length>100 || typeof answer!=='string' || answer.length>30)fail(400,'Enter your AMS username, password and current challenge answer.');
  const result=await config.academic.internal('/campus/portal-login/session',{owner,username:username.trim(),password,challengeId,answer});
  const user=await resolveCampusPortal(result);
  await AcademicLink.findOneAndUpdate({user:user._id},{$set:{academicId:result.user.id,email:user.email,sealedToken:encryptToken(result.token,config.linkKey),managed:false,linkedAt:new Date()}},{upsert:true});
  const token=newToken(),csrfToken=newToken();
  await Session.create({user:user._id,tokenHash:hashToken(token),csrfToken,expiresAt:new Date(Date.now()+7*86400000)});
  res.cookie('campus_session',token,{httpOnly:true,sameSite:'strict',secure:config.cookieSecure,maxAge:7*86400000,path:'/api/campus'});
  res.clearCookie(cookieName,{httpOnly:true,sameSite:'strict',secure:config.cookieSecure,path:cookiePath});
  res.json({user:publicUser(user),csrfToken,partial:!!result.partial,notes:result.notes || [],source:'ams-manual-login'});
 });
}
