"""Authenticated read orchestration shared by login and manual refresh."""
from app.services.student_service import StudentService
from app.services.timetable_service import TimetableService
from app.services.ams.academic_pages import collect_academic_pages
from app.services.ams.storage import store_academic_rows
from app.services.ams.source_modules import collect_source_modules,store_source_modules
from app.services.ams.sync_status import report_module,report_discovered_modules,finish_sync


async def sync_authenticated_records(db,sid,session,adapter,profile):
    StudentService(db)._save_ams_profile(sid,profile)
    report_module(db,sid,'profile','available',record_count=1)
    notes=[];course_count=0
    try:
        timetable=await TimetableService(db,ams_adapter=adapter).sync_timetable(sid,session,profile=profile)
        count=timetable.get('inserted',0)
        course_count=timetable.get('sourceCoursesCount',0)
        report_module(db,sid,'timetable','available' if count else 'unsupported',record_count=count if count else None,
                      error='Data not available: no supported current AMS timetable rows.')
    except Exception:
        report_module(db,sid,'timetable','error',error='AMS timetable could not be updated; previous records retained.')
        notes.append('AMS timetable could not be updated; previous records retained.')
    rows=await collect_academic_pages(session,adapter)
    accepted=store_academic_rows(db,sid,rows);notes.extend(rows['notes'])
    if rows['results'] and not accepted['results']:
        for module in rows.get('modules',[]):
            if module.get('kind')=='results' and module.get('status')=='available':
                module.update(status='unsupported',layoutSupported=False,rowCount=0,error='Conflicting AMS grades were discarded; previous grades retained.')
        notes.append('Conflicting AMS grades were discarded; previous grades retained.')
    modules=await collect_source_modules(session,adapter)
    # Attendance/results are read by their dedicated conservative table reader.
    discovered={module['url']:module for module in modules['modules']}
    discovered.update({module['url']:module for module in rows.get('modules',[])})
    modules['modules']=list(discovered.values())
    store_source_modules(db,sid,modules);notes.extend(modules.get('notes',[]))
    report_discovered_modules(db,sid,modules['modules'],{
        'attendance':'attendance','results':'results','fees':'fees','examinations':'examinations','documents':'documents'})
    registered=modules.get('registeredCourses',[])
    if registered or course_count:
        report_module(db,sid,'courses','available',record_count=len(registered) or course_count)
    else:
        registration=[module for module in modules['modules'] if module.get('kind')=='course-registration']
        report_module(db,sid,'courses','unsupported' if any(module.get('status') in {'available','unsupported'} for module in registration) else 'unavailable',
                      error='Data not available: no supported registered course rows were returned.')
    finish_sync(db,sid)
    return {'notes':notes,'updated':{**accepted,
                                   **{kind:len(modules.get(kind,[])) for kind in ('fees','examinations','documents')}}}
