"""Conservative source discovery and labeled fee extraction. Unknown layouts stay empty."""
import re
from bs4 import BeautifulSoup
from bson import ObjectId
from app.services.ams.academic_pages import discover_academic_pages,_same_origin,_login_or_error,MAX_PAGE_BYTES,REQUEST_TIMEOUT,_date
from app.utils.dates import utc_now

def parse_fee_rows(html):
    output=[]
    mapping={'description':'name','feetype':'name','feename':'name','particulars':'name','feeamount':'amount','amount':'amount','paymentstatus':'status','status':'status','paiddate':'date','duedate':'date','transactionreference':'reference','receiptnumber':'reference','referencenumber':'reference'}
    for table in BeautifulSoup(html,'html.parser').find_all('table'):
        columns=None
        for tr in table.find_all('tr'):
            if tr.find_parent('table') is not table:continue
            cells=tr.find_all(['th','td'],recursive=False)
            values=[cell.get_text(' ',strip=True) for cell in cells]
            headers={mapping.get(re.sub(r'[^a-z0-9]','',v.lower())):i for i,v in enumerate(values)}
            if 'name' in headers and 'amount' in headers:columns={k:v for k,v in headers.items() if k};continue
            if not columns or any(i>=len(values) for i in columns.values()):continue
            row={k:values[i] for k,i in columns.items()}
            amount=re.sub(r'^(?:INR|Rs\.?|₹)\s*','',row['amount']).replace(',','')
            if not row['name'] or len(row['name'])>300 or not re.fullmatch(r'\d{1,10}(?:\.\d{1,2})?',amount):continue
            row['amount']=float(amount)
            if row.get('date'):
                parsed=_date(row['date'])
                if not parsed:row.pop('date')
                else:row['date']=parsed
            output.append(row)
            if len(output)>=4000:return output
    return output

async def collect_source_modules(session,adapter):
    base=session.get('url') or adapter.BASE_URL
    html=session.get('dashboard_html','')
    if not html or not _same_origin(base) or _login_or_error(html,adapter):return {'modules':[],'fees':[]}
    identifiers=[session.get(k) for k in ('username','portalUsername','vtuNumber','studentId','rollNumber') if session.get(k)]
    modules=discover_academic_pages(html,base,identifiers,include_modules=True)
    output={'modules':[{**m,'layoutSupported':False} for m in modules],'fees':[]}
    for module in output['modules']:
        if module['kind']!='fees':continue
        try:
            response=await session['client'].get(module['url'],timeout=REQUEST_TIMEOUT,follow_redirects=False)
            if response.status_code!=200 or not _same_origin(str(response.url)) or len(response.content)>MAX_PAGE_BYTES or _login_or_error(response.text,adapter):continue
            rows=parse_fee_rows(response.text)
            module['layoutSupported']=bool(rows)
            output['fees'].extend(rows)
        except Exception:continue
        break
    return output

def store_source_modules(db,student_id,source):
    db.timetable_metadata.update_one({'studentId':student_id},{'$set':{'sourceModules':source['modules']}},upsert=True)
    if source['fees']:
        db.users.update_one({'_id':ObjectId(student_id)},{'$set':{'fees':[{**row,'source':'ams','sourceUpdatedAt':utc_now().isoformat()} for row in source['fees']]}})
