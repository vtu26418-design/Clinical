"""Private, read-only campus overview of existing per-student source records."""
from fastapi import APIRouter, Depends, HTTPException
from pymongo.database import Database
from app.config.database import get_db
from app.security.permissions import get_current_user
from app.services.base import serialize_document
from app.scheduler.attendance_sync import AttendanceSyncRunner
from pydantic import BaseModel, Field
from app.security.permissions import require_student
from app.security.portal_credentials import decrypt_portal_password
from app.services.ams.ams_adapter import AmsAdapter, AmsAuthenticationError
from app.services.ams.manual_session import prepare_challenge, take_challenge
from app.services.ams.academic_pages import collect_academic_pages
from app.services.ams.storage import store_academic_rows
from app.services.student_service import StudentService
from app.services.timetable_service import TimetableService
from app.services.university_sources import source_status, public_news

router = APIRouter(prefix="/campus", tags=["campus"])

PROFILE_FIELDS = (
    "name", "email", "portalUsername", "photoDataUri", "vtuNumber", "rollNumber", "phoneNumber", "branch",
    "degree", "year", "semester", "section", "batch", "mentorName", "photoUrl",
    "gender", "dateOfBirth", "fatherName", "motherName", "parentName", "parentPhone",
    "academicBankCreditsId", "portalSynced", "lastSyncedAt", "source",
)

@router.get('/sources')
async def sources():
    return await source_status()

@router.get('/news')
async def news():
    try:
        return await public_news()
    except Exception:
        raise HTTPException(502, 'The official university website could not be fetched. Please retry.')

@router.post('/ams/challenge')
async def ams_challenge(current_user: dict = Depends(require_student)):
    try:
        return await prepare_challenge(str(current_user['id']))
    except Exception:
        raise HTTPException(502, 'Could not load the official AMS challenge. Check the portal connection and retry.')

class AmsSyncInput(BaseModel):
    challengeId: str = Field(min_length=20,max_length=100)
    answer: str = Field(min_length=1,max_length=30)

@router.post('/ams/sync')
async def ams_sync(body: AmsSyncInput, current_user: dict = Depends(require_student), db: Database = Depends(get_db)):
    if not current_user.get('portalPasswordEncrypted') or not current_user.get('portalUsername'):
        raise HTTPException(409,'Save your own portal connection before syncing AMS.')
    try:
        prepared=await take_challenge(str(current_user['id']),body.challengeId)
    except ValueError as error:
        raise HTTPException(409,str(error))
    adapter=AmsAdapter();session=None
    try:
        password=decrypt_portal_password(current_user['portalPasswordEncrypted'])
        session=await adapter.login(current_user['portalUsername'],password,captcha=body.answer,prepared=prepared)
        profile=await adapter.get_student_profile(session)
        if not profile:raise ValueError('No student profile was returned.')
        # Authentication just proved this exact AMS principal. Bind only the signed-in
        # student's own workspace; never claim an existing owner by email.
        principal=str(session.get('portalUsername') or session.get('username') or '').strip()
        if not principal:raise HTTPException(502,'AMS did not confirm the student identity.')
        db.users.create_index('portalVerifiedPrincipal',unique=True,sparse=True)
        conflict=db.users.find_one({'portalVerifiedPrincipal':principal})
        if conflict and str(conflict['_id'])!=str(current_user['id']):raise HTTPException(409,'This verified portal identity already belongs to another academic workspace. Contact the administrator for a verified migration.')
        from app.utils.dates import utc_now
        from bson import ObjectId
        db.users.update_one({'_id':ObjectId(current_user['id'])},{'$set':{'portalVerifiedPrincipal':principal,'portalPrincipalVerifiedAt':utc_now()}})
        StudentService(db)._save_ams_profile(str(current_user['id']),profile)
        errors=[]
        try:
            await TimetableService(db,ams_adapter=adapter).sync_timetable(str(current_user['id']),session,profile=profile)
        except Exception:
            errors.append('AMS timetable could not be updated; previous records retained.')
        rows=await collect_academic_pages(session,adapter)
        store_academic_rows(db,str(current_user['id']),rows)
        from app.services.ams.source_modules import collect_source_modules,store_source_modules
        store_source_modules(db,str(current_user['id']),await collect_source_modules(session,adapter))
        errors.extend(rows['notes'])
        for kind, label in (('summary','attendance totals'),('records','period attendance'),('results','results')):
            if not rows[kind]:errors.append(f'No supported {label} rows were returned; previous records retained.')
        return {'success':True,'source':'ams','partial':bool(errors),'errors':errors,'portalPrincipal':principal,'academicId':str(current_user['id']),
                'updated':{kind:len(rows[kind]) for kind in ('summary','records','results')}}
    except HTTPException:
        raise
    except AmsAuthenticationError:
        raise HTTPException(400,'AMS did not accept the login or CAPTCHA. Load a fresh challenge and check your credentials.')
    except Exception:
        raise HTTPException(502,'AMS data could not be fetched completely. Existing records were preserved; check the source and retry.')
    finally:
        if session:
            await adapter.logout(session)
        else:
            await prepared['client'].aclose()

@router.get("/snapshot")
def snapshot(current_user: dict = Depends(get_current_user), db: Database = Depends(get_db)):
    student_id = str(current_user["id"])
    # Authentication already resolves this student's own document; caller supplies no ID.
    profile = {field: current_user.get(field) for field in PROFILE_FIELDS if current_user.get(field) is not None}
    metadata = db["timetable_metadata"].find_one({"studentId": student_id}) or {}
    source_profile = metadata.get("profile", {})
    if isinstance(source_profile, dict):
        for key in ("batch", "mentorName", "semester", "branch", "rollNumber", "degree"):
            if not profile.get(key) and source_profile.get(key):
                profile[key] = source_profile[key]
    academic = {"bucket": metadata.get("bucket"), "courses": metadata.get("courses", []),
                "updatedAt": metadata.get("updatedAt"), "source": metadata.get("source")}
    # Only display additional academic modules when present in the source database.
    for field in ("results", "examinations", "fees", "documents", "requests"):
        if current_user.get(field) is not None:
            academic[field] = current_user[field]
    academic['sourceModules']=metadata.get('sourceModules',[])
    academic['coverage']={key:('available' if academic.get(key) else 'unavailable') for key in ('courses','results','examinations','fees','documents','requests')}
    academic['liveVerified']=bool(current_user.get('portalPrincipalVerifiedAt'))
    result={"profile": profile, "academic": academic}
    if current_user.get('amsAttendanceSummary') is not None:
        result['attendanceSummary']=current_user['amsAttendanceSummary']
    if current_user.get('amsClassRecords') is not None:
        result['attendanceRecords']=current_user['amsClassRecords']
    return serialize_document(result)

@router.post("/sync")
async def sync(current_user: dict = Depends(get_current_user), db: Database = Depends(get_db)):
    if current_user.get("role") != "student":
        raise HTTPException(status_code=403, detail="Student account required for portal sync")
    raise HTTPException(status_code=410, detail='The parent-portal sync is retired. Use the manual AMS connection for your own records.')

class StudentImportInput(BaseModel):
    format: str = Field(pattern=r'^(json|csv|html)$')
    content: str = Field(max_length=5_000_000)

@router.post('/import')
def import_records(body: StudentImportInput, current_user: dict = Depends(require_student), db: Database = Depends(get_db)):
    from app.services.student_import import parse_student_import,store_student_import
    return store_student_import(db,str(current_user['id']),parse_student_import(body.format,body.content))

@router.get('/course-registration')
def course_registration(current_user: dict = Depends(require_student), db: Database = Depends(get_db)):
    metadata=db.timetable_metadata.find_one({'studentId':str(current_user['id'])}) or {}
    modules=metadata.get('sourceModules',[])
    official=next((item.get('url') for item in modules if isinstance(item,dict) and item.get('kind')=='course-registration' and str(item.get('url','')).startswith('https://ams.veltech.edu.in/')),None)
    return serialize_document({'registeredCourses':metadata.get('courses',[]),'offerings':metadata.get('offerings',[]),'registrationWindow':metadata.get('registrationWindow'),'officialUrl':official,'submissionSupported':False,'source':metadata.get('source') or 'unavailable','layoutSupported':bool(metadata.get('courses')),'message':'Plan and export a course selection here. Submit registration in the official AMS portal; no supported submission API has been verified.'})
