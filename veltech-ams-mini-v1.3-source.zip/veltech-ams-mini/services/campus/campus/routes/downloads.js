import path from 'node:path';
import fs from 'node:fs';
export function registerDownloads(router,options={}) {
 const dist=options.dist || process.env.CAMPUS_WEB_DIST || path.resolve('frontend/dist');
 const directory=options.directory || process.env.CAMPUS_DOWNLOAD_DIR || path.resolve(dist,'../../downloads');
 const base='https://raw.githubusercontent.com/vtu26418-design/Clinical/veltech-ams-mini-v1.3-downloads/';
 const files=[{id:'source',label:'veltech-ams-mini V1.3 · full React source',filename:'veltech-ams-mini-v1.3-source.zip',type:'application/zip'},{id:'mobile-web',label:'veltech-ams-mini V1.3 · mobile and web build',filename:'veltech-ams-mini-v1.3-mobile-web.zip',type:'application/zip'},{id:'guide',label:'Windows Docker setup guide',filename:'veltech-ams-mini-v1.3-setup.md',type:'text/markdown; charset=utf-8'}];
 const local=file=>{const target=path.join(directory,file.filename);return fs.existsSync(target)&&fs.statSync(target).isFile()?target:null;};
 router.get('/downloads',(_req,res)=>res.json({items:files.map(file=>{const target=local(file);return {id:file.id,label:file.label,available:true,hosted:!target,bytes:target?fs.statSync(target).size:null,url:target?`/api/campus/downloads/${file.id}`:base+file.filename};})}));
 router.get('/downloads/:id',(req,res)=>{const file=files.find(file=>file.id===req.params.id);if(!file)return res.status(404).json({message:'Download not found'});const target=local(file);if(!target)return res.redirect(302,base+file.filename);res.type(file.type).download(target,file.filename);});
}
