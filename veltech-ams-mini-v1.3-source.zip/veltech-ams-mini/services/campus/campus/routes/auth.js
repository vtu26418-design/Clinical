import bcrypt from 'bcrypt';
import User from '../../models/User.js';
import {Session} from '../models.js';
import {publicUser} from '../policy.js';
import {hashToken,newToken,fail} from '../security.js';
export function registerAuth(router,config) {
  router.post('/login',async(req,res)=>{
    const {identity,password}=req.body;
    if(typeof identity!=='string' || typeof password!=='string' || identity.length>200 || password.length>200) fail(400,'Enter your email and password');
    if(Buffer.byteLength(password,'utf8')>72) fail(400,'Campus passwords must be at most 72 UTF-8 bytes. Reset a longer existing password through the original app before using campus sign-in.');
    const clean=identity.trim().toLowerCase();
    const user=await User.findOne({$or:[{email:clean},{username:clean}]});
    if(!user || user.isActive===false || !await bcrypt.compare(password,user.password)) fail(401,'Incorrect email or password');
    const token=newToken(),csrfToken=newToken();
    await Session.create({user:user._id,tokenHash:hashToken(token),csrfToken,expiresAt:new Date(Date.now()+7*86400000)});
    res.cookie('campus_session',token,{httpOnly:true,sameSite:'strict',secure:config.cookieSecure,maxAge:7*86400000,path:'/api/campus'});
    res.json({user:publicUser(user),csrfToken});
  });
  router.get('/session',config.auth,(req,res)=>res.json({user:publicUser(req.user),csrfToken:req.session.csrfToken}));
  router.post('/logout',config.auth,async(req,res)=>{
    await Session.deleteOne({_id:req.session._id});res.clearCookie('campus_session',{httpOnly:true,sameSite:'strict',secure:config.cookieSecure,path:'/api/campus'});res.json({success:true});
  });
  router.patch('/profile',config.auth,async(req,res)=>{
    const changes={};
    for(const [key,max] of [['bio',300],['phone',30]]) if(typeof req.body[key]==='string') changes[key]=req.body[key].trim().slice(0,max);
    const user=await User.findByIdAndUpdate(req.user._id,{$set:changes},{returnDocument:'after'});
    res.json(publicUser(user));
  });
}
