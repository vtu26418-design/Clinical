export const ROLES = ['student','club_organizer','department_coordinator','college_event_manager','placement_officer','admin'];
export function campusRole(user) {
  if (user?.role === 'admin') return 'admin';
  return ROLES.includes(user?.campusRole) ? user.campusRole : 'student';
}
const id = value => String(value?._id ?? value ?? '');
export function canCreateEvent(user, event) {
  const role = campusRole(user);
  if (role === 'admin') return true;
  if (event.scope === 'club') return role === 'club_organizer' && !!user.club && user.club === event.club && !!user.department && user.department === event.department;
  if (event.scope === 'department') return role === 'department_coordinator' && !!user.department && user.department === event.department;
  return event.scope === 'college' && role === 'college_event_manager';
}
export function canManageEvent(user, event) {
  if (!user || !event) return false;
  if (campusRole(user) === 'admin') return true;
  if (!event.scope || event.scope === 'legacy') return id(user.id ?? user._id) === id(event.createdBy);
  return canCreateEvent(user, event);
}
export const canManagePlacements = user => ['admin','placement_officer'].includes(campusRole(user));
export function publicUser(user) {
  return {id:id(user._id ?? user.id),name:user.name || user.username,email:user.email,username:user.username,image:user.image,department:user.department,studentId:user.studentId,phone:user.phone,campusRole:campusRole(user),club:user.club || '',bio:user.bio || '',isVerified:!!user.isVerified,isActive:user.isActive!==false,portalOnly:!!user.portalOnly,portalPrincipal:user.portalPrincipal || ''};
}
