# Active feature coverage in V1.3

| Area | Working application features | Source or remaining dependency |
| --- | --- | --- |
| Student home | Original logo, private photo/avatar, ten basic student facts, attendance totals, current/next class, day timeline, academic shortcuts, events and notices | Actual supported AMS records or your own explicitly labeled import; sample preview is fictional |
| Academics | Attendance by course/period, timetable, course/grade/result records, fees, examinations and documents when supplied, CSV exports | Unknown or unavailable portal modules remain empty; no fabricated data |
| Course registration | Source registered courses/offerings, credit totals, known timing conflicts, duplicate checks, prerequisites/unknown-data warnings, draft export and official AMS handoff | No undocumented submission API is claimed |
| AMS connection | Browser-bound manual challenge, read-only account authentication, encrypted internal academic session, secure identity binding, same-origin bounded private photo | Live authentication/private records were not verified in the build environment; your other browser session is separate |
| Events | Vertical reels/poster stream, event-linked posts/reels, registration details, free QR tickets, paid order flow, server-verified capture, calendar/ticket downloads, waitlists, bookmarks | Real merchant keys/webhook and real payment capture are not configured or tested |
| Community | Posts, image/video uploads, overlays/styles, links, hashtags/mentions/location, reels, playback controls, comments/likes/bookmarks, text/image/video stories, private archive | Real accounts use protected uploads; preview uploads are temporary browser objects |
| Suggestions | Transparent weighted ranking from followed authors, shared interests, recency and engagement, with author diversity and reasons | Rules-based model, not a trained imitation of a proprietary algorithm; privacy filtering runs first |
| Connections | Member search/profiles, public follows, private requests/accept/reject, followers/following, saved content and owned notifications | Social metadata excludes private academic, contact and family fields |
| Account/settings | Verified signup, browser-bound one-use reset proof, session revocation, social profile/privacy, notification preferences, device snapshot encryption, install/display/accessibility controls | Signup/reset needs SMTP or Brevo; optional local Mailpit is only a development inbox |
| Management | Club/department/college event scope roles, event editing/archive, analytics, participant CSV/check-in, account provisioning/role/password/activation controls, notices and audit | Staff authority comes from persisted server-side roles |
| Academic admin | Student workspace management, attendance/course/timetable controls, portal diagnostics, sync status, audit and SMS status views | SMS integration reports test/unconfigured status; Internet SMS delivery is not implemented |
| Placements | Campus/off-campus listings, application tracking, saved opportunities, authorized placement publishing | College placement feed/API has not been supplied; postings are managed in this application |
| Windows and mobile | PowerShell setup, Docker Desktop APIs, Atlas configuration, direct React/Vite development, responsive bottom navigation, installable web app | No Ubuntu required. Mobile build is a PWA, not an APK; connected phone hosting needs HTTPS |

Home of VelTech's linked listing describes an AMS client; no separate documented data API was found. The retired parent portal is not used. This independent project does not claim to be an institution-issued application.
