# Active feature coverage in V1.4

| Area | Delivered behavior | Source or remaining dependency |
| --- | --- | --- |
| Home | Pinned current/next class, ten official facts, private portrait, real-time India clock, attendance and academic shortcuts | Known AMS source times; unmarked/ambiguous records stay neutral |
| Student information | Read-only source snapshot, no profile export, explicit import provenance | Authorized AMS or clearly labeled student-supplied copy |
| Social profile | Separate display name, username, bio, social department, photo, links and privacy | Never edits college department/role, official name or family details |
| Attendance | Overview calendar, full subject pages, status/date filters, source period records, safe target allowance, independent calculator/formulas, genuine PDF/XLSX | Export contains attendance only; no invented absence records; PDF Latin text, XLSX preserves Unicode |
| Academics | Registered courses, source results/grades, fees, documents and examinations; separate scoped faculty exam publishing | No missing grade/GPA is estimated; Resources removed |
| Course registration | Source registered/offered courses, source warnings and official AMS handoff | No guessed API or university submission is claimed |
| Events | Events/Reels tabs, free/paid filters, details/registration/ticket pages, owned media, bookmarks, QR/manual entry, waitlist and calendar | Real payments require merchant configuration and verified webhook; no browser callback can issue a paid ticket |
| Community | Route-based composers, posts/reels/stories/archive, real media, likes/saves/shares/comments, connections, private follower requests | Preview media is synthetic or temporary local files; no private college data in public author DTOs |
| Suggestions | Transparent weighted scoring, follows/interests/recency/engagement and diversity | No trained proprietary-style ML algorithm is claimed |
| Forms & feedback | Typed required questions/choices, scoped faculty authoring, opening/closing time, one response per student, private proof uploads and review | Only authorized faculty/event staff can review their scope; evidence uploads are separate from public social media |
| Event evidence | Fresh one-use challenge, server radius/accuracy/time checks, registered ticket requirement, faculty approval consumes active ticket | GPS can be spoofed or inaccurate; location is supporting evidence, never sole identity proof |
| Settings | App appearance/motion/text size, notification subscriptions, explicit camera/location/system permission checks, social feed/media preferences, encrypted device snapshot | Browser HTTPS/device support required; no continuous tracking; system site settings revoke hardware permission |
| Management | Provision student/faculty accounts, assign scoped staff roles, activation/password controls, notices/audit, event analytics/archive/check-in | Persisted authority checked server-side; event management editors use normal page sections |
| Academic admin | Private bridge for student/course/attendance/timetable management and sync status | College administrator only; SMS remains test/unconfigured |
| Placements | Developing state | No fictional jobs presented as live vacancies |
| Windows/mobile | PowerShell setup, Docker Desktop APIs, Atlas configuration, React/Vite dev workflow, installable PWA with bottom navigation | No Ubuntu required; mobile delivery is a PWA, not an APK |

Home of VelTech's public listing describes a student-developed AMS client. No separate documented API was found. Public AMS login/news are reachable, but private student retrieval was not verified. A session in another browser is separate from this app's server session. Unknown source modules remain unavailable until an adapter/provider supplies them. The retired parent portal is not used.
