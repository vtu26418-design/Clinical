"""Explicitly labeled, discovered AMS sections; never guess private routes.

These readers support labeled fixtures. Public login availability does not verify
an authenticated AMS module or its current layout.
"""
import re
from bs4 import BeautifulSoup
from bson import ObjectId
import httpx
from app.services.ams.academic_pages import (
    discover_academic_pages, _same_origin, _login_or_error, MAX_PAGE_BYTES,
    REQUEST_TIMEOUT, _date, _CODE, MAX_ROWS, MAX_PAGES,
)
from app.utils.dates import utc_now


def _normalized(value):
    return re.sub(r'[^a-z0-9]', '', value.lower())


def _table_rows(table, mapping, required):
    """Require unambiguous headers and exact widths, ignoring merged cells."""
    columns = None
    width = 0
    for tr in table.find_all('tr'):
        if tr.find_parent('table') is not table:
            continue
        cells = tr.find_all(['th', 'td'], recursive=False)
        if not cells or any(str(cell.get(attr, '1')) != '1' for cell in cells for attr in ('colspan', 'rowspan')):
            continue
        values = [cell.get_text(' ', strip=True) for cell in cells]
        matched = [(mapping[_normalized(value)], i) for i, value in enumerate(values) if _normalized(value) in mapping]
        fields = [field for field, _ in matched]
        if required <= set(fields):
            columns = dict(matched) if len(fields) == len(set(fields)) else None
            width = len(cells)
            continue
        if columns is None or len(cells) != width or any(len(value) > 500 for value in values):
            continue
        yield {key: values[index] for key, index in columns.items()}, cells, columns


def _source_date(row):
    if row.get('date'):
        raw = row['date']
        parsed = _date(raw)
        if parsed:
            row['date'] = parsed
        else:
            row['dateText'] = raw
            row.pop('date')


def parse_fee_rows(html):
    output = []
    mapping = {'description': 'name', 'feetype': 'name', 'feename': 'name', 'particulars': 'name',
               'feeamount': 'amount', 'amount': 'amount', 'paymentstatus': 'status', 'status': 'status',
               'paiddate': 'date', 'duedate': 'date', 'transactionreference': 'reference',
               'receiptnumber': 'reference', 'referencenumber': 'reference'}
    for table in BeautifulSoup(html, 'html.parser').find_all('table'):
        for row, _, _ in _table_rows(table, mapping, {'name', 'amount'}):
            amount = re.sub(r'^(?:INR|Rs\.?|₹)\s*', '', row['amount']).replace(',', '')
            if not row['name'] or not re.fullmatch(r'\d{1,10}(?:\.\d{1,2})?', amount):
                continue
            row['amount'] = float(amount)
            _source_date(row)
            output.append(row)
            if len(output) >= MAX_ROWS:
                return output
    return output


def parse_registration_page(html):
    """Registered courses and offerings need separate explicit table labels."""
    soup = BeautifulSoup(html, 'html.parser')
    output = {'registeredCourses': [], 'offerings': [], 'warnings': []}
    mapping = {'coursecode': 'courseCode', 'subjectcode': 'courseCode', 'coursename': 'courseName',
               'subjectname': 'courseName', 'credits': 'credits', 'credit': 'credits',
               'facultyname': 'facultyName', 'faculty': 'facultyName', 'facultyid': 'facultyId',
               'category': 'category', 'slot': 'slot', 'room': 'room', 'seats': 'seats',
               'availableseats': 'seats', 'prerequisites': 'prerequisites', 'status': 'status',
               'semester': 'semester', 'section': 'section'}
    for table in soup.find_all('table'):
        caption = table.find('caption')
        heading = caption or table.find_previous(['h1', 'h2', 'h3', 'h4', 'legend'])
        label = heading.get_text(' ', strip=True).lower() if heading else ''
        if re.search(r'\b(?:offered|available)\s+courses\b|\bcourse\s+offerings\b', label):
            target = 'offerings'
        elif re.search(r'\bregistered\s+courses\b|\bcourses?\s+registered\b', label):
            target = 'registeredCourses'
        else:
            continue
        for row, _, _ in _table_rows(table, mapping, {'courseCode', 'courseName'}):
            if _CODE.fullmatch(row['courseCode']) and row['courseName']:
                output[target].append(row)
                if sum(len(output[key]) for key in ('registeredCourses', 'offerings')) >= MAX_ROWS:
                    break
    for node in soup.select('[role="alert"], .alert-warning, .warning'):
        text = node.get_text(' ', strip=True)
        if text and len(text) <= 1000 and text not in output['warnings']:
            output['warnings'].append(text)
        if len(output['warnings']) >= 20:
            break
    return output


def parse_examination_rows(html):
    output = []
    mapping = {'examname': 'name', 'examination': 'name', 'examinationname': 'name',
               'exam': 'name', 'coursename': 'name', 'subjectname': 'name',
               'examdate': 'date', 'examinationdate': 'date', 'date': 'date',
               'time': 'time', 'examtime': 'time', 'session': 'time', 'room': 'room',
               'venue': 'room', 'coursecode': 'courseCode', 'subjectcode': 'courseCode', 'status': 'status'}
    for table in BeautifulSoup(html, 'html.parser').find_all('table'):
        for row, _, _ in _table_rows(table, mapping, {'name', 'date'}):
            if not row['name'] or not row['date']:
                continue
            _source_date(row)
            output.append(row)
            if len(output) >= MAX_ROWS:
                return output
    return output


async def collect_source_modules(session, adapter):
    base = session.get('url') or adapter.BASE_URL
    html = session.get('dashboard_html', '')
    output = {'modules': [], 'fees': [], 'examinations': [], 'registeredCourses': [],
              'offerings': [], 'warnings': [], 'notes': []}
    checker = getattr(adapter, '_looks_like_student_page', None)
    if (not session.get('client') or not html or len(html.encode('utf-8')) > MAX_PAGE_BYTES
            or not _same_origin(base) or _login_or_error(html, adapter) or (checker and not checker(html))):
        return output
    identifiers = [session.get(k) for k in ('username', 'portalUsername', 'vtuNumber', 'studentId', 'rollNumber', 'registrationNumber') if session.get(k)]
    modules = discover_academic_pages(html, base, identifiers, include_modules=True)
    output['modules'] = [{**module, 'layoutSupported': False, 'status': 'not-loaded'} for module in modules]
    count = 0
    for module in output['modules']:
        if module['kind'] not in {'fees', 'examinations', 'course-registration'} or count >= MAX_PAGES:
            continue
        count += 1
        module['status'] = 'unavailable'
        try:
            response = await session['client'].get(module['url'], timeout=REQUEST_TIMEOUT, follow_redirects=False)
            content_type = response.headers.get('content-type', '').lower()
            if (response.status_code != 200 or not _same_origin(str(response.url))
                    or len(response.content) > MAX_PAGE_BYTES or _login_or_error(response.text, adapter)
                    or (content_type and not any(value in content_type for value in ('text/html', 'application/xhtml+xml')))):
                continue
            if module['kind'] == 'course-registration':
                parsed = parse_registration_page(response.text)
                for field, rows in parsed.items():
                    output[field].extend(rows)
                rows = parsed['registeredCourses'] + parsed['offerings']
            else:
                field = module['kind']
                rows = parse_fee_rows(response.text) if field == 'fees' else parse_examination_rows(response.text)
                output[field].extend(rows)
            module.update(layoutSupported=bool(rows), rowCount=len(rows),
                          status='available' if rows else 'unsupported', checkedAt=utc_now().isoformat())
            if not rows:
                output['notes'].append('An AMS section returned no supported labeled rows; previous records retained.')
        except httpx.HTTPError:
            output['notes'].append('An AMS section could not be fetched; previous records retained.')
    return output


def store_source_modules(db, student_id, source):
    now = utc_now()
    metadata = {'sourceModules': source.get('modules', []), 'sourceModulesCheckedAt': now}
    # Empty/unknown layouts do not erase earlier successful or imported sections.
    for incoming, field in (('registeredCourses', 'courses'), ('offerings', 'offerings'), ('warnings', 'registrationWarnings')):
        if source.get(incoming):
            rows = source[incoming]
            metadata[field] = ([{**row, 'source': 'ams', 'sourceUpdatedAt': now.isoformat()} for row in rows]
                               if incoming != 'warnings' else rows)
            metadata['registrationSourceUpdatedAt'] = now
    db.timetable_metadata.update_one({'studentId': student_id}, {'$set': metadata}, upsert=True)
    updates = {}
    for field in ('fees', 'examinations'):
        if source.get(field):
            updates[field] = [{**row, 'source': 'ams', 'sourceUpdatedAt': now.isoformat()} for row in source[field]][:MAX_ROWS]
    if updates:
        db.users.update_one({'_id': ObjectId(student_id)}, {'$set': updates})
