import test from 'node:test';
import assert from 'node:assert/strict';
import {parseTicketPayload,locationReading,createSampleForms,buildFormPayload} from '../src/lib/forms.js';
test('camera/manual check-in rejects wrong events and incomplete or oversized QR payloads',()=>{
 const ticket={eventId:'a'.repeat(24),registrationId:'b'.repeat(24),qrToken:'c'.repeat(64)};
 assert.deepEqual(parseTicketPayload(JSON.stringify(ticket),ticket.eventId),ticket);
 for(const raw of ['not json',JSON.stringify({...ticket,eventId:'d'.repeat(24)}),JSON.stringify({...ticket,qrToken:''}),'x'.repeat(5000)])assert.throws(()=>parseTicketPayload(raw,ticket.eventId));
});
test('browser location preserves timestamp and accuracy for server validation',()=>{
 assert.deepEqual(locationReading({coords:{latitude:13,longitude:80,accuracy:12},timestamp:1234}),{latitude:13,longitude:80,accuracy:12,capturedAt:1234});
});
test('form builder serializes typed options and empty conditions without proof bytes',()=>{
 const draft={title:'Feedback',description:'',scope:'department',department:'CSE',club:'',fields:[{id:'choice',label:'Choose',type:'select',required:true,options:'A\nB'}],state:'published',eventId:'',opensAt:'',closesAt:'',requireProof:true,requireRegistration:false,checkIn:false,locationEnabled:false};
 const result=buildFormPayload(draft);assert.deepEqual(result.fields[0].choices,['A','B']);assert.equal(result.geofence,null);assert.equal(result.eventId,null);
 const samples=createSampleForms();assert.ok(samples.every(x=>x.demo));assert.ok(samples[0].fields.length>1);
});
