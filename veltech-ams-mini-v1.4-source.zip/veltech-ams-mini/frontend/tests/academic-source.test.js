import test from 'node:test';
import assert from 'node:assert/strict';
import {academicDate,officialAmsUrl,safeAcademicUrl,sectionProvenance} from '../src/lib/academic-source.js';
test('official handoff permits only secure exact AMS origin, never lookalikes or credentials',()=>{
 assert.equal(officialAmsUrl('https://ams.veltech.edu.in/CourseRegistration.aspx'),'https://ams.veltech.edu.in/CourseRegistration.aspx');
 for(const value of ['javascript:alert(1)','https://ams.veltech.edu.in.evil.test/','https://user@ams.veltech.edu.in/','http://ams.veltech.edu.in/','https://ams.veltech.edu.in:444/'])assert.equal(officialAmsUrl(value),'');
 assert.equal(safeAcademicUrl('data:text/html,test'),'');
});
test('section provenance is independent for imports, AMS and missing results',()=>{
 const academic={source:'ams',updatedAt:'2026-10-14',courses:[{courseCode:'CS101'}],fees:[{amount:1250,source:'student-import',sourceUpdatedAt:'2026-10-15'}]};
 assert.equal(sectionProvenance(academic,'courses').source,'ams');
 assert.equal(sectionProvenance(academic,'fees').source,'student-import');
 assert.equal(sectionProvenance(academic,'results').source,'unavailable');
 assert.equal(sectionProvenance(academic,'results').status,'unavailable');
 assert.equal(sectionProvenance(academic,'fees','demo').source,'sample-preview');
});
test('unsupported discovered sections stay distinct from missing and available records',()=>{
 const academic={fees:[],sectionSources:{fees:{status:'unsupported',discovered:true,layoutSupported:false,recordCount:99,source:'unavailable'}}};
 const info=sectionProvenance(academic,'fees');assert.equal(info.status,'unsupported');assert.equal(info.recordCount,0);assert.equal(info.discovered,true);
});
test('source text dates survive ambiguous formatting without invented day/month interpretation',()=>{
 assert.equal(academicDate(null,'10/11/2026'),'10/11/2026');
 assert.equal(academicDate(null),'Not provided');
 assert.equal(academicDate('Source pending'),'Source pending');
 assert.match(academicDate('2026-10-15'),/15 Oct 2026/);
});
