import {Link,useParams} from 'react-router-dom';
import {ArrowLeft} from 'lucide-react';
import {useCampus} from '../context/CampusContext';
import {EmptyState,PageHeader} from '../components/UI';
import {entityId} from '../components/SocialComposer';
import {PostCard} from './Feed';
import './community-pages.css';
export default function SocialPost(){const {id}=useParams(),{data,loading}=useCampus(),post=data.posts.find(p=>entityId(p)===id);return <div className="v14-conversation-route"><Link className="v14-back-link" to="/community"><ArrowLeft size={16}/>Back to community</Link><PageHeader title="A thought worth sharing." description="Good conversations start with a little curiosity."/>{post?<PostCard post={post} conversation/>:loading?<p role="status">Loading conversation…</p>:<EmptyState title="This post is unavailable" description="It may have been removed or shared with a different audience."/>}</div>;}
