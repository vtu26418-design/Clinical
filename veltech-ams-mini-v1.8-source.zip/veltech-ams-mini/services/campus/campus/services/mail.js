import nodemailer from 'nodemailer';
export function createMailProvider(env=process.env) {
 const from=env.CAMPUS_MAIL_FROM || env.MAIL_FROM || env.SMTP_FROM;
 if(env.SMTP_HOST && from) {
  const port=Number(env.SMTP_PORT || 587);
  const transport=nodemailer.createTransport({host:env.SMTP_HOST,port,secure:env.SMTP_SECURE==='true' || port===465,
   requireTLS:env.SMTP_REQUIRE_TLS==='true',...(env.SMTP_USER?{auth:{user:env.SMTP_USER,pass:env.SMTP_PASS}}:{}),
   connectionTimeout:10000,greetingTimeout:10000,socketTimeout:15000});
  return {configured:true,async send({to,subject,text}) {await transport.sendMail({from,to,subject,text});}};
 }
 if(env.BREVO_API_KEY && from) {
  const match=from.match(/^(.*?)\s*<([^>]+)>$/),sender=match?{name:match[1].trim(),email:match[2]}:{email:from};
  return {configured:true,async send({to,subject,text}) {
   const response=await fetch('https://api.brevo.com/v3/smtp/email',{method:'POST',headers:{'api-key':env.BREVO_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({sender,to:[{email:to}],subject,textContent:text}),signal:AbortSignal.timeout(15000)});
   if(!response.ok) throw new Error('Mail provider rejected delivery');
  }};
 }
 return {configured:false,async send(){const error=new Error('Email delivery is not configured. Ask the administrator to configure SMTP or Brevo.');error.status=503;throw error;}};
}
