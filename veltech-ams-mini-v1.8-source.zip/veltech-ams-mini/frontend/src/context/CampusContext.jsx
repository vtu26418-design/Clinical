import {calendarDateRange,resolveAcademicDay} from '../lib/academic-calendar';
import {applyRoomOverrides} from '../lib/timetable';
import {loadWorkspace} from '../lib/workspace-loader';
import {setDownloadOwner} from '../lib/device-downloads';
import {createContext,useContext,useEffect,useLayoutEffect,useState,useCallback,useRef} from 'react';
import {createDemo,DEMO_DATE} from '../data/demo';
import {useAppPreferences} from './AppPreferences';
import {request,setCsrf,setApiOwner} from '../lib/api';
import {normalizeAcademic,campusDate,campusTime,attendanceStatus,recordForClass,sortClasses} from '../lib/attendance';
import {academicIssueSummary,syncMutationFeedback,syncProgressKey} from '../lib/sync-feedback';
import {createAccountGate,mergeCampusProfile,createDemoRegistrationService,cancelDemoRegistration} from '../lib/client-state';

const CampusContext=createContext(null),STORAGE='veltech-ams-mini:demo:v16';
function readDemo() {try {const d=JSON.parse(localStorage.getItem(STORAGE));if(d?.version===1 && d.profile && Array.isArray(d.events) && Array.isArray(d.posts)){if(!d.academic?.results?.some(r=>r.grade)){const sample=createDemo().academic;d.academic={...d.academic,results:sample.results,credits:sample.credits,gradeScale:sample.gradeScale,creditSummary:sample.creditSummary};}return d;}} catch {}return createDemo();}
const blank=()=>({profile:{campusRole:'student'},subjects:[],classes:[],records:[],academic:{},calendarPolicies:[],roomOverrides:[],notificationReady:{academic:false,social:false},events:[],registrations:[],placements:[],posts:[],people:[],notices:[],notifications:[]});
export function CampusProvider({children}) {
 const {preferences}=useAppPreferences();
 const [clock,setClock]=useState(()=>new Date());
 useEffect(()=>{const tick=()=>setClock(new Date()),timer=setInterval(tick,15000);document.addEventListener('visibilitychange',tick);return()=>{clearInterval(timer);document.removeEventListener('visibilitychange',tick);};},[]);
 const [sessionState,setSessionState]=useState('checking'),[sessionError,setSessionError]=useState('');
 const [mode,setMode]=useState('demo'),[demo,setDemo]=useState(readDemo),[live,setLive]=useState(blank),[loading,setLoading]=useState(false),[message,setMessage]=useState(null),[error,setError]=useState('');
 const liveRef=useRef(live);liveRef.current=live;
 const accountKey=useRef('demo:'+demo.profile.id);accountKey.current=`${mode}:${(mode==='demo'?demo.profile:live.profile).id || ''}`;
 const isCurrentAccount=useCallback(owner=>accountKey.current===owner,[]);
 const academicRevision=useRef(0),workspaceFailures=useRef(new Map());
 const clearFailure=path=>{workspaceFailures.current.delete(path);setError([...new Set(workspaceFailures.current.values())].join(' · '));};
 const gate=useRef(null),modeRef=useRef('demo'),demoRef=useRef(demo),authAbort=useRef(null),refreshAbort=useRef(null),restoration=useRef(null),demoRegistrations=useRef(null);
 if(!gate.current)gate.current=createAccountGate();
 const notify=useCallback((text,type='success')=>setMessage({text,type,id:Date.now()}),[]);
 useEffect(()=>{localStorage.setItem(STORAGE,JSON.stringify(demo));},[demo]);
 useEffect(()=>{if(!message)return;const timer=setTimeout(()=>setMessage(null),5500);return()=>clearTimeout(timer);},[message]);
 const clearAccount=useCallback((state='anonymous')=>{
  accountKey.current=`demo:${demoRef.current.profile.id || ''}`;academicRevision.current++;gate.current.invalidate();authAbort.current?.abort();refreshAbort.current?.abort();setCsrf('');setApiOwner('');setLive(blank());setLoading(false);modeRef.current='demo';setMode('demo');setError('');setSessionError('');setSessionState(state);workspaceFailures.current.clear();
 },[]);
 const applyAcademic=(previous,value,user=previous.profile)=>{
  const overview=normalizeAcademic(value);
  return {...previous,notificationReady:{...previous.notificationReady,academic:value.errors?.notifications?(previous.notificationReady?.academic===true?true:'failed'):true},profile:mergeCampusProfile(user,overview.profile),subjects:overview.subjects || [],records:overview.records || [],timetable:overview.timetable || [],academic:overview.academic || {},syncStatus:overview.syncStatus || overview.academic?.syncStatus || previous.syncStatus,notifications:[...(value.errors?.notifications?(previous.notifications || []).filter(n=>n.source==='academic'):(overview.notifications || []).map(n=>({...n,source:'academic'}))),...(previous.notifications || []).filter(n=>n.source==='social')],lastSyncedAt:overview.lastSyncedAt,academicError:'',academicErrors:overview.errors || {}};
 };
 const refresh=useCallback(async(user)=>{
  if(modeRef.current!=='connected' && !user)return;
  const run=gate.current.startRefresh(!!user);if(!run)return;
  refreshAbort.current?.abort();const abort=new AbortController();refreshAbort.current=abort;
  setLoading(true);setError('');workspaceFailures.current.clear();
  try {
   const auth=user?{user}:await request('/session',{signal:abort.signal,timeout:10000});
   if(!gate.current.currentRefresh(run))return;
   if(auth.csrfToken)setCsrf(auth.csrfToken);
   if(accountKey.current!==`connected:${auth.user.id}`){
    gate.current.invalidate();academicRevision.current++;accountKey.current=`connected:${auth.user.id}`;setApiOwner(auth.user.id);setLive({...blank(),profile:mergeCampusProfile(auth.user)});void refresh(auth.user);return;
   }
   const range=calendarDateRange(campusDate()),calendarPath='/academic-calendar?'+new URLSearchParams(range);
   const paths=['/academics/overview','/events','/registrations','/placements','/feed','/people','/notices','/notifications/inbox','/timetable-rooms',calendarPath];
   const keys={'/events':'events','/registrations':'registrations','/placements':'placements','/feed':'posts','/people':'people','/notices':'notices'};
   const failures=workspaceFailures.current;
   let overviewRevision;
   await loadWorkspace(paths,path=>{if(path==='/academics/overview')overviewRevision=++academicRevision.current;return request(path,{signal:abort.signal});},{isCurrent:()=>gate.current.currentRefresh(run),onValue:(path,value)=>{
    if(path==='/academics/overview'){
     if(overviewRevision!==academicRevision.current)return;
     setLive(previous=>applyAcademic(previous,value,auth.user));
     const issue=academicIssueSummary(value.errors);if(issue)failures.set(path,issue);else failures.delete(path);
    }else if(path==='/notifications/inbox')setLive(previous=>({...previous,notificationReady:{...previous.notificationReady,social:true},notifications:[...(previous.notifications || []).filter(n=>n.source==='academic'),...(Array.isArray(value)?value:[]).map(n=>({...n,read:n.read ?? n.isRead,source:'social'}))]}));
    else if(path==='/timetable-rooms')setLive(previous=>({...previous,roomOverrides:value.entries || []}));
    else if(path===calendarPath)setLive(previous=>({...previous,calendarPolicies:value.entries || []}));
    else if(keys[path])setLive(previous=>({...previous,[keys[path]]:Array.isArray(value)?value:[]}));
   },onFailure:(path,error)=>{if(path==='/academics/overview' && overviewRevision!==academicRevision.current)return;failures.set(path,error.message);if(path==='/academics/overview')setLive(previous=>({...previous,notificationReady:{...previous.notificationReady,academic:'failed'},academicError:error.message}));if(path==='/notifications/inbox')setLive(previous=>({...previous,notificationReady:{...previous.notificationReady,social:'failed'}}));}});
   if(gate.current.currentRefresh(run))setError([...new Set(failures.values())].join(' · '));
  }catch(e){if(gate.current.currentRefresh(run)){setError(e.message);if(e.status===401){clearAccount();notify('Your college session has expired. Sign in again.','error');}}}
  finally{if(gate.current.currentRefresh(run))setLoading(false);}
 },[notify,clearAccount]);

 useEffect(()=>{if(mode!=='connected' || !preferences.refreshSeconds)return;const id=setInterval(()=>{if(document.visibilityState!=='hidden')void refresh();},preferences.refreshSeconds*1000);return()=>clearInterval(id);},[mode,refresh,preferences.refreshSeconds]);
 useEffect(()=>{
  if(mode!=='connected' || !live.profile.id)return;
  const abort=new AbortController(),owner=`connected:${live.profile.id}`;let timer,working=false;
  const poll=async()=>{
   if(working || document.visibilityState==='hidden')return;
   working=true;let syncing=false;
   try{
    const status=await request('/academics/sync-status',{signal:abort.signal});
    if(abort.signal.aborted || !isCurrentAccount(owner))return;
    syncing=status.state==='syncing';
    const progress=syncProgressKey(status);
    if(progress!==syncProgressKey(liveRef.current.syncStatus || {})){
     const revision=++academicRevision.current;
     const overview=await request('/academics/overview',{signal:abort.signal});
     if(!abort.signal.aborted && isCurrentAccount(owner) && revision===academicRevision.current){const issue=academicIssueSummary(overview.errors);if(issue)workspaceFailures.current.set('/academics/overview',issue);else clearFailure('/academics/overview');setLive(previous=>({...applyAcademic(previous,overview),syncStatus:status}));}
    }else setLive(previous=>({...previous,syncStatus:status}));
   }catch{}finally{working=false;}
   if(!abort.signal.aborted && isCurrentAccount(owner))timer=setTimeout(poll,syncing?2000:30000);
  };
  const visible=()=>{if(document.visibilityState==='visible' && !working){clearTimeout(timer);void poll();}};
  timer=setTimeout(poll,live.syncStatus?.state==='syncing'?750:30000);document.addEventListener('visibilitychange',visible);
  return()=>{abort.abort();clearTimeout(timer);document.removeEventListener('visibilitychange',visible);};
 },[mode,live.profile.id,isCurrentAccount,live.syncStatus?.state==='syncing']);

 useEffect(()=>{
  if(mode!=='connected' || !live.profile.id)return;
  const abort=new AbortController(),owner=`connected:${live.profile.id}`;let timer,working=false;
  const poll=async()=>{
   if(working || document.visibilityState==='hidden')return;
   working=true;
   try{const rows=await request('/notifications/inbox',{signal:abort.signal});if(!abort.signal.aborted && isCurrentAccount(owner)){clearFailure('/notifications/inbox');setLive(previous=>({...previous,notificationReady:{...previous.notificationReady,social:true},notifications:[...(previous.notifications || []).filter(n=>n.source==='academic'),...(Array.isArray(rows)?rows:[]).map(n=>({...n,read:n.read ?? n.isRead,source:'social'}))]}));}}catch{}finally{working=false;}
  };
  const visible=()=>{if(document.visibilityState==='visible')void poll();};
  timer=setInterval(()=>void poll(),15000);document.addEventListener('visibilitychange',visible);
  return()=>{abort.abort();clearInterval(timer);document.removeEventListener('visibilitychange',visible);};
 },[mode,live.profile.id,isCurrentAccount]);

 const beginAccount=()=>{authAbort.current?.abort();authAbort.current=new AbortController();refreshAbort.current?.abort();setLoading(true);setError('');return {ticket:gate.current.beginAccount(),signal:authAbort.current.signal};};
 const connectAccount=async(path,options,success,supplied,restoring=false)=>{
  const {ticket,signal}=beginAccount();let adopted=false;
  if(restoring){setSessionState('checking');setSessionError('');}
  try {
   const result=supplied || await request(path,{...options,signal});if(!gate.current.currentAccount(ticket))return false;
   demoRegistrations.current?.invalidate();academicRevision.current++;setLive({...blank(),profile:mergeCampusProfile(result.user),syncStatus:result.syncStatus || null});accountKey.current=`connected:${result.user.id}`;setApiOwner(result.user.id);setCsrf(result.csrfToken);modeRef.current='connected';setMode('connected');setSessionState('ready');setSessionError('');
   adopted=true;void refresh(result.user);if(!gate.current.currentAccount(ticket))return false;if(success)notify(success);return true;
  }catch(e){if(!gate.current.currentAccount(ticket) || signal.aborted)return false;if(restoring){if(e.status===401)clearAccount();else {setSessionError('Check your connection and try again. Your college account may still be signed in.');setSessionState('error');}}throw e;}
  finally {if(gate.current.currentAccount(ticket)){gate.current.finishAccount(ticket);if(!adopted)setLoading(false);}}
 };
 const signIn=(identity,password)=>connectAccount('/login',{method:'POST',body:{identity,password}},'Signed in to your campus workspace');
 const resume=auth=>{
  if(auth)return connectAccount('/session',{},null,auth);
  if(restoration.current)return restoration.current;
  const work=connectAccount('/session',{timeout:10000},null,null,true);
  restoration.current=work;const clear=()=>{if(restoration.current===work)restoration.current=null;};work.then(clear,clear);return work;
 };
 useEffect(()=>{const reconcile=event=>{if(accountKey.current===`connected:${event.detail?.owner}`)void resume().catch(()=>{});};window.addEventListener('campus:account-changed',reconcile);return()=>window.removeEventListener('campus:account-changed',reconcile);},[]);
 useEffect(()=>{void resume().catch(()=>{});return()=>{gate.current.invalidate();authAbort.current?.abort();refreshAbort.current?.abort();restoration.current=null;};},[]);
 useEffect(()=>{if(sessionState!=='error')return;const retry=()=>{void resume().catch(()=>{});};window.addEventListener('online',retry);return()=>window.removeEventListener('online',retry);},[sessionState]);
 const switchDemo=()=>{clearAccount('demo');notify('Demo workspace · all student data is fictional');};
 const signOut=async()=>{
  const {ticket,signal}=beginAccount();
  try {if(modeRef.current==='connected' && 'serviceWorker' in navigator){try{const registration=await navigator.serviceWorker.getRegistration(),subscription=await registration?.pushManager?.getSubscription();if(subscription){await request('/academics/push/unsubscribe',{method:'DELETE',body:{endpoint:subscription.endpoint},signal});await subscription.unsubscribe();}}catch{/* Logout remains available if the academic service is down. */}}if(modeRef.current==='connected')await request('/logout',{method:'POST',body:{},signal});if(gate.current.currentAccount(ticket)){clearAccount();notify('Signed out of your college workspace');}}
  catch(e){if(gate.current.currentAccount(ticket)){if(e.status===401)clearAccount();else throw e;}}
  finally{if(gate.current.currentAccount(ticket)){gate.current.finishAccount(ticket);setLoading(false);}}
 };
 const updateDemo=useCallback(fn=>{const next=fn(structuredClone(demoRef.current));demoRef.current=next;setDemo(next);return next;},[]);
 if(!demoRegistrations.current)demoRegistrations.current=createDemoRegistrationService({getState:()=>demoRef.current,update:updateDemo,makeTicket:async event=>{
  const QRCode=await import('qrcode'),token='demo-'+crypto.randomUUID(),id='ticket-'+crypto.randomUUID();
  const qrCode=await QRCode.toDataURL(JSON.stringify({demo:true,registrationId:id,eventId:event.id,qrToken:token}));
  return {id,event,qrToken:token,qrCode,status:'registered',createdAt:new Date().toISOString()};
 }});
 const data=mode==='demo'?demo:live;
 useLayoutEffect(()=>{setDownloadOwner(mode==='connected'?String(live.profile.id || 'unavailable'):'demo');},[mode,live.profile.id]);
 const today=mode==='demo'?DEMO_DATE:campusDate(clock);
 const demoDays=['Monday','Tuesday','Wednesday','Thursday','Friday'];
 const rawTimetable=mode==='demo'?demoDays.flatMap((day,index)=>demo.classes.map((c,i)=>({...c,id:day+c.id,day,date:undefined,status:undefined,subjectName:index%2 && i===0?'Software Engineering':c.subjectName}))):live.timetable || [];
 const canonicalTimetable=mode==='demo'?rawTimetable.map(row=>{const found=(demo.academic?.courses || []).filter(course=>course.name===row.subjectName);return {...row,source:'demo',subjectCode:row.subjectCode || (found.length===1?found[0].code:'')};}):rawTimetable;
 const baseTimetable=applyRoomOverrides(canonicalTimetable,data.roomOverrides || [],mode==='demo'?data.profile.department:data.profile.campusDepartment || '');
 const calendarPolicies=mode==='demo'?(demo.calendarPolicies || []).filter(p=>p.scope==='college' || p.scope==='department' && p.department===demo.profile.department || p.scope==='students' && p.studentIds?.includes(demo.profile.id)):live.calendarPolicies || [];
 const dayInfo=resolveAcademicDay({date:today,classes:baseTimetable,policies:calendarPolicies});
 const classes=sortClasses(dayInfo.classes.map(c=>{
  const record=recordForClass(c,data.records || [],dayInfo.classes,today),entry={...c,date:today,status:record?.status};
  return {...entry,status:attendanceStatus(entry,today,campusTime(clock))};
 }));

 async function mutate(path,body,method='POST',success='Updated') {const value=await request(path,{method,body});await refresh();const feedback=syncMutationFeedback(value,success);notify(feedback.text,feedback.type);return value;}
 async function register(event,details={}) {
  if(mode==='connected')return mutate(`/events/${event.id}/register`,details,'POST',event.pricePaise?'Payment order created. Your ticket awaits verified payment.':'You’re registered. Your ticket is ready.');
  const ticket=await demoRegistrations.current.register(event.id);notify('Demo registration saved. Your sample ticket is ready.');return ticket;
 }
 async function cancel(ticket) {
  if(mode==='connected')return mutate(`/registrations/${ticket.id}/cancel`,{},'POST','Registration cancelled');
  updateDemo(d=>{cancelDemoRegistration(d,ticket.id);return d;});notify('Demo registration cancelled');
 }
 async function postAction(post,action,body) {
  if(mode==='connected')return mutate(`/feed/${post.id}/${action}`,body,action==='comments'?'POST':'PUT',action==='comments'?'Comment posted':'Updated');
  updateDemo(d=>{const p=d.posts.find(p=>p.id===post.id);if(action==='like'){p.likes+=body.liked?1:-1;p.liked=body.liked;}if(action==='save')p.saved=body.saved;if(action==='comments')p.comments.push({id:crypto.randomUUID(),author:{name:d.profile.socialName || d.profile.name},text:body.text});return d;});
 }
 async function compose(body) {
  if(mode==='connected')return mutate('/feed',body,'POST','Post shared with campus');
  updateDemo(d=>{d.posts.unshift({id:crypto.randomUUID(),author:{id:d.profile.id,name:d.profile.socialName || d.profile.name,image:d.profile.socialImage || d.profile.photo,socialDepartment:d.profile.socialDepartment},...body,createdAt:new Date().toISOString(),likes:0,liked:false,saved:false,comments:[]});return d;});notify('Your demo post is shared');
 }
 async function editPost(post,text) {
  if(mode==='connected')return mutate(`/feed/${post.id}`,{text},'PATCH','Post updated');
  updateDemo(d=>{const found=d.posts.find(p=>p.id===post.id);if(found?.author.id!==d.profile.id)throw new Error('Only the author can edit this post');found.text=text.trim();return d;});notify('Demo post updated');
 }
 async function deletePost(post) {
  if(mode==='connected')return mutate(`/feed/${post.id}`,{},'DELETE','Post removed');
  updateDemo(d=>{const found=d.posts.find(p=>p.id===post.id);if(found?.author.id!==d.profile.id)throw new Error('Only the author can remove this post');d.posts=d.posts.filter(p=>p.id!==post.id);return d;});notify('Demo post removed');
 }
 async function saveEvent(event) {
  if(mode==='connected')return mutate(`/events/${event.id}/save`,{saved:!event.saved},'PUT',event.saved?'Event bookmark removed':'Event bookmarked');
  updateDemo(d=>{const found=d.events.find(e=>e.id===event.id);found.saved=!found.saved;return d;});notify('Demo event bookmarks updated');
 }
 async function follow(person) {
  if(mode==='connected')return mutate(`/connections/${person.id}`,{},person.following || person.requestStatus==='requested'?'DELETE':'POST','Connection updated');
  updateDemo(d=>{const p=d.people.find(p=>p.id===person.id);p.following=!p.following;return d;});
 }
 async function placementAction(job,action,body) {
  if(mode==='connected')return mutate(`/placements/${job.id}/${action}`,body,'PUT','Opportunity updated');
  updateDemo(d=>{const p=d.placements.find(p=>p.id===job.id);if(action==='save')p.saved=body.saved;else p.application=body.status;return d;});notify(action==='application'?'Demo application tracking updated':'Saved opportunities updated');
 }
 const value={clock,time:campusTime(clock),mode,sessionState,sessionError,isCurrentAccount,data:{...data,timetable:baseTimetable,calendarPolicies,dayInfo,classes},today,loading,error,message,notify,refresh,signIn,resume,signOut,switchDemo,updateDemo,register,cancel,postAction,compose,editPost,deletePost,saveEvent,follow,placementAction,mutate,resetDemo:()=>{demoRegistrations.current.invalidate();demoRef.current=createDemo();setDemo(demoRef.current);notify('Demo data reset');}};
 return <CampusContext.Provider value={value}>{children}</CampusContext.Provider>;
}
export function useCampus() {return useContext(CampusContext);}
