import {useEffect,useId,useMemo,useRef,useState} from 'react';
import {ChevronDown,Download,TrendingUp,GraduationCap,FileText,Search,Percent,RotateCcw} from 'lucide-react';
import {prepareResults,resultSemesters,resultMetrics,resultReportGroups,resultTrend,resultAssessmentFields,resultReportLabel,filterResults,publishedResultSummary,hasResultMark,resultAssessmentTrends} from '../lib/academic-results';
import {createResultsReport,resultsPdf,resultsXlsx} from '../lib/results-export';
import {downloadFile} from '../lib/download';
import {Field,Button,EmptyState} from './UI';
import GpaCalculator from './GpaCalculator';
import '../academic-results.css';

const marks=resultAssessmentFields;
const reportName=resultReportLabel;
const format=value=>value===null?'—':value.toFixed(2);

function PerformanceGraph({points,title,assessment=false,chooseAssessment=false}){
 const unit=assessment?'marks':'grade points';
 const plot=useRef(null),gradient=useId().replaceAll(':',''),instructions=useId();
 const [width,setWidth]=useState(600),[active,setActive]=useState(()=>Math.max(0,points.findLastIndex(point=>point.value!==null)));
 const available=points.filter(point=>point.value!==null),hasValues=available.length>0;
 useEffect(()=>{
  if(!plot.current)return;
  const observer=new ResizeObserver(([entry])=>setWidth(Math.max(340,Math.round(entry.contentRect.width))));
  observer.observe(plot.current);return()=>observer.disconnect();
 },[hasValues]);
 const left=36,right=width-14,top=16,bottom=184,maximum=Math.ceil(Math.max(1,...available.map(point=>point.value))/2)*2;
 const x=index=>points.length<2?(left+right)/2:left+index*(right-left)/(points.length-1),y=value=>bottom-value/maximum*(bottom-top);
 useEffect(()=>{
  const node=plot.current,scroller=node?.parentElement;
  if(!node || !scroller || !hasValues)return;
  const position=(points.length<2?(left+right)/2:left+active*(right-left)/(points.length-1))*node.clientWidth/width;
  if(position<scroller.scrollLeft+28)scroller.scrollLeft=Math.max(0,position-28);
  else if(position>scroller.scrollLeft+scroller.clientWidth-28)scroller.scrollLeft=position-scroller.clientWidth+28;
 },[active,width,hasValues,points.length,left,right]);
 const current=points[active] || points[0],segments=[];
 for(let index=0;index<points.length;index++){
  if(points[index].value===null)continue;
  if(index===0 || points[index-1].value===null)segments.push([]);
  segments.at(-1).push({x:x(index),y:y(points[index].value)});
 }
 function selectPointer(event){
  const rect=event.currentTarget.getBoundingClientRect(),position=(event.clientX-rect.left)/rect.width*width;
  setActive(points.length<2?0:Math.max(0,Math.min(points.length-1,Math.round((position-left)/(right-left)*(points.length-1)))));
 }
 function selectKey(event){
  const actions={ArrowLeft:Math.max(0,active-1),ArrowRight:Math.min(points.length-1,active+1),Home:0,End:points.length-1};
  if(Object.hasOwn(actions,event.key)){event.preventDefault();setActive(actions[event.key]);}
 }
 const valueText=current?`${current.label}: ${current.value===null?'numeric value unavailable':`${format(current.value)} ${unit}`}`:'';
 return <figure className="performance-graph">
  <figcaption><span><TrendingUp size={18}/>{title}</span><small>{assessment?'Source assessment marks':'Source grade points'}</small></figcaption>
  {hasValues?<>
   <div className="performance-readout"><div><strong>{format(current?.value??null)}</strong><span>{current?.label}{current?.contextLabel?<small>{current.contextLabel}</small>:null}</span></div><small>{current?.detail || `Explicit source ${unit}`}{current?.value===null?' · Numeric value unavailable':''}</small></div>
   <p className="performance-axis-label">{assessment?'Score · raw marks':'Grade points'}</p><div className="performance-scroll"><div ref={plot} className="performance-plot" tabIndex={0} role="slider" aria-label={`${title}; selected data point`} aria-orientation="horizontal" aria-valuemin={1} aria-valuemax={points.length} aria-valuenow={active+1} aria-valuetext={valueText} aria-describedby={instructions} onKeyDown={selectKey} onPointerMove={selectPointer} onPointerDown={selectPointer}>
    <svg viewBox={`0 0 ${width} 222`} role="img" aria-label={title}>
     <title>{title}</title><desc>Only explicit numeric source values are plotted. Missing values leave gaps.</desc>
     <defs><linearGradient id={gradient} x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#0a66c2" stopOpacity=".2"/><stop offset="100%" stopColor="#0a66c2" stopOpacity=".015"/></linearGradient></defs>
     {[0,.25,.5,.75,1].map(value=><g key={value}><line x1={left} x2={right} y1={y(value*maximum)} y2={y(value*maximum)} stroke="#e2eaf3" strokeDasharray="3 5"/><text x={left-9} y={y(value*maximum)+4} textAnchor="end" fontSize="12" fill="#72849b">{Number((value*maximum).toFixed(1))}</text></g>)}
     {segments.map((segment,index)=>{const line=segment.map((point,i)=>`${i?'L':'M'}${point.x},${point.y}`).join(' ');return <g key={index}>{segment.length>1?<path d={`${line} L${segment.at(-1).x},${bottom} L${segment[0].x},${bottom} Z`} fill={`url(#${gradient})`}/>:null}<path d={line} fill="none" stroke="#0a66c2" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round"/></g>;})}
     {points.map((point,index)=>point.value!==null?<circle key={index} cx={x(index)} cy={y(point.value)} r={index===active?5:3} fill={index===active?'#0a66c2':'white'} stroke="#0a66c2" strokeWidth="2"/>:null)}
     {points.map((point,index)=>point.value!==null && (points.length<=8 || index===active)?<text key={'score'+index} x={Math.max(left+10,Math.min(right-12,x(index)))} y={Math.max(top+12,y(point.value)-10)} textAnchor="middle" fontSize="12" fontWeight="600" fill="#164878">{Number(point.value.toFixed(2))}</text>:null)}
     {current?<line x1={x(active)} x2={x(active)} y1={top} y2={bottom} stroke="#0a66c2" strokeOpacity=".35" strokeDasharray="3 4"/>:null}
     {points.map((point,index)=>index%Math.max(1,Math.ceil(points.length/(width<340?3:6)))===0 || index===points.length-1?<text key={index} x={x(index)} y="208" textAnchor={index===0?'start':index===points.length-1?'end':'middle'} fontSize="12" fill="#62758c">{point.shortLabel || point.label.slice(0,12)}</text>:null)}
    </svg>
   </div>
   </div><div className="performance-legend"><span><i/>Numeric source values</span><small id={instructions}>Hover, tap or use arrow keys</small></div>
   {points.some(point=>point.value===null)?<p className="performance-note">{assessment?'Gaps indicate missing or non-numeric source marks. Marks from different assessments are never combined.':'Gaps indicate missing credits or grade points, or repeated course attempts. No value is estimated.'}</p>:null}
  </>:<div className="performance-unavailable"><span><TrendingUp size={26}/></span><strong>{chooseAssessment?'Choose an assessment to see its trend':'A numeric trend is not available'}</strong><p>{chooseAssessment?'Select a test, mid-test, lab, assignment or final internal above. Each source mark uses its own scale.':assessment?'This selection has no numeric source marks for the chosen assessment. Original marks remain visible in the reports below.':'AMS has not supplied complete credits and numeric grade points for this selection. Letter grades are shown in the reports below.'}</p></div>}
 </figure>;
}

function ResultReport({group,view,index,assessment}){
 const fields=Object.entries(marks).filter(([field])=>(assessment==='all' || assessment===field) && group.rows.some(row=>hasResultMark(row,field)));
 return <details className="academic-report" open={index===0}>
  <summary><span className="academic-report-icon"><FileText size={17}/></span><span className="academic-report-title"><strong>{group.report}</strong><small>{group.semester?`Semester ${group.semester}`:'Semester not provided'}{group.session?` · ${group.session}`:''}{group.sourceReport && group.sourceReport!==group.report?` · ${group.sourceReport}`:''}</small></span><span className="academic-report-count">{group.rows.length} {group.rows.length===1?'record':'records'}</span><ChevronDown size={17} className="academic-report-chevron"/></summary>
  <div className="table-scroll"><table className="academic-detail-table" style={view==='assessments'?{minWidth:Math.max(280,195+fields.length*80)}:undefined}><caption className="sr-only">{group.report}, {group.semester?`Semester ${group.semester}`:'semester not provided'}{group.session?`, ${group.session}`:''}{group.sourceReport?`, ${group.sourceReport}`:''}</caption><thead><tr><th>Course / subject</th>{view==='grades'?<><th>Result</th><th>Grade</th><th>Credits</th><th>Grade points</th></>:fields.length?fields.map(([field,label])=><th key={field}>{label}</th>):<th>Source marks</th>}</tr></thead><tbody>{group.rows.map((row,index)=><tr key={`${row.courseCode}:${index}`}><td><strong>{row.courseName || row.courseCode || 'Course not provided'}</strong><small className="result-course-code">{row.courseCode}</small></td>{view==='grades'?<><td>{row.status || '—'}</td><td><b className="result-grade">{row.grade}</b></td><td>{row.credits??'—'}</td><td>{row.gradePoints??'—'}</td></>:fields.length?fields.map(([field])=><td className="result-assessment-value" key={field}>{hasResultMark(row,field)?row[field]:'—'}</td>):<td>Marks not provided by source</td>}</tr>)}</tbody></table></div>
 </details>;
}

export default function ResultsDashboard({results=[],credits=[],gradeScale=[],creditSummary=[],mode='connected',accountKey=''}){
 const queryId=useId();
 const [semester,setSemester]=useState('all'),[view,setView]=useState('grades'),[exam,setExam]=useState('all'),[kind,setKind]=useState('all'),[query,setQuery]=useState(''),[assessment,setAssessment]=useState('all'),[graphField,setGraphField]=useState(''),[exportError,setExportError]=useState('');
 const prepared=useMemo(()=>prepareResults(results,mode==='connected'?credits.filter(row=>row.source==='ams'):credits,gradeScale),[results,credits,gradeScale,mode]);
 const pool=view==='grades'?prepared.grades:prepared.assessments;
 const reports=[...new Set(pool.map(reportName))],reportRows=filterResults(pool,{report:kind});
 const semesters=resultSemesters(reportRows),semesterRows=filterResults(reportRows,{semester});
 const exams=[...new Set(semesterRows.map(row=>row.examinationSession).filter(Boolean))];
 const availableAssessments=Object.entries(marks).filter(([field])=>pool.some(row=>hasResultMark(row,field)));
 const filters={report:kind,semester,session:exam,query,assessment:view==='assessments'?assessment:'all'};
 const selected=filterResults(pool,filters),groups=resultReportGroups(selected),current=resultMetrics(selected),published=publishedResultSummary(creditSummary);
 const assessmentGraphs=resultAssessmentTrends(selected),graphedField=assessment!=='all'?assessment:assessmentGraphs.some(series=>series.field===graphField)?graphField:assessmentGraphs[0]?.field || '';
 const graph=view==='grades'?resultTrend(selected,semester):assessmentGraphs.find(series=>series.field===graphedField)?.points || [],latestScore=graph.findLast(point=>point.value!==null);
 const distribution=[...selected.reduce((counts,row)=>{if(row.grade)counts.set(String(row.grade),(counts.get(String(row.grade)) || 0)+1);return counts;},new Map())];
 const filtered=semester!=='all' || kind!=='all' || exam!=='all' || query.trim() || assessment!=='all';
 function resetFilters(){setSemester('all');setExam('all');setKind('all');setQuery('');setAssessment('all');setExportError('');}
 function changeView(value){setView(value);resetFilters();}
 function exportReport(type){
  try{
   const report=createResultsReport({rows:selected,filters,view,summary:creditSummary,mode});
   const filename=`veltech-ams-results-${view}-semester-${semester.replace(/[^a-z0-9_-]/gi,'_')}`;
   downloadFile(`${filename}.${type}`,type==='pdf'?resultsPdf(report):resultsXlsx(report),type==='pdf'?'application/pdf':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');setExportError('');
  }catch(error){setExportError(error.message || 'The report could not be exported. Try another selection.');}
 }
 return <div className="results-dashboard">
  <div className="results-overall">
   <div><span><GraduationCap size={16}/>Overall CGPA</span><strong>{format(published.cgpa)}</strong><small>{published.cgpa!==null?'As explicitly published by the source':'Not published in the available source summary'}</small></div>
   <div><span><Percent size={15}/>Overall percentage</span><strong>{published.percentage===null?'—':`${format(published.percentage)}%`}</strong><small>{published.percentage!==null?'As explicitly published by the source':'Awaiting a published percentage or confirmed formula'}</small></div>
   <div><span>{view==='grades'?'Selected source average':'Latest plotted score'}</span><strong>{view==='grades'?format(current.complete?current.value:null):format(latestScore?.value??null)}</strong><small>{view==='grades'?current.complete?`Credit-weighted · ${current.credits} source credits`:'Complete, unambiguous credits and grade points required':latestScore?`${marks[graphedField]} · ${latestScore.label}`:'No numeric marks in this selection'}</small></div>
   <div><span>Selected records</span><strong>{selected.length}</strong><small>{groups.length} report divisions · {resultSemesters(selected).length} source semesters</small></div>
  </div>
  <div className="academic-view-switch" role="group" aria-label="Result record category"><button type="button" aria-pressed={view==='grades'} onClick={()=>changeView('grades')}>Final results<span>{prepared.grades.length}</span></button><button type="button" aria-pressed={view==='assessments'} onClick={()=>changeView('assessments')}>Assessment & internal<span>{prepared.assessments.length}</span></button></div>
  <div className="results-filters">
   <Field label="Source report"><select value={kind} onChange={event=>{setKind(event.target.value);setSemester('all');setExam('all');}}><option value="all">{view==='grades'?'All final result reports':'All assessment reports'}</option>{reports.map(report=><option key={report} value={report}>{report} ({pool.filter(row=>reportName(row)===report).length})</option>)}</select></Field>
   <Field label="Semester"><select value={semester} onChange={event=>{setSemester(event.target.value);setExam('all');}}><option value="all">All source semesters</option>{semesters.map(label=><option key={label} value={label}>Semester {label}</option>)}</select></Field>
   {exams.length?<Field label="Examination session"><select value={exam} onChange={event=>setExam(event.target.value)}><option value="all">All examination sessions</option>{exams.map(session=><option key={session} value={session}>{session}</option>)}</select></Field>:null}
   {view==='assessments'?<Field label="Assessment"><select value={assessment} onChange={event=>setAssessment(event.target.value)}><option value="all">All assessment fields</option>{availableAssessments.map(([field,label])=><option key={field} value={field}>{label}</option>)}</select></Field>:null}
   <div className="field"><label htmlFor={queryId}>Search subject</label><span className="results-subject-search"><Search size={15}/><input id={queryId} aria-label="Search subject" type="search" placeholder="Course name or code" value={query} onChange={event=>setQuery(event.target.value)}/></span></div>
  </div>
  <div className="results-selection-status"><p role="status">{selected.length} of {pool.length} {view==='grades'?'final result':'assessment'} records{semester!=='all'?` · Semester ${semester}`:''}{query.trim()?` · Matching “${query.trim()}”`:''}</p>{filtered?<button type="button" onClick={resetFilters}><RotateCcw size={12}/>Reset filters</button>:null}</div>
  {view==='assessments' && assessment==='all' && assessmentGraphs.length?<div className="results-graph-controls"><Field label="Assessment graph"><select value={graphedField} onChange={event=>setGraphField(event.target.value)}>{assessmentGraphs.map(series=><option key={series.field} value={series.field}>{series.label}</option>)}</select></Field><span>Raw marks · one assessment at a time</span></div>:null}
  <PerformanceGraph key={JSON.stringify([view,kind,semester,exam,assessment,graphedField,query,graph.map(point=>point.label)])} points={graph} assessment={view==='assessments'} chooseAssessment={false} title={view==='assessments'?(`${marks[graphedField] || 'Assessment'} · subject performance`):semester==='all'?'Semester performance':`Semester ${semester} · course performance`}/>
  {view==='grades' && !graph.some(point=>point.value!==null) && distribution.length?<div className="result-distribution"><span>Source grade distribution</span><div>{distribution.map(([grade,count])=><span key={grade}><b>{grade}</b>{count} {count===1?'record':'records'}</span>)}</div></div>:null}
  {view==='assessments'?<p className="academic-report-explanation">Tests, mid-tests, lab, assignments and final internal marks have separate columns. Each report retains the original semester, source marks and examination session.</p>:null}
  <div className="academic-record-heading"><div><h3>{view==='grades'?'Final result reports':'Assessment reports'}</h3><p>{selected.length} records · {groups.length} {groups.length===1?'report division':'report divisions'}</p></div><div className="results-export-actions"><Button variant="secondary" disabled={!selected.length} onClick={()=>exportReport('xlsx')}><Download size={15}/>Export Excel</Button><Button variant="secondary" disabled={!selected.length || semester==='all'} onClick={()=>exportReport('pdf')}><FileText size={15}/>Semester PDF</Button></div></div>
  <p className="results-export-note">{semester==='all'?'Select a semester to download its PDF report. ':''}Downloads follow every active filter. Excel keeps source reports on separate sheets.</p>
  {exportError?<p className="results-export-error" role="alert">{exportError}</p>:null}
  {groups.length?<div className="academic-report-list">{groups.map((group,index)=><ResultReport key={group.key} group={group} view={view} assessment={assessment} index={index}/>)}</div>:<EmptyState title={query.trim()?'No subjects match your search':'No results in this selection'} description={query.trim()?'Try a course code, a shorter subject name or reset your filters.':'Choose another semester, source report or assessment to view available records.'} action={filtered?'Reset filters':undefined} onAction={resetFilters}/>}
  <p className="page-footnote">Reports retain the semester, source report and examination session supplied by AMS. The source average uses explicit credits and grade points, with no inferred grade scale. Repeated or incomplete records prevent a complete average. Your official transcript remains authoritative.</p>
  <GpaCalculator results={prepared.grades} mode={mode} accountKey={accountKey}/>
 </div>;
}
