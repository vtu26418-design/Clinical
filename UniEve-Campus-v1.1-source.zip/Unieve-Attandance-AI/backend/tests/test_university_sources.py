import unittest
from app.services.university_sources import parse_news
class SourceNewsTests(unittest.TestCase):
 def test_only_official_news_links_are_published_and_duplicates_are_removed(self):
  html='<a href="/events/campus-2026/">University campus event for students</a><a href="/events/campus-2026/">University campus event for students</a><a href="https://attacker.example/events/x">External event pretending to be news</a><a href="javascript:alert(1)">Not an official university event</a>'
  items=parse_news(html);self.assertEqual(len(items),1);self.assertTrue(items[0]['url'].startswith('https://www.veltech.edu.in/'))
