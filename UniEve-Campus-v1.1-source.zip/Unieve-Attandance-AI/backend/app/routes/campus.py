"""Private, read-only campus overview of existing per-student source records."""
from fastapi import APIRouter, Depends, HTTPException
from pymongo.database import Database
from app.config.database import get_db
from app.security.permissions import get_current_user
from app.services.base import serialize_document
from app.scheduler.attendance_sync import AttendanceSyncRunner
from pydantic import BaseModel, Field
from app.security.permissions import require_student
from app.security.portal_credentials import decrypt_portal_password
from app.services.ams.ams_adapter import AmsAdapter, AmsAuthenticationError
from app.services.ams.manual_session import prepare_challenge, take_challenge
from app.services.student_service import StudentService
from app.services.timetable_service import TimetableService
from app.services.university_sources import source_status, public_news

router = APIRouter(prefix="/campus", tags=["campus"])

PROFILE_FIELDS = (
    "name", "email", "vtuNumber", "rollNumber", "phoneNumber", "branch",
    "degree", "year", "semester", "section", "batch", "mentorName", "photoUrl",
    "gender", "dateOfBirth", "fatherName", "motherName", "parentName", "parentPhone",
    "academicBankCreditsId", "portalSynced", "lastSyncedAt", "source",
)

@router.get('/sources')
async def sources():
    return await source_status()

@router.get('/news')
async def news():
    try:
        return await public_news()
    except Exception:
        raise HTTPException(502, 'The official university website could not be fetched. Please retry.')

@router.post('/ams/challenge')
async def ams_challenge(current_user: dict = Depends(require_student)):
    try:
        return await prepare_challenge(str(current_user['id']))
    except Exception:
        raise HTTPException(502, 'Could not load the official AMS challenge. Check the portal connection and retry.')

class AmsSyncInput(BaseModel):
    challengeId: str = Field(min_length=20,max_length=100)
    answer: str = Field(min_length=1,max_length=30)

@router.post('/ams/sync')
async def ams_sync(body: AmsSyncInput, current_user: dict = Depends(require_student), db: Database = Depends(get_db)):
    if not current_user.get('portalPasswordEncrypted') or not current_user.get('portalUsername'):
        raise HTTPException(409,'Save your own portal connection before syncing AMS.')
    try:
        prepared=await take_challenge(str(current_user['id']),body.challengeId)
    except ValueError as error:
        raise HTTPException(409,str(error))
    adapter=AmsAdapter();session=None
    try:
        password=decrypt_portal_password(current_user['portalPasswordEncrypted'])
        session=await adapter.login(current_user['portalUsername'],password,captcha=body.answer,prepared=prepared)
        profile=await adapter.get_student_profile(session)
        if not profile:raise ValueError('No student profile was returned.')
        StudentService(db)._save_ams_profile(str(current_user['id']),profile)
        await TimetableService(db,ams_adapter=adapter).sync_timetable(str(current_user['id']),session,profile=profile)
        return {'success':True,'source':'ams','partial':True,'errors':['AMS profile and timetable synced. Attendance needs the currently unavailable Home of Vel Tech source.']}
    except AmsAuthenticationError:
        raise HTTPException(400,'AMS did not accept the login or CAPTCHA. Load a fresh challenge and check your credentials.')
    except Exception:
        raise HTTPException(502,'AMS data could not be fetched completely. Existing records were preserved; check the source and retry.')
    finally:
        if session:
            await adapter.logout(session)
        else:
            await prepared['client'].aclose()

@router.get("/snapshot")
def snapshot(current_user: dict = Depends(get_current_user), db: Database = Depends(get_db)):
    student_id = str(current_user["id"])
    # Authentication already resolves this student's own document; caller supplies no ID.
    profile = {field: current_user.get(field) for field in PROFILE_FIELDS if current_user.get(field) is not None}
    metadata = db["timetable_metadata"].find_one({"studentId": student_id}) or {}
    source_profile = metadata.get("profile", {})
    if isinstance(source_profile, dict):
        for key in ("batch", "mentorName", "semester", "branch", "rollNumber", "degree"):
            if not profile.get(key) and source_profile.get(key):
                profile[key] = source_profile[key]
    academic = {"bucket": metadata.get("bucket"), "courses": metadata.get("courses", []),
                "updatedAt": metadata.get("updatedAt"), "source": metadata.get("source")}
    # Only display additional academic modules when present in the source database.
    for field in ("results", "examinations", "fees", "documents", "requests"):
        if current_user.get(field) is not None:
            academic[field] = current_user[field]
    return serialize_document({"profile": profile, "academic": academic})

@router.post("/sync")
async def sync(current_user: dict = Depends(get_current_user), db: Database = Depends(get_db)):
    if current_user.get("role") != "student":
        raise HTTPException(status_code=403, detail="Student account required for portal sync")
    if not current_user.get("portalPasswordEncrypted") or not current_user.get("portalUsername"):
        raise HTTPException(status_code=409, detail="Configure your own portal credentials before syncing")
    result = await AttendanceSyncRunner(db).sync_single_student(str(current_user["id"]))
    if not result.get("success"):
        raise HTTPException(status_code=502, detail="Portal sync did not complete. Check the portal connection and account credentials.")
    return {"success": True, "recordsProcessed": result.get("recordsProcessed", 0)}
