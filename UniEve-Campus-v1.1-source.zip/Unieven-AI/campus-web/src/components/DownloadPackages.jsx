import {useEffect,useState} from 'react';
import {Download,FileArchive,FileText,RefreshCw} from 'lucide-react';
import {request} from '../lib/api';
import {Button,SectionTitle,Feedback} from './UI';
export default function DownloadPackages() {
 const [items,setItems]=useState([]),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const load=async()=>{setBusy(true);setError('');try {setItems((await request('/downloads')).items);}catch(e){setError(e.message);}finally{setBusy(false);}};
 useEffect(()=>{void load();},[]);
 return <section className="panel settings-section"><SectionTitle title="Project downloads"/><p className="body-copy">Download the portable source, installable web/mobile build and setup guide. Packages exclude account credentials and private student data.</p><div className="download-package-list">{items.map(item=><div key={item.id}><span className="download-package-icon">{item.id==='guide'?<FileText size={25}/>:<FileArchive size={25}/>}</span><div><h3>{item.label}</h3><small className="muted">{item.available?`${item.bytes<1048576?`${Math.ceil(item.bytes/1024)} KB`:`${(item.bytes/1048576).toFixed(1)} MB`} · ready to download`:'Package not found on this server'}</small></div>{item.available?<a className="button secondary" href={item.url} download><Download size={16}/>Download</a>:null}</div>)}</div><Feedback error={error}/><Button variant="ghost" busy={busy} onClick={load}><RefreshCw size={15}/>Refresh downloads</Button><p className="page-footnote">Downloads require the campus API. A static demo preview alone cannot serve source packages. These files do not deploy an HTTPS app or configure university access.</p></section>;
}
