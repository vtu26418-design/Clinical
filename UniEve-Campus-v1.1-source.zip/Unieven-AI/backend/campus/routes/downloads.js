import path from 'node:path';
import fs from 'node:fs';
export function registerDownloads(router,options={}) {
 const dist=options.dist || process.env.CAMPUS_WEB_DIST || path.resolve('campus-web/dist');
 const directory=options.directory || process.env.CAMPUS_DOWNLOAD_DIR || path.resolve(dist,'../../../artifacts');
 const files=[{id:'source',label:'Campus V1.1 · complete source',filename:'UniEve-Campus-v1.1-source.zip',type:'application/zip'},{id:'mobile-web',label:'Campus V1.1 · mobile and web app',filename:'UniEve-Campus-v1.1-mobile-web.zip',type:'application/zip'},{id:'guide',label:'Setup guide',filename:'UniEve-Campus-v1.1-setup.md',type:'text/markdown; charset=utf-8'}];
 router.get('/downloads',(_req,res)=>res.json({items:files.map(file=>{const target=path.join(directory,file.filename),available=fs.existsSync(target)&&fs.statSync(target).isFile();return {id:file.id,label:file.label,available,bytes:available?fs.statSync(target).size:0,url:`/api/campus/downloads/${file.id}`};})}));
 router.get('/downloads/:id',(req,res)=>{const file=files.find(file=>file.id===req.params.id);if(!file)return res.status(404).json({message:'Download not found'});const target=path.join(directory,file.filename);if(!fs.existsSync(target))return res.status(404).json({message:'Package has not been generated on this server'});res.type(file.type).download(target,file.filename);});
}
