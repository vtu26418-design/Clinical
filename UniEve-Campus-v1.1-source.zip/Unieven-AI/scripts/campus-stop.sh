#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CAMPUS_SOURCE_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
CAMPUS_RUNTIME_DIR="${CAMPUS_RUNTIME_DIR:-$(dirname -- "$CAMPUS_SOURCE_DIR")/.campus-runtime}"
CAMPUS_PYTHON="${CAMPUS_PYTHON:-python3.12}"
command -v "$CAMPUS_PYTHON" >/dev/null || CAMPUS_PYTHON=python3
"$CAMPUS_PYTHON" - "$CAMPUS_RUNTIME_DIR" <<'PY'
import json, os, signal, subprocess, sys, time
from pathlib import Path
runtime = Path(sys.argv[1]).expanduser().resolve()
def identity(pid):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().split(') ', 1)[1].split()
        return '' if fields[0] == 'Z' else fields[19]
    except (OSError, IndexError):
        result = subprocess.run(['ps', '-o', 'lstart=', '-p', str(pid)], text=True, capture_output=True)
        return result.stdout.strip() if result.returncode == 0 else ''
for name in ('web', 'campus', 'attendance', 'mongo'):
    path = runtime / 'pids' / f'{name}.json'
    if not path.exists():
        continue
    record = json.loads(path.read_text())
    if record.get('identity') and identity(record['pid']) == record['identity']:
        os.kill(record['pid'], signal.SIGTERM)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline and identity(record['pid']) == record['identity']:
            time.sleep(.2)
        if identity(record['pid']) == record['identity']:
            print(f'{name} is still stopping; its PID record was preserved.')
            continue
    path.unlink(missing_ok=True)
print('Recorded V1 services stopped. Database files and local keys were preserved.')
PY
