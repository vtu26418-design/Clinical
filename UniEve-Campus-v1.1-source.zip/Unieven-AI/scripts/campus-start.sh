#!/usr/bin/env bash
set -euo pipefail
umask 077
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CAMPUS_SOURCE_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
CAMPUS_RUNTIME_DIR="${CAMPUS_RUNTIME_DIR:-$(dirname -- "$CAMPUS_SOURCE_DIR")/.campus-runtime}"
[[ -x "$CAMPUS_RUNTIME_DIR/attendance-venv/bin/python" ]] || { echo 'Run scripts/campus-setup.sh first.' >&2; exit 1; }
"$CAMPUS_RUNTIME_DIR/attendance-venv/bin/python" - "$CAMPUS_SOURCE_DIR" "$CAMPUS_RUNTIME_DIR" <<'PY'
import json, os, shutil, socket, subprocess, sys, time
from pathlib import Path
from urllib.request import urlopen
from dotenv import dotenv_values
from pymongo import MongoClient

source, runtime = map(lambda value: Path(value).expanduser().resolve(), sys.argv[1:])
private, pids, logs = runtime / 'private', runtime / 'pids', runtime / 'logs'
for directory in (private, pids, logs):
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)

def environment(filename):
    values = dotenv_values(private / filename)
    return {**os.environ, **{key: value for key, value in values.items() if value is not None and key not in os.environ}}

campus_env, academic_env = environment('campus.env'), environment('attendance.env')
campus_env['CAMPUS_ENV_FILE'] = str(private / 'campus.env')
campus_env['CAMPUS_WEB_DIST'] = str(source / 'campus-web/dist')
campus_env['CAMPUS_RUNTIME_OWNER'] = academic_env['CAMPUS_RUNTIME_OWNER'] = str(runtime)

def identity(pid):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().split(') ', 1)[1].split()
        return '' if fields[0] == 'Z' else fields[19]
    except (OSError, IndexError):
        result = subprocess.run(['ps', '-o', 'lstart=', '-p', str(pid)], text=True, capture_output=True)
        return result.stdout.strip() if result.returncode == 0 else ''

def recorded(name):
    path = pids / f'{name}.json'
    if not path.exists():
        return None
    record = json.loads(path.read_text())
    return record if record.get('identity') and identity(record['pid']) == record['identity'] else None

started = []
def launch(name, command, cwd, env):
    if recorded(name):
        return
    with (logs / f'{name}.log').open('ab') as output:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    record = {'pid': process.pid, 'identity': identity(process.pid)}
    (pids / f'{name}.json').write_text(json.dumps(record))
    started.append((name, process))

def mongo_ready(uri):
    try:
        with MongoClient(uri, serverSelectionTimeoutMS=1500, connectTimeoutMS=1500) as client:
            client.admin.command('ping')
        return True
    except Exception:
        return False

def local_mongo_port(uri):
    from urllib.parse import urlsplit
    try:
        parsed = urlsplit(uri)
        return (parsed.port or 27017) if parsed.scheme == 'mongodb' and parsed.hostname in ('127.0.0.1', 'localhost') and ',' not in parsed.netloc else None
    except ValueError:
        return None

def check_port(port):
    with socket.socket() as connection:
        if connection.connect_ex(('127.0.0.1', port)) == 0:
            raise RuntimeError(f'Port {port} is occupied by a different process. No process was stopped.')

def wait_http(name, address):
    deadline = time.monotonic() + 40
    while time.monotonic() < deadline:
        record = recorded(name)
        if not record:
            raise RuntimeError(f'{name} stopped. Inspect its private runtime log.')
        try:
            with urlopen(address, timeout=2) as response:
                if response.status == 200:
                    return
        except Exception:
            pass
        time.sleep(.4)
    raise RuntimeError(f'{name} did not become ready. Inspect its private runtime log.')

try:
    mongo_uris = [campus_env.get('MONGODB_URI', ''), academic_env.get('MONGO_URI', '')]
    for uri in dict.fromkeys(mongo_uris):
        if not uri:
            raise RuntimeError('Configure both MongoDB connections in the private runtime env files.')
        if mongo_ready(uri):
            continue
        port = local_mongo_port(uri)
        if port is None:
            raise RuntimeError('External MongoDB could not be reached. Check its credentials, TLS and network access.')
        if port != 27018:
            raise RuntimeError('Configured local MongoDB is unavailable. Start it yourself, or use the isolated default port 27018.')
        binary = os.getenv('CAMPUS_MONGOD') or shutil.which('mongod')
        if not binary and Path('/workspace/.onboarding/mongod').is_file():
            binary = '/workspace/.onboarding/mongod'
        if not binary:
            raise RuntimeError('Install MongoDB Community Server, set CAMPUS_MONGOD, or configure an existing MongoDB connection.')
        if not recorded('mongo'):
            check_port(port)
        launch('mongo', [binary, '--bind_ip', '127.0.0.1', '--port', str(port), '--dbpath', str(runtime / 'mongo-data')], runtime, campus_env)
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline and not mongo_ready(uri):
            time.sleep(.3)
        if not mongo_ready(uri):
            raise RuntimeError('Local MongoDB did not become ready. Inspect its private runtime log.')
    api_port = int(campus_env.get('CAMPUS_PORT', '4100'))
    academic_port = int(campus_env.get('CAMPUS_ACADEMIC_PORT', '8000'))
    web_port = int(campus_env.get('CAMPUS_WEB_PORT', '5180'))
    if any(port < 1024 or port > 65535 for port in (api_port, academic_port, web_port)) or len({api_port, academic_port, web_port}) != 3:
        raise RuntimeError('Choose three distinct application ports between 1024 and 65535.')
    for name, port in (('attendance', academic_port), ('campus', api_port), ('web', web_port)):
        if not recorded(name):
            check_port(port)
    launch('attendance', [str(runtime / 'attendance-venv/bin/python'), '-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', str(academic_port)], runtime / 'attendance-backend', academic_env)
    wait_http('attendance', f'http://127.0.0.1:{academic_port}/health')
    launch('campus', [shutil.which('node') or 'node', 'campus/server.js'], runtime / 'campus-backend', campus_env)
    wait_http('campus', f'http://127.0.0.1:{api_port}/api/campus/health')
    launch('web', [shutil.which('node') or 'node', str(source / 'campus-web/node_modules/vite/bin/vite.js'), '--host', '127.0.0.1', '--port', str(web_port), '--strictPort'], source / 'campus-web', campus_env)
    wait_http('web', f'http://127.0.0.1:{web_port}/')
except Exception as error:
    # Roll back only the processes this invocation started; existing services are preserved.
    for name, process in reversed(started):
        if process.poll() is None:
            process.terminate()
        (pids / f'{name}.json').unlink(missing_ok=True)
    raise SystemExit(str(error))
print(f'V1 services ready. Open http://127.0.0.1:{web_port} in your own local browser.')
print(f'Logs and private local configuration: {runtime}')
PY
