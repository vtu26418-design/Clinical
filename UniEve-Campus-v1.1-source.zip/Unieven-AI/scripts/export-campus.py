#!/usr/bin/env python3
"""Create portable sanitized source and PWA packages; never includes a private runtime."""
import hashlib,json,os,re,shutil,tempfile,zipfile
from pathlib import Path

source=Path(__file__).resolve().parents[1]
attendance=Path(os.environ.get('CAMPUS_ATTENDANCE_DIR',str(source.parent/'Unieve-Attandance-AI'))).resolve()
output=Path(os.environ.get('CAMPUS_DOWNLOAD_DIR',str(source.parent/'artifacts'))).resolve()
if not (attendance/'backend/requirements.txt').is_file():raise SystemExit('Attendance repository not found; set CAMPUS_ATTENDANCE_DIR.')
if not (source/'campus-web/dist/index.html').is_file():raise SystemExit('Build campus-web before exporting packages.')
output.mkdir(parents=True,exist_ok=True)
excluded={'.git','node_modules','.venv','venv','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache','dist','target','bin','.idea','.vscode','.next','.turbo','.cache','uploads','logs','mongo-data','artifacts','downloads'}
patterns=[re.compile(r'mongodb(?:\+srv)?://[^\s/]+:[^\s/@]+@'),re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(r'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|sk_live_[A-Za-z0-9]{20,}|AKIA[A-Z0-9]{16})\b')]
report=[]
with tempfile.TemporaryDirectory(prefix='unieve-export-') as temporary:
 staging=Path(temporary)/'source';staging.mkdir()
 for original,name in [(source,'Unieven-AI'),(attendance,'Unieve-Attandance-AI')]:
  for base,dirs,files in os.walk(original):
   dirs[:]=[d for d in dirs if d not in excluded and not d.startswith('.campus-runtime') and not (Path(base)/d).is_symlink() and (Path(base)/d).resolve()!=output]
   for filename in files:
    p=Path(base)/filename
    if p.is_symlink() or (filename.startswith('.env') and filename!='.env.example') or p.suffix in {'.pyc','.pyo','.log','.db','.sqlite','.pem','.key','.p12'} or filename=='.DS_Store':continue
    target=staging/name/p.relative_to(original);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
  config=staging/name/'auth-service/src/main/resources/application.properties'
  if config.exists():
   text=config.read_text();text=re.sub(r'(?m)^(spring\.(?:data\.)?mongodb\.uri)\s*=.*$',lambda m:m.group(1)+'=${SPRING_MONGODB_URI:mongodb://127.0.0.1:27017/Unieven}',text)
   for key,variable in [('password','MAIL_PASSWORD'),('username','MAIL_USERNAME')]:text=re.sub(r'(?m)^spring\.mail\.'+key+r'\s*=.*$','spring.mail.'+key+'=${'+variable+':}',text)
   config.write_text(text)
 # Original attendance helpers use a literal student ID as an illustration.
 # Neutralize these comments, labels and error examples in the delivery copy.
 example_files=['backend/app/college/parser.py','backend/app/schemas/user.py',
  'backend/app/services/parent_portal/veltech_adapter.py',
  'backend/app/services/student_service.py','backend/app/services/user_service.py',
  'frontend/src/admin/EditUser.jsx','frontend/src/components/PortalCredentialsCard.jsx',
  'frontend/src/hooks/usePortal.js','frontend/src/services/profileService.js',
  'frontend/src/services/userService.js']
 for relative in example_files:
  example=staging/'Unieve-Attandance-AI'/relative
  if example.is_file():example.write_text(re.sub(r'\bVTU[0-9]{5}\b','VTU00000',example.read_text(),flags=re.IGNORECASE))
 for file in staging.rglob('*'):
  if not file.is_file() or file.stat().st_size>1000000:continue
  try:text=file.read_text()
  except UnicodeDecodeError:continue
  if any(pattern.search(text) for pattern in patterns):raise SystemExit('Credential-pattern scan rejected file: '+str(file.relative_to(staging)))
 guide=source/'README-CAMPUS-V1.md';shutil.copy2(guide,staging/'START_HERE.md')
 mobile=Path(temporary)/'UniEve-Campus-v1.1-mobile-web';mobile.mkdir();shutil.copytree(source/'campus-web/dist',mobile/'web',ignore=shutil.ignore_patterns('downloads'))
 shutil.copy2(guide,mobile/'SETUP_GUIDE.md')
 (mobile/'START_HERE.md').write_text('''# UniEve Campus V1.1\n\nPreview the fictional demo: `cd web` then `python3 -m http.server 5180 --bind 127.0.0.1`. Open http://127.0.0.1:5180 on that machine.\n\nFor live data, use the source ZIP and follow SETUP_GUIDE.md. The static preview cannot connect campus accounts or serve source downloads.\n\nInstall on Android Chrome or iPhone Safari after hosting this PWA at an HTTPS origin with the campus API on the same origin. This is a web app, not an APK. AMS requires your manual CAPTCHA answer. Device snapshots are optional and passphrase-encrypted.\n''')
 for filename,folder,prefix in [('UniEve-Campus-v1.1-source.zip',staging,Path('.')),('UniEve-Campus-v1.1-mobile-web.zip',mobile,Path(mobile.name))]:
  target=output/filename
  with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
   for file in sorted(folder.rglob('*')):
    if file.is_file():archive.write(file,prefix/file.relative_to(folder))
  with zipfile.ZipFile(target) as archive:
   if archive.testzip() is not None:raise SystemExit('ZIP integrity check failed.')
  report.append({'file':filename,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
 shutil.copy2(guide,output/'UniEve-Campus-v1.1-setup.md')
(output/'UniEve-Campus-v1.1-manifest.json').write_text(json.dumps({'packages':report,'containsPrivateData':False},indent=2))
print(json.dumps({'output':str(output),'packages':report},indent=2))
