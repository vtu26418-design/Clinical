#!/usr/bin/env bash
# Install V1 into a private runtime outside the source checkouts.
set -euo pipefail
umask 077
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CAMPUS_SOURCE_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
CAMPUS_ATTENDANCE_DIR="${CAMPUS_ATTENDANCE_DIR:-$(dirname -- "$CAMPUS_SOURCE_DIR")/Unieve-Attandance-AI}"
CAMPUS_RUNTIME_DIR="${CAMPUS_RUNTIME_DIR:-$(dirname -- "$CAMPUS_SOURCE_DIR")/.campus-runtime}"
CAMPUS_PYTHON="${CAMPUS_PYTHON:-python3.12}"
command -v "$CAMPUS_PYTHON" >/dev/null || CAMPUS_PYTHON=python3
command -v node >/dev/null && command -v npm >/dev/null || { echo 'Install Node.js 24 LTS (minimum 22.12) and npm first.' >&2; exit 1; }
node -e 'const [a,b]=process.versions.node.split(".").map(Number);if(a<22||(a===22&&b<12)){console.error("Node.js >=22.12 is required");process.exit(1)}'
"$CAMPUS_PYTHON" -c 'import sys; assert sys.version_info[:2] == (3,12), "Install Python 3.12 or set CAMPUS_PYTHON to its executable"'

"$CAMPUS_PYTHON" - "$CAMPUS_SOURCE_DIR" "$CAMPUS_ATTENDANCE_DIR" "$CAMPUS_RUNTIME_DIR" <<'PY'
import base64, json, os, secrets, shutil, sys
from pathlib import Path

source, attendance, runtime = map(lambda p: Path(p).expanduser().resolve(), sys.argv[1:])
if not (source / 'campus-web/package-lock.json').is_file() or not (attendance / 'backend/requirements.txt').is_file():
    raise SystemExit('Extract both repositories as siblings, or set CAMPUS_ATTENDANCE_DIR.')
if runtime == Path('/') or any(runtime == p or p in runtime.parents for p in (source, attendance)):
    raise SystemExit('CAMPUS_RUNTIME_DIR must be outside both source checkouts.')
for record in (runtime / 'pids').glob('*.json'):
    try:
        saved = json.loads(record.read_text())
        pid = saved['pid']
        stat = Path(f'/proc/{pid}/stat')
        if stat.exists():
            fields = stat.read_text().split(') ', 1)[1].split()
            if fields[0] == 'Z' or fields[19] != saved.get('identity'):
                continue
        os.kill(pid, 0)
    except (OSError, ValueError, KeyError):
        continue
    raise SystemExit('A recorded runtime process is running. Run campus-stop.sh before reinstalling.')
for name in ('private', 'pids', 'logs', 'mongo-data', 'npm-cache', 'uv-cache'):
    (runtime / name).mkdir(parents=True, exist_ok=True, mode=0o700)
    (runtime / name).chmod(0o700)
(runtime / '.gitignore').write_text('*\n')

def excluded(_directory, names):
    return [n for n in names if n in {'node_modules', '.git', '.venv', 'venv', '__pycache__', '.pytest_cache'} or n.startswith('.env')]

for original, target in ((source / 'backend', runtime / 'campus-backend'), (attendance / 'backend', runtime / 'attendance-backend')):
    # Source node_modules is tracked in the original event repository. Never run npm ci there.
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(original, target, ignore=excluded)

raw = (attendance / 'backend/requirements.txt').read_bytes()
requirements = raw.decode('utf-16') if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else raw.decode('utf-8-sig')
(runtime / 'attendance-requirements.txt').write_text(requirements.replace('\r\n', '\n'), encoding='utf-8')

def write_env_once(path, values):
    if path.exists():
        path.chmod(0o600)
        return
    # JSON string quoting is compatible with dotenv and protects punctuation in generated secrets.
    text = '\n'.join(f'{key}={json.dumps(str(value))}' for key, value in values.items()) + '\n'
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'w') as file:
        file.write(text)

private = runtime / 'private'
write_env_once(private / 'campus.env', {
    'MONGODB_URI': os.getenv('MONGODB_URI', 'mongodb://127.0.0.1:27018/unieve_campus_v1'),
    'CAMPUS_PORT': os.getenv('CAMPUS_PORT', '4100'),
    'CAMPUS_ACADEMIC_PORT': os.getenv('CAMPUS_ACADEMIC_PORT', '8000'),
    'CAMPUS_WEB_PORT': os.getenv('CAMPUS_WEB_PORT', '5180'),
    'CAMPUS_LINK_KEY': os.getenv('CAMPUS_LINK_KEY') or secrets.token_hex(32),
    'CAMPUS_ORIGINS': os.getenv('CAMPUS_ORIGINS', ','.join(f'http://{host}:{port}' for port in (os.getenv('CAMPUS_WEB_PORT', '5180'), os.getenv('CAMPUS_PORT', '4100')) for host in ('127.0.0.1', 'localhost'))),
    'ACADEMIC_API_URL': os.getenv('ACADEMIC_API_URL', f"http://127.0.0.1:{os.getenv('CAMPUS_ACADEMIC_PORT', '8000')}/api/v1"),
    'NODE_ENV': 'development',
    'RAZORPAY_KEY_ID': '', 'RAZORPAY_KEY_SECRET': '', 'RAZORPAY_WEBHOOK_SECRET': '',
})
write_env_once(private / 'attendance.env', {
    'MONGO_URI': os.getenv('MONGO_URI', 'mongodb://127.0.0.1:27018'),
    'MONGO_DB_NAME': os.getenv('MONGO_DB_NAME', 'unieve_campus_attendance_v1'),
    'JWT_SECRET': os.getenv('JWT_SECRET') or secrets.token_hex(48),
    'PORTAL_CREDENTIAL_ENCRYPTION_KEY': os.getenv('PORTAL_CREDENTIAL_ENCRYPTION_KEY') or base64.urlsafe_b64encode(secrets.token_bytes(32)).decode(),
    'DEFAULT_ADMIN_EMAIL': os.getenv('DEFAULT_ADMIN_EMAIL', 'local-admin@example.invalid'),
    'DEFAULT_ADMIN_PASSWORD': os.getenv('DEFAULT_ADMIN_PASSWORD') or secrets.token_urlsafe(32),
    'DEFAULT_ADMIN_NAME': os.getenv('DEFAULT_ADMIN_NAME', 'Local academic administrator'),
    'COLLEGE_ADAPTER_MODE': os.getenv('COLLEGE_ADAPTER_MODE', 'portal'),
    'SYNC_ENABLED': 'false', 'SMS_ENABLED': 'false', 'EMAIL_ENABLED': 'false',
    'CORS_ORIGINS': json.dumps([f'http://{host}:{os.getenv("CAMPUS_WEB_PORT", "5180")}' for host in ('127.0.0.1', 'localhost')]),
})
shutil.copyfile(private / 'attendance.env', runtime / 'attendance-backend/.env')
(runtime / 'attendance-backend/.env').chmod(0o600)
print('Private runtime source copies and persistent local configuration prepared.')
PY

mkdir -p -- "$CAMPUS_RUNTIME_DIR"
export npm_config_cache="$CAMPUS_RUNTIME_DIR/npm-cache"
export UV_CACHE_DIR="$CAMPUS_RUNTIME_DIR/uv-cache"
export PIP_CACHE_DIR="$CAMPUS_RUNTIME_DIR/pip-cache"
if command -v uv >/dev/null; then
  if [[ ! -x "$CAMPUS_RUNTIME_DIR/attendance-venv/bin/python" ]]; then
    uv venv --python "$CAMPUS_PYTHON" "$CAMPUS_RUNTIME_DIR/attendance-venv"
  fi
  uv pip install --python "$CAMPUS_RUNTIME_DIR/attendance-venv/bin/python" -r "$CAMPUS_RUNTIME_DIR/attendance-requirements.txt"
else
  if [[ ! -x "$CAMPUS_RUNTIME_DIR/attendance-venv/bin/python" ]]; then
    "$CAMPUS_PYTHON" -m venv "$CAMPUS_RUNTIME_DIR/attendance-venv"
  fi
  "$CAMPUS_RUNTIME_DIR/attendance-venv/bin/python" -m pip install -r "$CAMPUS_RUNTIME_DIR/attendance-requirements.txt"
fi
(cd -- "$CAMPUS_RUNTIME_DIR/campus-backend" && npm ci --no-audit --no-fund)
(cd -- "$CAMPUS_SOURCE_DIR/campus-web" && npm ci --no-audit --no-fund && npm run build)
"$CAMPUS_PYTHON" "$CAMPUS_SOURCE_DIR/scripts/export-campus.py"
echo 'V1 setup complete. Start with scripts/campus-start.sh. No student data was seeded.'
