# Campus V1.1 — live sources, settings and device storage

The user requests live university fetching, redesigned Settings, more event/social features, encrypted device data and usable downloads. Prior authorization delegates professional design and implementation choices; continue inline without redundant approval gates. Preserve the existing campus modules, mobile bottom navigation and server-enforced roles.

Settings becomes a category rail with Account, Connections, Device storage, App preferences and Downloads. Connections reports actual source reachability, timestamps and errors; AMS uses Login.aspx (Login.htm is an unrendered template) and requires the student's manually entered CAPTCHA plus a session nonce. Credentials are never submitted automatically when a CAPTCHA is unresolved. Parent login currently returns404; do not substitute invented attendance. Official public campus news is fetched separately and labelled as website content.

Device snapshots are optional AES-GCM encrypted IndexedDB records protected with a user passphrase (PBKDF2), one-day or seven-day expiry. Save only selected student identity, subject totals, timetable and source timestamps; omit credentials, auth tokens, family/contact information and ticket/payment secrets. Unlock into a read-only view; no offline registration, fake sync or payment. Clear control removes the encrypted snapshot.

Events gain account-persisted bookmarks, search/filter, sharing and correctly timed IST calendar exports. Feed gains search, following filter and author-owned edit/delete; legacy posts remain interoperable. Authorization, input limits and account-transition guards apply to every mutation.

Downloads use real HTTP attachments from the campus API with a fixed allowlist, safe filenames and no arbitrary file paths. Delivery copies exclude secrets, private runtime data and dependencies; Spring credential literals are replaced only in archived copies. Chat attachment export is unavailable and /mnt/data is not writable on this executor, so standard sandbox file links and tested in-app download buttons are provided without claiming a published public URL.

Verification covers encryption/expiry/tampering, ownership, portal challenge isolation/no password submission without a manual answer, public news parsing, mobile settings navigation, device save/unlock/clear, event bookmarks, feed search/edit/delete and attachment headers/content. No real portal login success is claimed before a manual challenge and successful authenticated fetch.
