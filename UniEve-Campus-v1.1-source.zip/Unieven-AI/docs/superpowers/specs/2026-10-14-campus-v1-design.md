# UniEve Campus V1 design

The user approved the proposed design and delegated professional design and implementation choices. Proceed continuously in this isolated cloud checkout; no additional worktree, deployment, external project or paid transaction is required.

## Outcome
A responsive web application unifies the existing UniEven event/social system and the attendance application's academic adapters. Deliver source ZIP, a built web bundle, runnable setup scripts, and a guide. Playground is excluded. The linked conversation is unavailable through this session's tools, so exact parity with every page of the university application cannot be asserted. Document supported modules and unconnected sources accurately.

## Architecture
Create `campus-web` (React 19, Vite, Lucide) in Unieven-AI. Add `backend/campus` as a standalone Express API on port 4100 using the existing User, Event and EventRegistration MongoDB models and a new revocable session collection. Keep the original frontend, Node server and Spring service usable. Reuse the FastAPI academic service through a server-side bridge and its existing per-student authorization. Authenticate Node accounts with password verification, opaque HttpOnly session cookies and same-origin CSRF protection. Link an academic account only after verifying its password and matching its normalized email to the campus account. Store its API token encrypted with a configured persistent key; never store the linking password or return the API token.

## Student experience
- One shell with Home, Attendance, Timetable, Academics, Events, Placements, Campus feed, Student details and Settings. Authorized staff also see Management.
- Photo in navbar, home and private student details. Initials replace unavailable photos. Never publish private academic identifiers or family information in the social feed.
- Home: name, enrollment number, department, semester, batch, mentor; attendance summary; today's ordered classes; academic shortcuts; campus events and announcements.
- Attendance: per-subject percentages and present/absent totals, percentage calculator, date and subject detail. Green only for source-confirmed present, red only for confirmed absent. Unknown, unmarked, future and not-scheduled classes have distinct neutral states. Times use Asia/Kolkata.
- Academics: registered courses, semester/bucket, results, examinations, fees, documents, requests and resources. University-provided data is displayed only when available; results/fees/documents not yet covered by adapters explicitly show an integration state. Staff can provide campus announcements/resources through the app.
- Placements: separate campus/off-campus filters, search, job details, eligibility and deadlines, save jobs and track applications. Staff can create genuine opportunities. Sample opportunities are clearly demo content.
- Campus feed: professional and campus-life categories, compose text/image posts, like, save, comment, profile view and follow with real persisted state in connected mode.

## Events and roles
Reuse existing event documents and registration collection. Add scopes `club`, `department`, `college`, department and club fields, capacity, registration count and price in INR paise. Roles: student, club organizer, department coordinator, college event manager, placement officer and admin. Legacy faculty/admin roles map to campus permissions without granting new client-asserted roles. Only server-stored roles and scopes authorize creation, analytics, exports and check-in. A club organizer can manage only their assigned club; a department coordinator only their department; a college event manager only college-wide events; admin can manage all. Legacy creator checks remain supported for unscoped events.

Registration is idempotent, unique per student/event, capacity-limited by an atomic reservation, and distinct from cancellation. Paid tickets remain pending until a verified Razorpay `payment.captured` webhook matches the stored order, event price and currency. Generate short-lived one-time QR tokens only for confirmed registrations; check-in is authorized and atomic. Never confirm payment from a browser success callback. Preserve original free-event flow while fixing organizer authorization on legacy endpoints.

## Data and operational honesty
An explicit browser-only demo mode uses fictional student data, generated photo/assets, and local persistence to let users review V1 without credentials. It is never labelled live; clearing demo data is supported. Connected mode uses the real APIs, clear empty/unavailable states, retry controls and last-sync timestamps. Portal sync requires the student's authorized account, supported destinations and a persistent encryption key. Missing source modules cannot be manufactured. Real Razorpay processing requires merchant keys and a public webhook endpoint; development tests use a fake provider confined to the test harness.

## Visual system
Use a white/light cool-gray canvas, navy sidebar, indigo actions, teal accents, strong readable headings, restrained borders, 14-18px radius panels, and generous spacing. One student identity band, a schedule rail and compact information rows avoid repetitive grids. Lucide outline icons, 20px/1.8 stroke. Motion is subtle, decorative and disabled by prefers-reduced-motion. Responsive drawer navigation, stacked sections, keyboard focus and accessible dialog/forms are required. Generated dashboard concept is the visual reference; functionality may add labelled demo and connection status required by this spec.

## Verification and delivery
Node tests must cover role boundaries, CSRF/session revocation, academic link isolation, registration duplicates/capacity, QR ownership/replay and payment webhook authenticity/amount/idempotency. Browser checks cover demo navigation, photo placement, attendance states, event registration, filters, compose/like/save/comment, dialogs, management and mobile overflow. Build the new frontend, run the relevant backend suite, and recheck original frontend builds and Python import. Compare the generated concept and browser screenshots with view_image and record differences. ZIP excludes .git, node_modules, .env, credentials, database files and build caches. Include explicit integration limitations and a reproducible setup guide.
