# Sky-blue hybrid artwork

Same cap, curved sides, calendar and institutional centre emblem as the existing project logo. The colour/finish edit uses the original Attendance app primary sky blue #0EA5E9, softer blue tints #7DD3FC/#BAE6FD and satin silver/slate #F1F5F9 already compatible with the source projects. Original colour evidence: Unieve-Attandance-AI frontend/src/pages/Login.jsx and Timetable.jsx use #0EA5E9; Unieven-AI login uses blue classes and #F1F5F9/#F8FAFC surfaces. Outer orange, purple and green are not used. Official centre-emblem identifying colours remain.

Smooth low-glare car-paint finish; no bloom, glow halo or brightness pulse. Transparent master: hybrid-3d-master.png. Static web/PWA/native assets and five animated parts derive from this master. Calendar and emblem are independently aligned alpha partitions. The existing cap-drop, rising sides and centre reveal sequence is retained, with reduced-motion support. Original project reference remains preserved at public/assets/project-original-logo.png and is not used as the displayed logo.

University emblem reference provenance: faculty-provided report cover. No institutional endorsement is claimed.
