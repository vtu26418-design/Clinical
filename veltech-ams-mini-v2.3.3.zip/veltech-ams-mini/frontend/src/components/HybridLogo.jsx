export default function HybridLogo(){
 return ['left','right','cap','centre','emblem'].map(part=><img key={part} className={`app-launch-part part-${part}`} src={`/assets/logo/${part}.png`} alt="" decoding="sync"/>);
}
