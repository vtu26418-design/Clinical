import {useEffect,useState} from 'react';
import {useAppPreferences} from '../context/AppPreferences';
const key='veltech:launch:v22';
function alreadyOpened(){try{return sessionStorage.getItem(key)==='seen';}catch{return false;}}
export default function AppLaunch({children}){
 const {preferences}=useAppPreferences(),[pending,setPending]=useState(()=>!alreadyOpened());
 const reduced=preferences.motion==='reduced' || globalThis.matchMedia?.('(prefers-reduced-motion:reduce)').matches;
 const visible=pending && preferences.openingAnimation;
 useEffect(()=>{
  if(!pending)return;
  if(!preferences.openingAnimation){setPending(false);return;}
  try{sessionStorage.setItem(key,'seen');}catch{}
  const timer=setTimeout(()=>setPending(false),reduced?180:850);
  return()=>clearTimeout(timer);
 },[pending,preferences.openingAnimation,reduced]);
 return <><div className="app-launch-content" inert={visible} aria-hidden={visible || undefined}>{children}</div>{visible?<div className="app-launch" role="status" aria-label="Opening Veltech mini" data-motion={reduced?'reduced':'full'}><div className="app-launch-mark"><span/><img src="/assets/original-logo.png" alt=""/></div><strong>veltech mini</strong><div className="app-launch-line" aria-hidden="true"><span/></div></div>:null}</>;
}
