import {useEffect,useRef,useState} from 'react';
import {Download,RefreshCw,Smartphone} from 'lucide-react';
import {request} from '../lib/api';
import {androidInstallation,androidReleaseState,validateAndroidRelease,verifyApkDownload} from '../lib/app-release';
import {Button,Badge,Feedback} from './UI';
export default function AndroidUpdates(){
 const [release,setRelease]=useState(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[downloading,setDownloading]=useState(false),[progress,setProgress]=useState(0),[downloaded,setDownloaded]=useState(false);
 const active=useRef(true),controller=useRef(null);
 // Capture browser-provided Android referrer only; never restore an installation
 // claim from sessionStorage or infer installation from URL parameters alone.
 const [launch]=useState(()=>({referrer:document.referrer,search:location.search}));
 const installation=androidInstallation({...launch,packageId:release?.packageId});
 async function check(){setBusy(true);setError('');try{const value=validateAndroidRelease(await request('/app-release'));if(active.current){setRelease(value);setDownloaded(false);}}catch(e){if(active.current){setRelease(null);setError(e.message);}}finally{if(active.current)setBusy(false);}}
 useEffect(()=>{active.current=true;check();return()=>{active.current=false;controller.current?.abort();};},[]);
 async function download(){
  if(!release?.available || downloading)return;setDownloading(true);setDownloaded(false);setError('');setProgress(0);controller.current=new AbortController();
  try{
   const data=await request(release.url.replace('/api/campus',''),{responseType:'arraybuffer',timeout:180000,signal:controller.current.signal,onDownloadProgress:e=>{if(active.current)setProgress(Math.min(99,Math.round(e.loaded/release.bytes*100)));}});
   const bytes=await verifyApkDownload(data,release);if(!active.current)return;
   const url=URL.createObjectURL(new Blob([bytes],{type:'application/vnd.android.package-archive'})),anchor=document.createElement('a');anchor.href=url;anchor.download=`veltech-ams-mini-${release.versionName}.apk`;document.body.append(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);setProgress(100);setDownloaded(true);
  }catch(e){if(active.current)setError(e.message || 'Download failed. Please try again.');}finally{if(active.current)setDownloading(false);}
 }
 return <div className="android-updates"><div className="connection-heading"><span className="connection-icon"><Smartphone size={23}/></span><div><h3>Android app</h3><p role="status">{busy && !release?'Checking Android release…':androidReleaseState(release,installation)}</p></div><Badge status={installation.installed?'present':'neutral'}>{installation.installed?'Android app':'APK'}</Badge></div>{release?.available?<><p>Version {release.versionName} · {(release.bytes/1048576).toFixed(1)} MB</p>{release.notes?<p>{release.notes}</p>:null}<div className="app-install-actions"><Button busy={downloading} onClick={download}><Download size={16}/>{downloading?`Downloading ${progress}%`:installation.installed?'Download Android update':'Download Android APK'}</Button><Button variant="secondary" busy={busy} disabled={downloading} onClick={check}><RefreshCw size={15}/>Check for updates</Button></div>{downloading?<progress className="apk-download-progress" max="100" value={progress} aria-label="APK download progress"/>:null}{downloaded?<p role="status" className="apk-download-complete">APK saved. Open it from Downloads to continue. Android will ask you to confirm installation.</p>:null}<p className="page-footnote">Open the downloaded APK to install. Your device may ask to allow installation from this browser. Only Android can confirm that installation is complete.</p><details className="apk-verification"><summary>Verify this download</summary><p>Package: {release.packageId}</p><p>SHA-256: <code>{release.sha256}</code></p></details></>:<><p className="page-footnote">{error?'Release details are unavailable. Retry when connected.':'A signed APK has not been published to this server yet. Check again after the release is deployed.'}</p><Button variant="secondary" busy={busy} onClick={check}><RefreshCw size={15}/>Check Android release</Button></>}<Feedback error={error}/></div>;
}
