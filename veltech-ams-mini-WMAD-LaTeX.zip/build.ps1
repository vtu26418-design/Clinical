$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command pdflatex -ErrorAction SilentlyContinue)) {
    throw 'Install MiKTeX or TeX Live, or upload this source ZIP to Overleaf and select pdfLaTeX.'
}
for ($reportPass = 1; $reportPass -le 3; $reportPass++) {
    & pdflatex -interaction=nonstopmode -halt-on-error -file-line-error main.tex
    if ($LASTEXITCODE -ne 0) { throw "LaTeX compilation failed on pass $reportPass. See main.log." }
}
Write-Host 'Report ready: main.pdf. Edit project-info.tex to add your personal details.'
