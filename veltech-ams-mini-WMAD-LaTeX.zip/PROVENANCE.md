# Report content and asset provenance

## Template

The uploaded `1-WMAD-SS2627-REPORT-LATEX.docx` contains literal LaTeX text, with no embedded media. Its document structure, university text, course code, summer label, front matter and nine-chapter order form the report template. Its unrelated car-rental abstract and unfilled exercise content were replaced with verified project information. Personal details remain editable placeholders at the user's request. The existing template's Head/Dean names are retained for the user to confirm.

## Project content

The current combined veltech-ams-mini V1.8 source and these project documents supplied the implementation facts:

- README.md; docs/FEATURES.md; docs/IMPLEMENTATION.md; docs/technology.md.
- docs/VERIFICATION.md; docs/deployment.md; docs/ANDROID.md.
- Frontend, campus-service and academic-service code and tests.

The current source release is pinned at:
https://raw.githubusercontent.com/vtu26418-design/Clinical/e3d50e627dcbe15fc316bc1fe3a2c01570a7c08a/veltech-ams-mini-v1.8-source.zip

Its SHA-256 is `aca0beff7ca6ac79bc2753435f5cabc2bfbfd032025585b186dbccb9a92b86ca`.

The 607-test result is the existing 20 October 2026 verification record, not a rerun for report generation. The benchmark is the recorded 19 October fictional local test. Historical AMS row counts are aggregate evidence from earlier authorized read-only checks; no private capture or individual record is included. No new live login was performed for this report.

## Diagrams and code

`architecture.tex` and `data-flow.tex` are original vector diagrams of the delivered project components and data flow. They are not diagrams of the university's internal server architecture.

`gpa.js`, `security.js` and `login_admission.py` are copies of the corresponding current project files. The report displays selected excerpts; private configuration values are not present.

## Images

- `veltech-official.jpg`: official AMS public login emblem, retrieved without authentication from https://ams.veltech.edu.in/images/VTUNEW.jpg on 20 October 2026. It fills the university-logo position in the supplied template. This does not imply institutional endorsement.
- `veltech-campus.jpg`: the project's existing university library photo. Its documented original source is https://www.veltech.edu.in/wp-content/uploads/2024/10/library-ban.jpg.
- `project-logo.png`: the original UniEven project emblem retained by the combined application.
- Home, attendance, events, community, login, results, credits and timetable screenshots: actual project UI from fictional preview/source-shaped QA fixtures. Student names, portraits, posts, events, grades, attendance and room records shown are demonstration data. No author/student personal grades are represented.
- Clean phone Home/Events/Community and desktop attendance screenshots were recaptured for this report from the static fictional preview, with identical existing project assets provided locally. Visible images were checked; no private API or university request was used for those captures.

Official university information remains attributed to the supplied template and the linked Vel Tech/AMS portals. Framework documentation in the bibliography is an implementation reference, not a claimed academic experiment.
