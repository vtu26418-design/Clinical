# Report provenance

This is the shortened 21 October 2026 revision of the report adapted from the user's WMAD-SS2627-REPORT-LATEX.docx. The college template's front matter, chapter order and presentation are retained. Personal fields remain placeholders at the user's request. This report has 28 total pages and exactly five visual items including the cover emblem.

## Project evidence

Content is condensed from the combined veltech-ams-mini V1.8 source, README.md and docs/FEATURES.md, IMPLEMENTATION.md, technology.md and VERIFICATION.md. The 607-test count and historical source/benchmark observations are the existing 20 October project record, not a new live-source test. No credentials, private student values, cookies or signing keys are included.

## Five images

1. images/veltech-official.jpg — public AMS login emblem: https://ams.veltech.edu.in/images/VTUNEW.jpg, retrieved without authentication for the earlier report.
2. images/architecture.tex — original vector diagram of the implemented project, not the university's private infrastructure.
3. images/data-flow.tex — original project data-flow diagram.
4. images/home-desktop.png — actual application UI with fictional preview records.
5. images/results-overall.png — actual application UI with fictional source-shaped QA grades and labelled calculation estimates.

There are no other image assets or picture placements. The campus security excerpt is copied from the current project's services/campus/campus/security.js.

## IEEE bibliography

The bibliography uses the unmodified Michael Shell IEEEtran.bst 1.14 (2015/08/26), distributed under LPPL 1.3. The original copyright and license notices remain in IEEEtran.bst. This controls reference formatting only; no IEEE paper template replaces the supplied college report format. The cited sources are actual project and technical references, not invented IEEE journal papers.

Retrieved style mirror (pinned commit):
https://raw.githubusercontent.com/rstudio/rticles/accdfa39225570a8ad9b786fbb3077060d1e12a5/inst/rmarkdown/templates/ieee/skeleton/IEEEtran.bst

IEEEtran.bst SHA-256: `314f0ece704568faf827011bac498650691b2b5ee06320720830e782416d5a5f`.
