import {createContext,useContext,useEffect,useState,useCallback,useRef} from 'react';
import {createDemo,DEMO_DATE} from '../data/demo';
import {useAppPreferences} from './AppPreferences';
import {request,setCsrf} from '../lib/api';
import {normalizeAcademic,campusDate,campusTime,attendanceStatus,recordForClass,sortClasses} from '../lib/attendance';
import {createAccountGate,mergeCampusProfile,createDemoRegistrationService,cancelDemoRegistration} from '../lib/client-state';

const CampusContext=createContext(null),STORAGE='unievecampus:demo:v1';
function readDemo() {try {const d=JSON.parse(localStorage.getItem(STORAGE));if(d?.version===1 && d.profile && Array.isArray(d.events) && Array.isArray(d.posts)) return d;} catch {}return createDemo();}
const blank=()=>({profile:{campusRole:'student'},subjects:[],classes:[],records:[],academic:{},events:[],registrations:[],placements:[],posts:[],people:[],notices:[],notifications:[]});
export function CampusProvider({children}) {
 const {preferences}=useAppPreferences();
 const [mode,setMode]=useState('demo'),[demo,setDemo]=useState(readDemo),[live,setLive]=useState(blank),[loading,setLoading]=useState(false),[message,setMessage]=useState(null),[error,setError]=useState('');
 const gate=useRef(null),modeRef=useRef('demo'),demoRef=useRef(demo),authAbort=useRef(null),demoRegistrations=useRef(null);
 if(!gate.current)gate.current=createAccountGate();
 const notify=useCallback((text,type='success')=>setMessage({text,type,id:Date.now()}),[]);
 useEffect(()=>{localStorage.setItem(STORAGE,JSON.stringify(demo));},[demo]);
 useEffect(()=>{if(!message)return;const timer=setTimeout(()=>setMessage(null),5500);return()=>clearTimeout(timer);},[message]);
 const refresh=useCallback(async(user)=>{
  if(modeRef.current!=='connected' && !user)return;
  const run=gate.current.startRefresh(!!user);if(!run)return;
  setLoading(true);setError('');
  try {
   const auth=user?{user}:await request('/session');
   if(!gate.current.currentRefresh(run))return;
   if(auth.csrfToken)setCsrf(auth.csrfToken);
   const paths=['/academics/overview','/events','/registrations','/placements','/feed','/people','/notices'];
   const responses=await Promise.allSettled(paths.map(p=>request(p)));
   const [academic,events,registrations,placements,posts,people,notices]=responses;
   if(!gate.current.currentRefresh(run))return;
   const overview=academic.status==='fulfilled'?normalizeAcademic(academic.value):{};
   setLive({profile:mergeCampusProfile(auth.user,overview.profile),subjects:overview.subjects || [],records:overview.records || [],timetable:overview.timetable || [],academic:overview.academic || {},notifications:overview.notifications || [],lastSyncedAt:overview.lastSyncedAt,academicError:academic.status==='rejected'?academic.reason.message:'',academicErrors:overview.errors || {},events:events.value || [],registrations:registrations.value || [],placements:placements.value || [],posts:posts.value || [],people:people.value || [],notices:notices.value || []});
   const failures=responses.slice(1).filter(x=>x.status==='rejected').map(x=>x.reason.message);
   const sourceErrors=Object.entries(overview.errors || {}).map(([source,message])=>`${source}: ${message}`);
   if(failures.length || sourceErrors.length)setError([...failures,...sourceErrors].join(' · '));
  } catch(e) {if(gate.current.currentRefresh(run)){setError(e.message);if(e.status===401){setLive(blank());setCsrf('');notify('Your session has expired. Sign in again.','error');}}}
  finally {if(gate.current.currentRefresh(run))setLoading(false);}
 },[notify]);
 useEffect(()=>{if(mode!=='connected' || !preferences.refreshSeconds)return;const id=setInterval(()=>refresh(),preferences.refreshSeconds*1000);return()=>clearInterval(id);},[mode,refresh,preferences.refreshSeconds]);
 const beginAccount=()=>{authAbort.current?.abort();authAbort.current=new AbortController();setLoading(true);setError('');return {ticket:gate.current.beginAccount(),signal:authAbort.current.signal};};
 const connectAccount=async(path,options,success)=>{
  const {ticket,signal}=beginAccount();
  try {
   const result=await request(path,{...options,signal});if(!gate.current.currentAccount(ticket))return false;
   demoRegistrations.current?.invalidate();setLive({...blank(),profile:mergeCampusProfile(result.user)});setCsrf(result.csrfToken);modeRef.current='connected';setMode('connected');
   await refresh(result.user);if(!gate.current.currentAccount(ticket))return false;notify(success);return true;
  }catch(e){if(gate.current.currentAccount(ticket))throw e;return false;}
  finally {if(gate.current.currentAccount(ticket)){gate.current.finishAccount(ticket);setLoading(false);}}
 };
 const signIn=(identity,password)=>connectAccount('/login',{method:'POST',body:{identity,password}},'Signed in to your campus workspace');
 const resume=()=>connectAccount('/session',{},'Campus session restored');
 const switchDemo=()=>{gate.current.invalidate();authAbort.current?.abort();setCsrf('');setLive(blank());setLoading(false);modeRef.current='demo';setMode('demo');setError('');notify('Demo workspace · all student data is fictional');};
 const signOut=async()=>{
  const {ticket,signal}=beginAccount();
  try {if(modeRef.current==='connected')await request('/logout',{method:'POST',body:{},signal});if(gate.current.currentAccount(ticket))switchDemo();}
  catch(e){if(gate.current.currentAccount(ticket)){if(e.status===401)switchDemo();else throw e;}}
  finally{if(gate.current.currentAccount(ticket)){gate.current.finishAccount(ticket);setLoading(false);}}
 };
 const updateDemo=useCallback(fn=>{const next=fn(structuredClone(demoRef.current));demoRef.current=next;setDemo(next);return next;},[]);
 if(!demoRegistrations.current)demoRegistrations.current=createDemoRegistrationService({getState:()=>demoRef.current,update:updateDemo,makeTicket:async event=>{
  const QRCode=await import('qrcode'),token='demo-'+crypto.randomUUID(),id='ticket-'+crypto.randomUUID();
  const qrCode=await QRCode.toDataURL(JSON.stringify({demo:true,registrationId:id,eventId:event.id,qrToken:token}));
  return {id,event,qrToken:token,qrCode,status:'registered',createdAt:new Date().toISOString()};
 }});
 const data=mode==='demo'?demo:live;
 const today=mode==='demo'?DEMO_DATE:campusDate();
 let classes=mode==='demo'?demo.classes:(live.timetable || []).filter(c=>String(c.day).toLowerCase()===new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Kolkata',weekday:'long'}).format(new Date()).toLowerCase()).map(c=>{
  const record=recordForClass(c,live.records,live.timetable.filter(t=>t.day===c.day),today);
  const entry={...c,date:today,status:record?.status};return {...entry,status:attendanceStatus(entry,today,campusTime())};
 });
 classes=sortClasses(classes);
 async function mutate(path,body,method='POST',success='Updated') {const value=await request(path,{method,body});await refresh();if(value.partial)notify(`Some sources did not sync: ${(value.errors || []).join('; ')}`,'error');else notify(success);return value;}
 async function register(event,details={}) {
  if(mode==='connected')return mutate(`/events/${event.id}/register`,details,'POST',event.pricePaise?'Payment order created. Your ticket awaits verified payment.':'You’re registered. Your ticket is ready.');
  const ticket=await demoRegistrations.current.register(event.id);notify('Demo registration saved. Your sample ticket is ready.');return ticket;
 }
 async function cancel(ticket) {
  if(mode==='connected')return mutate(`/registrations/${ticket.id}/cancel`,{},'POST','Registration cancelled');
  updateDemo(d=>{cancelDemoRegistration(d,ticket.id);return d;});notify('Demo registration cancelled');
 }
 async function postAction(post,action,body) {
  if(mode==='connected')return mutate(`/feed/${post.id}/${action}`,body,action==='comments'?'POST':'PUT',action==='comments'?'Comment posted':'Updated');
  updateDemo(d=>{const p=d.posts.find(p=>p.id===post.id);if(action==='like'){p.likes+=body.liked?1:-1;p.liked=body.liked;}if(action==='save')p.saved=body.saved;if(action==='comments')p.comments.push({id:crypto.randomUUID(),author:{name:d.profile.name},text:body.text});return d;});
 }
 async function compose(body) {
  if(mode==='connected')return mutate('/feed',body,'POST','Post shared with campus');
  updateDemo(d=>{d.posts.unshift({id:crypto.randomUUID(),author:{id:d.profile.id,name:d.profile.name,image:d.profile.photo,department:d.profile.department},...body,createdAt:new Date().toISOString(),likes:0,liked:false,saved:false,comments:[]});return d;});notify('Your demo post is shared');
 }
 async function editPost(post,text) {
  if(mode==='connected')return mutate(`/feed/${post.id}`,{text},'PATCH','Post updated');
  updateDemo(d=>{const found=d.posts.find(p=>p.id===post.id);if(found?.author.id!==d.profile.id)throw new Error('Only the author can edit this post');found.text=text.trim();return d;});notify('Demo post updated');
 }
 async function deletePost(post) {
  if(mode==='connected')return mutate(`/feed/${post.id}`,{},'DELETE','Post removed');
  updateDemo(d=>{const found=d.posts.find(p=>p.id===post.id);if(found?.author.id!==d.profile.id)throw new Error('Only the author can remove this post');d.posts=d.posts.filter(p=>p.id!==post.id);return d;});notify('Demo post removed');
 }
 async function saveEvent(event) {
  if(mode==='connected')return mutate(`/events/${event.id}/save`,{saved:!event.saved},'PUT',event.saved?'Event bookmark removed':'Event bookmarked');
  updateDemo(d=>{const found=d.events.find(e=>e.id===event.id);found.saved=!found.saved;return d;});notify('Demo event bookmarks updated');
 }
 async function follow(person) {
  if(mode==='connected')return mutate(`/people/${person.id}/follow`,{following:!person.following},'PUT','Connection updated');
  updateDemo(d=>{const p=d.people.find(p=>p.id===person.id);p.following=!p.following;return d;});
 }
 async function placementAction(job,action,body) {
  if(mode==='connected')return mutate(`/placements/${job.id}/${action}`,body,'PUT','Opportunity updated');
  updateDemo(d=>{const p=d.placements.find(p=>p.id===job.id);if(action==='save')p.saved=body.saved;else p.application=body.status;return d;});notify(action==='application'?'Demo application tracking updated':'Saved opportunities updated');
 }
 const value={mode,data:{...data,classes},today,loading,error,message,notify,refresh,signIn,resume,signOut,switchDemo,updateDemo,register,cancel,postAction,compose,editPost,deletePost,saveEvent,follow,placementAction,mutate,resetDemo:()=>{demoRegistrations.current.invalidate();demoRef.current=createDemo();setDemo(demoRef.current);notify('Demo data reset');}};
 return <CampusContext.Provider value={value}>{children}</CampusContext.Provider>;
}
export function useCampus() {return useContext(CampusContext);}
