import {useEffect,useState} from 'react';
import {ExternalLink,RefreshCw} from 'lucide-react';
import {request} from '../lib/api';
import {SectionTitle,EmptyState} from './UI';
export default function UniversityNews(){
 const [news,setNews]=useState(null),[error,setError]=useState('');
 useEffect(()=>{const controller=new AbortController();request('/university/news',{signal:controller.signal}).then(setNews).catch(e=>{if(e.name!=='AbortError')setError(e.message);});return()=>controller.abort();},[]);
 return <section className="panel university-news"><SectionTitle title="From Vel Tech"/>{news?.items?.length?<div className="university-news-list">{news.items.slice(0,3).map(item=><a key={item.url} href={item.url} target="_blank" rel="noopener noreferrer"><div><strong>{item.title}</strong><small>{item.source}</small></div><ExternalLink size={17}/></a>)}</div>:<p className="muted">{error || (news?'No public updates were found on the official university website.':'Fetching the official university website…')}</p>}{news?<p className="page-footnote">Public website updates · fetched {new Date(news.fetchedAt).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'})}. This feed is separate from your private student records.</p>:null}</section>;
}
