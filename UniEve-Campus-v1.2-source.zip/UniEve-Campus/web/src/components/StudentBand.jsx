import {BookOpen,Laptop,Flower2} from 'lucide-react';
import {Avatar} from './UI';
export default function StudentBand({profile,onProfile}) {
 return <section className="student-band"><button className="student-identity" onClick={onProfile} aria-label="Open student details"><Avatar name={profile.name} src={profile.photo || profile.image} size="large"/><div><h2>{profile.name || 'Your student profile'}</h2><p>{profile.studentId || 'Connect your academic account'}</p><span>{profile.department || 'Department not provided'}</span></div></button><dl className="student-facts">{[['Department',profile.department],['Semester',profile.semester],['Batch',profile.batch],['Mentor',profile.mentor || profile.mentorName]].map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value || 'Not provided'}</dd></div>)}</dl><div className="desk-decoration" aria-hidden="true"><BookOpen size={35}/><Laptop size={62}/><Flower2 size={42}/></div></section>;
}
