import {useState} from 'react';
import {CalendarDays,Users,MapPin,Download,LockKeyhole,Ticket} from 'lucide-react';
import {useCampus} from '../context/CampusContext';
import {displayDate} from '../lib/attendance';
import {downloadFile} from '../lib/download';
import {eventStart} from '../lib/calendar';
import {Button,Dialog,Field,Feedback,Badge} from './UI';
async function loadCheckout() {
 if(window.Razorpay)return;
 await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='https://checkout.razorpay.com/v1/checkout.js';script.onload=resolve;script.onerror=()=>reject(new Error('Payment checkout could not load. Retry or contact the organizer.'));document.body.append(script);});
}
export function EventDialog({event,onClose}) {
 const {data,mode,register,cancel,notify,refresh}=useCampus();const [busy,setBusy]=useState(false),[error,setError]=useState(''),[newTicket,setNewTicket]=useState(null);
 const existing=data.registrations.find(t=>String(t.event?.id || t.event?._id)===event.id && t.status!=='cancelled');
 const ticket=existing || newTicket;
 const [details,setDetails]=useState({studentId:data.profile.studentId || '',department:data.profile.department || '',phone:data.profile.phone || data.profile.phoneNumber || '',degree:data.profile.degree || 'B.Tech',yearOfStudy:data.profile.year || ''});
 const set=(key,value)=>setDetails(old=>({...old,[key]:value}));
 const start=async e=>{
  e.preventDefault();setError('');setBusy(true);
  try {
   const result=await register(event,{...details,yearOfStudy:Number(details.yearOfStudy)||null});setNewTicket(result);
   if(result.payment) {
    if(!result.payment.keyId)throw new Error('The organizer has not configured payment checkout. Your order remains pending.');
    await loadCheckout();
    const checkout=new window.Razorpay({key:result.payment.keyId,order_id:result.payment.orderId,amount:result.payment.amount,currency:result.payment.currency,name:'UniEve Campus',description:event.title,prefill:{name:data.profile.name,email:data.profile.email,contact:details.phone},handler:()=>{notify('Payment submitted. Your ticket will appear after the server verifies the payment.');refresh();},modal:{ondismiss:()=>notify('Checkout closed. Your registration is still awaiting payment.')}});checkout.open();
   }
  } catch(e){setError(e.message);}finally{setBusy(false);}
 };
 const calendar=()=>{
  let start;try {start=eventStart(event).toISOString().replace(/[-:]/g,'').replace(/\.\d+Z/,'Z');}catch(error){notify(error.message,'error');return;}
  const escaped=s=>String(s || '').replaceAll('\\','\\\\').replaceAll('\n','\\n').replaceAll(',','\\,').replaceAll(';','\\;');
  downloadFile('unieve-event.ics',`BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//UniEve//Campus//EN\r\nBEGIN:VEVENT\r\nUID:${event.id}@unieve\r\nDTSTAMP:${start}\r\nDTSTART:${start}\r\nSUMMARY:${escaped(event.title)}\r\nLOCATION:${escaped(event.location)}\r\nDESCRIPTION:${mode==='demo'?'Fictional demo event. ':''}${escaped(event.description)}\r\nEND:VEVENT\r\nEND:VCALENDAR`,'text/calendar');
 };
 return <Dialog title={ticket?'Your event ticket':event.title} onClose={onClose} wide><img className="event-detail-image" src={event.image || '/assets/code-jam.png'} alt={`${event.title} poster`}/><div className="event-detail-meta"><span><CalendarDays size={16}/>{displayDate(event.date)} · {event.time}</span><span><MapPin size={16}/>{event.location}</span><span><Users size={16}/>{event.registrationCount} / {event.capacity} seats</span></div><p className="event-description">{event.description}</p><div className="event-organizer"><span>Organized by <strong>{event.organizerName || event.category}</strong></span><Badge status="neutral">{event.scope==='college'?'College-wide':event.scope==='club'?'Club event':'Department event'}</Badge></div>{ticket?<div className="ticket-confirmation"><div className="ticket-status-heading"><h3>{event.title}</h3><Badge status={ticket.status}/></div>{ticket.qrCode?<><img className="ticket-qr" src={ticket.qrCode} alt="Your event check-in QR code"/><p>{mode==='demo'?'Sample ticket · not valid for a real college event':'Show this QR to the authorized event organizer at check-in.'}</p><a className="button primary" href={ticket.qrCode} download={`unieve-ticket-${ticket.id}.png`}><Download size={16}/>Download ticket</a></>:<p>Your paid ticket will be issued after a verified payment confirmation. Refresh to check its status.</p>}<div className="ticket-actions"><Button variant="secondary" onClick={calendar}><CalendarDays size={16}/>Add to calendar</Button>{ticket.status==='registered' && !event.pricePaise?<Button variant="ghost" onClick={async()=>{try {await cancel(ticket);setNewTicket(null);} catch(e){setError(e.message);}}}>Cancel registration</Button>:null}{ticket.status==='payment_pending'?<Button variant="secondary" onClick={start} busy={busy}>Resume checkout</Button>:null}</div></div>:<form onSubmit={start} className="registration-form"><h3>Confirm your registration details</h3><div className="form-grid"><Field label="Student ID" required value={details.studentId} onChange={e=>set('studentId',e.target.value)}/><Field label="Department" required value={details.department} onChange={e=>set('department',e.target.value)}/><Field label="Phone" required type="tel" value={details.phone} onChange={e=>set('phone',e.target.value)}/><Field label="Degree" value={details.degree} onChange={e=>set('degree',e.target.value)}/></div><p className="registration-email">Confirmation account: <strong>{data.profile.email || 'Your signed-in email'}</strong></p><div className="registration-total"><span>{event.pricePaise?'Registration fee':'Registration'}</span><strong>{event.pricePaise?`₹${event.pricePaise/100}`:'Free'}</strong></div><Button busy={busy} type="submit" className="full" disabled={event.registrationCount>=event.capacity}>{event.pricePaise?<LockKeyhole size={16}/>:<Ticket size={16}/>} {event.registrationCount>=event.capacity?'Event full':event.pricePaise?'Continue to secure payment':'Confirm registration'}</Button><small className="muted">{mode==='demo'?'Demo registrations stay in this browser. No payment is collected.':'Your email and ticket remain private to authorized organizers.'}</small></form>}<Feedback error={error}/></Dialog>;
}
