import test from 'node:test';
import assert from 'node:assert/strict';
import {createDeviceSnapshot,sealSnapshot,openSnapshot} from '../src/lib/device-storage.js';
test('snapshot keeps only selected academic fields and excludes secrets and private contact data',()=>{
 const snapshot=createDeviceSnapshot({profile:{name:'Student',studentId:'ID',email:'private',fatherName:'Private',portalPassword:'secret',photo:'private-url'},subjects:[{id:'s',name:'Math',present:9,total:10,token:'secret'}],classes:[],records:[{password:'secret'}]},'connected');
 assert.equal(snapshot.profile.name,'Student');assert.ok(!JSON.stringify(snapshot).includes('private'));assert.ok(!JSON.stringify(snapshot).includes('secret'));assert.ok(!snapshot.records);
});
test('AES device envelope unlocks only with correct passphrase and contains no plaintext records',async()=>{
 const payload={profile:{name:'Student'},source:'connected'};const envelope=await sealSnapshot(payload,'DevicePassphrase123',1,1000);
 assert.ok(!JSON.stringify(envelope).includes('Student'));assert.deepEqual(await openSnapshot(envelope,'DevicePassphrase123',2000),payload);
 await assert.rejects(openSnapshot(envelope,'wrong-password',2000));
});
test('expiry and tampered metadata cannot be bypassed',async()=>{
 const envelope=await sealSnapshot({profile:{name:'Student'}},'DevicePassphrase123',1,1000);
 await assert.rejects(openSnapshot(envelope,'DevicePassphrase123',envelope.expiresAt+1),/expired/);
 await assert.rejects(openSnapshot({...envelope,expiresAt:envelope.expiresAt+1},'DevicePassphrase123',2000));
});
