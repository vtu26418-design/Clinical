import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizePreferences} from '../src/lib/preferences.js';
test('app settings preserve meaningful choices and reject invalid stored options',()=>{
 const settings=normalizePreferences({theme:'dark',textSize:'large',motion:'reduced',refreshSeconds:0,browserAlerts:true});
 assert.equal(settings.theme,'dark');assert.equal(settings.refreshSeconds,0);assert.equal(settings.browserAlerts,true);
 const malformed=normalizePreferences({theme:'bad',refreshSeconds:1,browserAlerts:'true'});
 assert.equal(malformed.theme,'light');assert.equal(malformed.refreshSeconds,60);assert.equal(malformed.browserAlerts,false);
});
