import test from 'node:test';
import assert from 'node:assert/strict';
import {notificationChanges} from '../src/lib/notifications.js';
test('first refresh and account switch establish a baseline without leaking alerts',()=>{
 const first=notificationChanges(null,'alpha',[{id:'one',read:false}]);assert.deepEqual(first.newUnread,[]);
 const switched=notificationChanges(first.state,'beta',[{id:'two',read:false}]);assert.deepEqual(switched.newUnread,[]);
});
test('new unread notification is alerted once and old or read entries are ignored',()=>{
 const first=notificationChanges(null,'alpha',[{id:'one',read:false}]);
 const items=[{id:'one',read:false},{id:'two',read:false},{id:'three',read:true}];
 const next=notificationChanges(first.state,'alpha',items);assert.deepEqual(next.newUnread,['two']);
 assert.deepEqual(notificationChanges(next.state,'alpha',items).newUnread,[]);
});
