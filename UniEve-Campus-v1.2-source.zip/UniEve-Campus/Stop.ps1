$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'scripts/CampusTools.psm1') -Force
Assert-CampusDocker
Push-Location $PSScriptRoot
try {
 & docker compose stop
 if ($LASTEXITCODE -ne 0) { throw 'Docker could not stop the campus services.' }
 Write-Output 'Campus services stopped. Private configuration and Atlas data are retained.'
} finally { Pop-Location }
