"""Short-lived, account-bound manual CAPTCHA sessions; no passwords are retained."""
import asyncio,secrets,time
from app.services.ams.ams_adapter import AmsAdapter

_sessions={}
_lock=asyncio.Lock()

async def prepare_challenge(owner):
    async with _lock:
        now=time.monotonic()
        for key,item in list(_sessions.items()):
            if item['expires']<=now or item['owner']==owner:
                _sessions.pop(key);await item['prepared']['client'].aclose()
        if len(_sessions)>=100:raise RuntimeError('Portal verification is busy. Please retry shortly.')
        prepared=await AmsAdapter().prepare_login();key=secrets.token_urlsafe(32)
        _sessions[key]={'owner':owner,'expires':now+300,'prepared':prepared}
        return {'challengeId':key,'display':prepared['challenge'],'requiresCaptcha':prepared['requiresCaptcha'],'expiresIn':300}

async def take_challenge(owner,key):
    async with _lock:
        item=_sessions.get(key)
        if not item or item['owner']!=owner:raise ValueError('Load a new AMS challenge for your own account.')
        _sessions.pop(key)
        if item['expires']<=time.monotonic():
            await item['prepared']['client'].aclose();raise ValueError('The AMS challenge expired. Load a fresh challenge.')
        return item['prepared']
