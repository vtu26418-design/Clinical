"""Optional read-only extraction from discovered, authenticated AMS pages.

Only explicitly labeled HTML tables are supported. This is a conservative generic
reader, not a verified description of the live AMS attendance/results layout.
Unknown layouts produce no rows; summary counts never create daily records.
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import Any
from urllib.parse import parse_qsl, unquote, urljoin, urlsplit

from bs4 import BeautifulSoup
import httpx


AMS_ORIGIN = 'https://ams.veltech.edu.in'
MAX_ROWS = 4000
MAX_PAGE_BYTES = 2_000_000
MAX_PAGES = 4
REQUEST_TIMEOUT = 10.0
_UNSAFE = re.compile(r'login|logout|validation|forgotpassword|delete|edit|save|update|action', re.I)
_CODE = re.compile(r'(?=.*[A-Za-z])(?=.*\d)[A-Za-z0-9][A-Za-z0-9._/-]{1,39}\Z')

# Matching is explicit; column positions, element IDs and unlabeled text never
# substitute for source labels. Result values retain the source's text.
_HEADERS = {
    'code': {'coursecode', 'subjectcode', 'papercode'},
    'name': {'coursename', 'subjectname', 'papername', 'subject', 'course'},
    'total': {'total', 'totalclasses', 'totalcount', 'classesconducted', 'totalclassesconducted', 'conductedclasses', 'totalperiods'},
    'present': {'present', 'presentcount', 'presentclasses', 'classesattended', 'attendedclasses', 'attended', 'presentperiods'},
    'percentage': {'percentage', 'attendancepercentage', 'attendancepercent', 'attendance', 'percent'},
    'date': {'date', 'attendancedate', 'classdate'},
    'period': {'period', 'periodno', 'periodnumber', 'classperiod', 'hour', 'hourno'},
    'status': {'status', 'attendancestatus'},
    'grade': {'grade', 'lettergrade', 'resultgrade'},
    'credits': {'credits', 'credit', 'coursecredits', 'subjectcredits'},
    'semester': {'semester', 'sem'},
    'cgpa': {'cgpa', 'cumulativegradepointaverage'},
    'gpa': {'gpa', 'sgpa', 'semestergradepointaverage', 'gradepointaverage'},
}


def _normalized(value: str) -> str:
    return re.sub(r'[^a-z0-9]', '', value.lower())


def _same_origin(url: str) -> bool:
    try:
        parts = urlsplit(url)
        return (parts.scheme == 'https' and parts.hostname == 'ams.veltech.edu.in'
                and parts.port in (None, 443) and not parts.username and not parts.password)
    except ValueError:
        return False


def _identifier_key(key: str) -> bool:
    normalized = _normalized(key)
    return (normalized == 'id' or normalized.endswith('id') or any(
        token in normalized for token in ('student', 'username', 'vtu', 'roll', 'registration', 'regno')
    ))


def discover_academic_pages(
    html: str, base_url: str = AMS_ORIGIN, identifiers=(),
) -> list[dict[str, str]]:
    """Return safe view links actually present in the student dashboard.

    Identity-bearing query parameters require an exact session identifier match.
    Non-identity parameters are limited to ordinary academic view filters.
    """
    if not _same_origin(base_url):
        return []
    own_identifiers = {str(item).strip() for item in identifiers if str(item).strip()}
    found = []
    seen = set()
    for anchor in BeautifulSoup(html or '', 'html.parser').find_all('a', href=True):
        href = str(anchor['href']).strip()
        if not href or any(ord(char) < 32 for char in href) or '\\' in href:
            continue
        url = urljoin(base_url, href)
        if not _same_origin(url):
            continue
        parts = urlsplit(url)
        path = unquote(parts.path)
        label = anchor.get_text(' ', strip=True) + ' ' + str(anchor.get('title', ''))
        if not path.lower().endswith('.aspx') or _UNSAFE.search(path + ' ' + label):
            continue
        descriptive = path + ' ' + label
        if re.search(r'attendance', descriptive, re.I):
            kind = 'attendance'
        elif re.search(r'results?|marks?|grades?', descriptive, re.I):
            kind = 'results'
        else:
            continue
        allowed = True
        for key, value in parse_qsl(parts.query, keep_blank_values=True):
            if _UNSAFE.search(key):
                allowed = False
            elif _identifier_key(key):
                allowed = allowed and value in own_identifiers
            elif _normalized(key) not in {'semester', 'sem', 'year', 'academicyear', 'exam', 'examtype', 'type', 'view'}:
                allowed = False
            elif _UNSAFE.search(value) or not re.fullmatch(r'[A-Za-z0-9 _./-]{1,40}', value):
                allowed = False
        if not allowed:
            continue
        # Fragments do not distinguish server pages.
        url = parts._replace(fragment='').geturl()
        if url not in seen:
            found.append({'url': url, 'kind': kind})
            seen.add(url)
    return found


def _empty() -> dict[str, list]:
    return {'summary': [], 'records': [], 'results': []}


def _date(value: str) -> str | None:
    # ISO and textual month forms are unambiguous. Numeric day/month order is
    # intentionally unsupported until a source format has been verified.
    for pattern in ('%Y-%m-%d', '%d-%b-%Y', '%d %b %Y', '%d-%B-%Y', '%d %B %Y'):
        try:
            return datetime.strptime(value, pattern).date().isoformat()
        except ValueError:
            pass
    return None


def _count(value: str) -> int | None:
    if not re.fullmatch(r'\d{1,9}', value):
        return None
    return int(value)


def _percentage(value: str) -> float | None:
    if not re.fullmatch(r'\d{1,3}(?:\.\d{1,4})?\s*%?', value):
        return None
    number = float(value.rstrip('%').strip())
    return number if 0 <= number <= 100 else None


def _status(value: str) -> str:
    return {
        'p': 'present', 'present': 'present',
        'a': 'absent', 'absent': 'absent',
        'od': 'on-duty', 'onduty': 'on-duty',
    }.get(_normalized(value), 'unknown')


def _append_unique(output: dict, seen: dict, kind: str, row: dict) -> None:
    key = tuple(sorted(row.items()))
    if key not in seen[kind] and sum(len(output[k]) for k in seen) < MAX_ROWS:
        output[kind].append(row)
        seen[kind].add(key)


def parse_academic_page(html: str) -> dict[str, list[dict[str, Any]]]:
    """Extract supported, labeled summaries, period records and course results.

    A row needs an identifiable course code. Source summary percentage and counts
    must agree within half a percentage point (rounded source percentages).
    Credits, grade, semester and GPA remain source text, without inferred values.
    """
    output = _empty()
    seen = {key: set() for key in output}
    examined = 0
    soup = BeautifulSoup(html or '', 'html.parser')
    for table in soup.find_all('table'):
        columns = None
        width = 0
        for tr in table.find_all('tr'):
            if tr.find_parent('table') is not table:
                continue
            cells = tr.find_all(['th', 'td'], recursive=False)
            if not cells or any(str(cell.get('colspan', '1')) != '1' or str(cell.get('rowspan', '1')) != '1' for cell in cells):
                continue
            values = [cell.get_text(' ', strip=True) for cell in cells]
            mapped = {}
            ambiguous = False
            for index, value in enumerate(values):
                normalized = _normalized(value)
                for field, aliases in _HEADERS.items():
                    if normalized in aliases:
                        if field in mapped:
                            ambiguous = True
                        mapped[field] = index
            if 'code' in mapped:
                columns = None if ambiguous else mapped
                width = len(cells)
                continue
            if columns is None or len(cells) != width:
                continue
            examined += 1
            if examined > MAX_ROWS:
                return output
            row = {field: values[index] for field, index in columns.items()}
            code = row['code']
            if not _CODE.fullmatch(code):
                continue
            name = row.get('name', '')
            if {'total', 'present', 'percentage'} <= row.keys():
                total, present, percentage = _count(row['total']), _count(row['present']), _percentage(row['percentage'])
                if total is not None and present is not None and percentage is not None and 0 <= present <= total:
                    expected = 100 * present / total if total else 0
                    if abs(percentage - expected) <= 0.51:
                        _append_unique(output, seen, 'summary', {
                            'subjectCode': code, 'subjectName': name, 'totalCount': total,
                            'presentCount': present, 'percentage': percentage,
                        })
            if {'date', 'period', 'status'} <= row.keys() and row['period']:
                date = _date(row['date'])
                if date:
                    _append_unique(output, seen, 'records', {
                        'subjectCode': code, 'subjectName': name, 'date': date,
                        'period': row['period'], 'status': _status(row['status']),
                    })
            if any(row.get(field) for field in ('grade', 'cgpa', 'gpa')):
                result = {'courseCode': code}
                if name:
                    result['courseName'] = name
                result.update({field: row[field] for field in ('grade', 'credits', 'semester', 'cgpa', 'gpa') if row.get(field)})
                _append_unique(output, seen, 'results', result)
    return output


def _login_or_error(html: str, adapter: Any) -> bool:
    soup = BeautifulSoup(html, 'html.parser')
    if soup.select_one('input[type="password"]'):
        return True
    text = soup.get_text(' ', strip=True).lower()
    if any(phrase in text for phrase in ('invalid credentials', 'login failed', 'authentication failed', 'session expired', 'please login', 'please log in')):
        return True
    checker = getattr(adapter, '_contains_authentication_error', None)
    return bool(checker and checker(html))


async def collect_academic_pages(session: dict[str, Any], adapter: Any) -> dict[str, Any]:
    """Use an existing authenticated session for up to four discovered view GETs.

    No login, guessed route, recursive discovery, credential submission or redirect
    occurs here. Failure notes are generic and never contain URLs, HTML or private
    exception details. The caller continues to own the client's cookie session.
    pagesLoaded counts accepted HTML responses, even if their layout is unsupported.
    """
    output = {**_empty(), 'notes': [], 'pagesLoaded': 0}
    notes = output['notes']
    client = session.get('client')
    dashboard = session.get('dashboard_html', '')
    base = session.get('url') or getattr(adapter, 'BASE_URL', AMS_ORIGIN)
    if not client or not dashboard or not _same_origin(base) or _UNSAFE.search(unquote(urlsplit(base).path)):
        notes.append('Authenticated AMS student dashboard unavailable; no academic pages requested.')
        return output
    checker = getattr(adapter, '_looks_like_student_page', None)
    if len(dashboard.encode('utf-8')) > MAX_PAGE_BYTES or _login_or_error(dashboard, adapter) or (checker and not checker(dashboard)):
        notes.append('AMS student dashboard was not accepted; no academic pages requested.')
        return output
    identifiers = [session.get(key) for key in ('username', 'portalUsername', 'vtuNumber', 'studentId', 'rollNumber', 'registrationNumber') if session.get(key)]
    pages = discover_academic_pages(dashboard, base_url=base, identifiers=identifiers)
    if not pages:
        notes.append('No supported academic view links were discovered in the AMS dashboard.')
        return output
    if len(pages) > MAX_PAGES:
        notes.append('Academic page limit reached; additional dashboard links were not loaded.')
    seen = {key: set() for key in ('summary', 'records', 'results')}
    for page in pages[:MAX_PAGES]:
        try:
            response = await client.get(page['url'], timeout=REQUEST_TIMEOUT, follow_redirects=False)
        except httpx.HTTPError:
            notes.append('An AMS academic page could not be loaded; partial data retained.')
            continue
        if not _same_origin(str(response.url)) or not 200 <= response.status_code < 300:
            notes.append('An AMS academic page returned an error or redirect and was discarded.')
            continue
        if len(response.content) > MAX_PAGE_BYTES:
            notes.append('An AMS academic page exceeded the size limit and was discarded.')
            continue
        content_type = response.headers.get('content-type', '').lower()
        if content_type and not any(kind in content_type for kind in ('text/html', 'application/xhtml+xml')):
            notes.append('An AMS academic page did not return HTML and was discarded.')
            continue
        if _UNSAFE.search(unquote(urlsplit(str(response.url)).path)) or _login_or_error(response.text, adapter):
            notes.append('An AMS academic page returned a login or authentication error and was discarded.')
            continue
        parsed = parse_academic_page(response.text)
        output['pagesLoaded'] += 1
        if not any(parsed.values()):
            notes.append('An AMS academic page contained no supported labeled rows; source layout remains unverified.')
        for kind, rows in parsed.items():
            for row in rows:
                if sum(len(output[key]) for key in seen) >= MAX_ROWS:
                    break
                _append_unique(output, seen, kind, row)
    return output
