import secrets
from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, ConfigDict, Field
from app.config.database import get_db
from app.config.settings import settings
from app.services.campus_bridge import campus_session, bind_verified_account

router = APIRouter(prefix='/campus/bridge', tags=['internal-campus'])

def require_service(x_campus_service_key: str = Header(default='')):
    configured = settings.campus_service_key
    if len(configured) < 64 or not secrets.compare_digest(x_campus_service_key.encode('utf-8'), configured.encode('utf-8')):
        raise HTTPException(403, 'Internal campus service authentication required.')

class CampusIdentity(BaseModel):
    model_config = ConfigDict(extra='forbid')
    campusId: str = Field(pattern=r'^[a-f0-9]{24}$')
    email: str = Field(min_length=3, max_length=200, pattern=r'^[^\s@]+@[^\s@]+\.[^\s@]+$')
    name: str = Field(min_length=1, max_length=120)
    department: str = Field(default='', max_length=120)

class VerifiedBinding(CampusIdentity):
    academicId: str = Field(pattern=r'^[a-f0-9]{24}$')

@router.post('/session', dependencies=[Depends(require_service)])
def session(body: CampusIdentity, db=Depends(get_db)):
    return campus_session(db, body.model_dump())

@router.post('/bind', dependencies=[Depends(require_service)])
def bind(body: VerifiedBinding, db=Depends(get_db)):
    return bind_verified_account(db, body.model_dump())
