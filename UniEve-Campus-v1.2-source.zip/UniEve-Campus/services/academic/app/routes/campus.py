"""Private, read-only campus overview of existing per-student source records."""
from fastapi import APIRouter, Depends, HTTPException
from pymongo.database import Database
from app.config.database import get_db
from app.security.permissions import get_current_user
from app.services.base import serialize_document
from app.scheduler.attendance_sync import AttendanceSyncRunner
from pydantic import BaseModel, Field
from app.security.permissions import require_student
from app.security.portal_credentials import decrypt_portal_password
from app.services.ams.ams_adapter import AmsAdapter, AmsAuthenticationError
from app.services.ams.manual_session import prepare_challenge, take_challenge
from app.services.ams.academic_pages import collect_academic_pages
from app.services.ams.storage import store_academic_rows
from app.services.student_service import StudentService
from app.services.timetable_service import TimetableService
from app.services.university_sources import source_status, public_news

router = APIRouter(prefix="/campus", tags=["campus"])

PROFILE_FIELDS = (
    "name", "email", "vtuNumber", "rollNumber", "phoneNumber", "branch",
    "degree", "year", "semester", "section", "batch", "mentorName", "photoUrl",
    "gender", "dateOfBirth", "fatherName", "motherName", "parentName", "parentPhone",
    "academicBankCreditsId", "portalSynced", "lastSyncedAt", "source",
)

@router.get('/sources')
async def sources():
    return await source_status()

@router.get('/news')
async def news():
    try:
        return await public_news()
    except Exception:
        raise HTTPException(502, 'The official university website could not be fetched. Please retry.')

@router.post('/ams/challenge')
async def ams_challenge(current_user: dict = Depends(require_student)):
    try:
        return await prepare_challenge(str(current_user['id']))
    except Exception:
        raise HTTPException(502, 'Could not load the official AMS challenge. Check the portal connection and retry.')

class AmsSyncInput(BaseModel):
    challengeId: str = Field(min_length=20,max_length=100)
    answer: str = Field(min_length=1,max_length=30)

@router.post('/ams/sync')
async def ams_sync(body: AmsSyncInput, current_user: dict = Depends(require_student), db: Database = Depends(get_db)):
    if not current_user.get('portalPasswordEncrypted') or not current_user.get('portalUsername'):
        raise HTTPException(409,'Save your own portal connection before syncing AMS.')
    try:
        prepared=await take_challenge(str(current_user['id']),body.challengeId)
    except ValueError as error:
        raise HTTPException(409,str(error))
    adapter=AmsAdapter();session=None
    try:
        password=decrypt_portal_password(current_user['portalPasswordEncrypted'])
        session=await adapter.login(current_user['portalUsername'],password,captcha=body.answer,prepared=prepared)
        profile=await adapter.get_student_profile(session)
        if not profile:raise ValueError('No student profile was returned.')
        StudentService(db)._save_ams_profile(str(current_user['id']),profile)
        errors=[]
        try:
            await TimetableService(db,ams_adapter=adapter).sync_timetable(str(current_user['id']),session,profile=profile)
        except Exception:
            errors.append('AMS timetable could not be updated; previous records retained.')
        rows=await collect_academic_pages(session,adapter)
        store_academic_rows(db,str(current_user['id']),rows)
        errors.extend(rows['notes'])
        for kind, label in (('summary','attendance totals'),('records','period attendance'),('results','results')):
            if not rows[kind]:errors.append(f'No supported {label} rows were returned; previous records retained.')
        return {'success':True,'source':'ams','partial':bool(errors),'errors':errors,
                'updated':{kind:len(rows[kind]) for kind in ('summary','records','results')}}
    except AmsAuthenticationError:
        raise HTTPException(400,'AMS did not accept the login or CAPTCHA. Load a fresh challenge and check your credentials.')
    except Exception:
        raise HTTPException(502,'AMS data could not be fetched completely. Existing records were preserved; check the source and retry.')
    finally:
        if session:
            await adapter.logout(session)
        else:
            await prepared['client'].aclose()

@router.get("/snapshot")
def snapshot(current_user: dict = Depends(get_current_user), db: Database = Depends(get_db)):
    student_id = str(current_user["id"])
    # Authentication already resolves this student's own document; caller supplies no ID.
    profile = {field: current_user.get(field) for field in PROFILE_FIELDS if current_user.get(field) is not None}
    metadata = db["timetable_metadata"].find_one({"studentId": student_id}) or {}
    source_profile = metadata.get("profile", {})
    if isinstance(source_profile, dict):
        for key in ("batch", "mentorName", "semester", "branch", "rollNumber", "degree"):
            if not profile.get(key) and source_profile.get(key):
                profile[key] = source_profile[key]
    academic = {"bucket": metadata.get("bucket"), "courses": metadata.get("courses", []),
                "updatedAt": metadata.get("updatedAt"), "source": metadata.get("source")}
    # Only display additional academic modules when present in the source database.
    for field in ("results", "examinations", "fees", "documents", "requests"):
        if current_user.get(field) is not None:
            academic[field] = current_user[field]
    result={"profile": profile, "academic": academic}
    if current_user.get('amsAttendanceSummary') is not None:
        result['attendanceSummary']=current_user['amsAttendanceSummary']
    if current_user.get('amsClassRecords') is not None:
        result['attendanceRecords']=current_user['amsClassRecords']
    return serialize_document(result)

@router.post("/sync")
async def sync(current_user: dict = Depends(get_current_user), db: Database = Depends(get_db)):
    if current_user.get("role") != "student":
        raise HTTPException(status_code=403, detail="Student account required for portal sync")
    raise HTTPException(status_code=410, detail='The parent-portal sync is retired. Use the manual AMS connection for your own records.')
