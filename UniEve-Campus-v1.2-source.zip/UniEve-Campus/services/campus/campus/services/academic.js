import axios from 'axios';
import {fail} from '../security.js';
export function academicClient(baseURL,serviceKey='') {
  const client=axios.create({baseURL,timeout:60000,maxRedirects:0});
  return {
    async bootstrap(identity,academicId) {
      if(!serviceKey) fail(503,'The internal academic workspace connection is not configured');
      try {return (await client.post(academicId?'/campus/bridge/bind':'/campus/bridge/session',{...identity,...(academicId?{academicId}:{})},{headers:{'X-Campus-Service-Key':serviceKey}})).data;}
      catch(error) {fail(error.response?.status || 502,error.response?.data?.detail || 'The academic workspace could not be prepared. Retry after the service starts.');}
    },
    async login(email,password) {
      const {data}=await client.post('/auth/login',{email,password});
      const token=data.accessToken;
      const me=await client.get('/auth/me',{headers:{Authorization:`Bearer ${token}`}});
      return {token,user:me.data};
    },
    async request(token,path,method='GET',body) {
      try {return (await client.request({url:path,method,data:body,headers:{Authorization:`Bearer ${token}`}})).data;}
      catch(error) {
        const status=error.response?.status;
        if(status===401) fail(401,'Academic session expired. Reconnect your academic account.');
        if(status===403) fail(403,'The linked academic account cannot access this resource.');
        fail(status && status<500?status:502,error.response?.data?.detail || 'Academic service is unavailable. Retry after it starts.');
      }
    }
  };
}
