import Event from '../../models/Event.js';
import Registration from '../../models/EventRegistration.js';
import {Audit} from '../models.js';
import {canCreateEvent,canManageEvent} from '../policy.js';
import {fail,validateId,httpUrl,checkWebhook} from '../security.js';
import {registerForEvent,checkIn,confirmPayment,cancelRegistration} from '../services/registration.js';

export function registerEvents(router,config) {
  router.get('/events',config.auth,async(req,res)=>{
    const events=await Event.find().sort({date:1}).limit(200).lean();
    const tickets=await Registration.find({user:req.user._id}).select('event status').lean();
    res.json(events.map(e=>({...e,id:String(e._id),saved:(req.user.savedCampusEvents || []).map(String).includes(String(e._id)),registered:tickets.find(t=>String(t.event)===String(e._id))?.status || null,canManage:canManageEvent(req.user,e)})));
  });
  router.put('/events/:id/save',config.auth,async(req,res)=>{
    validateId(req.params.id);if(typeof req.body.saved!=='boolean')fail(400,'Choose a bookmark state');
    if(!await Event.exists({_id:req.params.id}))fail(404,'Event not found');
    await req.user.constructor.updateOne({_id:req.user._id},req.body.saved?{$addToSet:{savedCampusEvents:req.params.id}}:{$pull:{savedCampusEvents:req.params.id}});
    res.json({saved:req.body.saved});
  });
  router.post('/events',config.auth,async(req,res)=>{
    const {scope,department='',club=''}=req.body || {};
    if(!['club','department','college'].includes(scope) || typeof department!=='string' || department.length>120 || typeof club!=='string' || club.length>120) fail(400,'Choose a valid event scope, department and club');
    if(!canCreateEvent(req.user,{scope,department,club})) fail(403,'Your role cannot create events in this scope');
    const {title,description='',date,time,location,category='General',capacity=100,pricePaise=0,deadline}=req.body;
    if(typeof title!=='string' || !title.trim() || title.length>150 || typeof description!=='string' || description.length>5000 || typeof location!=='string' || !location.trim() || typeof time!=='string' || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time) || typeof category!=='string' || !category.trim() || category.length>80 || !Number.isInteger(capacity) || capacity<1 || capacity>100000 || !Number.isInteger(pricePaise) || pricePaise<0 || pricePaise>10000000 || !['club','department','college'].includes(scope)) fail(400,'Enter valid event details, scope, capacity and price');
    if(typeof date!=='string' || !date || !Number.isFinite(new Date(date).getTime()) || new Date(date)<new Date()) fail(400,'Choose a future event date');
    if(deadline && (typeof deadline!=='string' || !Number.isFinite(new Date(deadline).getTime()) || new Date(deadline)>new Date(date))) fail(400,'Registration deadline must be before the event');
    if(req.body.image!==undefined && typeof req.body.image!=='string') fail(400,'Enter a valid event image URL');
    const image=req.body.image?.startsWith('/assets/')?req.body.image:httpUrl(req.body.image || '') || '/assets/code-jam.png';
    const event=await Event.create({createdBy:req.user._id,title:title.trim(),description,date,time,location,category,capacity,pricePaise,scope,department,club,deadline:deadline || null,image,organizerName:req.user.name || req.user.username});
    await Audit.create({actor:req.user._id,action:'event.create',target:event.id});
    res.status(201).json({...event.toObject(),id:event.id});
  });
  router.post('/events/:id/register',config.auth,async(req,res)=>{
    const ticket=await registerForEvent(req.user,req.params.id,config.payment,req.body);
    res.json({...ticket.toObject(),id:ticket.id,payment:ticket.status==='payment_pending' && ticket.paymentOrderId?{orderId:ticket.paymentOrderId,keyId:config.payment.keyId,amount:ticket.amountPaise,currency:ticket.currency}:null});
  });
  router.get('/registrations',config.auth,async(req,res)=>{
    const tickets=await Registration.find({user:req.user._id}).populate('event').sort({createdAt:-1});
    res.json(tickets.map(t=>({...t.toObject(),id:t.id})));
  });
  router.post('/registrations/:id/cancel',config.auth,async(req,res)=>res.json(await cancelRegistration(req.user,req.params.id)));
  router.get('/events/:id/participants',config.auth,async(req,res)=>{
    validateId(req.params.id);const event=await Event.findById(req.params.id);
    if(!canManageEvent(req.user,event)) fail(403,'Organizer access required for this event');
    const tickets=await Registration.find({event:event.id}).populate('user','name username').select('-qrToken -qrCode -paymentOrderId -paymentId').lean();
    res.json(tickets.map(t=>({...t,id:String(t._id)})));
  });
  router.post('/check-in',config.auth,async(req,res)=>{
    const {registrationId,qrToken}=req.body;
    if(qrToken!==undefined && (typeof qrToken!=='string' || qrToken.length>128)) fail(400,'Invalid QR token');
    const ticket=await checkIn(req.user,registrationId,qrToken);
    await Audit.create({actor:req.user._id,action:'event.check-in',target:ticket.id});res.json({id:ticket.id,status:ticket.status});
  });
  router.post('/payments/webhook',async(req,res)=>{
    if(!checkWebhook(req.body,req.headers['x-razorpay-signature'],config.webhookSecret)) fail(401,'Invalid webhook signature');
    let payload;try {payload=JSON.parse(req.body.toString());} catch {fail(400,'Invalid webhook payload');}
    if(!payload || typeof payload!=='object' || Array.isArray(payload) || typeof payload.event!=='string') fail(400,'Invalid webhook payload');
    if(payload.event!=='payment.captured') return res.json({received:true,ignored:true});
    const payment=payload.payload?.payment?.entity;
    if(!payment?.order_id || !payment?.id) fail(400,'Invalid captured payment');
    const ticket=await confirmPayment(payment);res.json({received:true,confirmed:!!ticket});
  });
}
