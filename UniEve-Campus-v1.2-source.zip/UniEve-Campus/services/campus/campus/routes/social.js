import {CampusPost,Notice} from '../models.js';
import User from '../../models/User.js';
import LegacyPost from '../../models/Post.js';
import LegacyComment from '../../models/Comment.js';
import Follow from '../../models/Follow.js';
import Notification from '../../models/Notification.js';
import {fail,validateId,httpUrl} from '../security.js';
const authorView=user=>({id:String(user?._id || ''),name:user?.name || user?.username || 'Campus member',username:user?.username,image:user?.image || '',department:user?.department || ''});
const includesId=(ids,id)=>(ids || []).some(value=>String(value)===String(id));
const canRead=(author,user)=>author && (!author.isPrivate || String(author._id)===String(user._id) || includesId(user.following,author._id));
const commentView=comment=>({id:String(comment._id),text:comment.text,createdAt:comment.createdAt,author:authorView(comment.user)});
export function registerSocial(router,config) {
  async function ownPost(id,user) {
    validateId(id);
    let post=await CampusPost.findById(id).populate('user','name username image department isPrivate');
    const legacy=!post;
    if(legacy) post=await LegacyPost.findOne({_id:id,isArchived:{$ne:true}}).populate('user','name username image department isPrivate');
    if(!post || !post.user) fail(404,'Post not found');
    if(!canRead(post.user,user)) fail(403,'This profile is private');
    return {post,legacy};
  }
  router.get('/feed',config.auth,async(req,res)=>{
    const posts=await CampusPost.find().sort({createdAt:-1}).limit(100).populate('user','name username image department isPrivate').populate('comments.user','name username image department');
    const visible=posts.filter(p=>canRead(p.user,req.user));
    const data=visible.map(p=>({id:p.id,canEdit:String(p.user._id)===req.user.id,author:authorView(p.user),text:p.text,image:p.image,category:p.category,createdAt:p.createdAt,likes:p.likes.length,liked:includesId(p.likes,req.user._id),saved:includesId(p.savedBy,req.user._id),comments:p.comments.map(commentView)}));
    const legacy=await LegacyPost.find({isArchived:{$ne:true}}).sort({createdAt:-1}).limit(50).populate('user','name username image department isPrivate').populate({path:'comments',select:'text createdAt user',populate:{path:'user',select:'name username image department'}}).lean();
    for(const p of legacy) if(canRead(p.user,req.user)) data.push({id:String(p._id),canEdit:String(p.user._id)===req.user.id,author:authorView(p.user),text:p.caption,image:p.type==='image'?p.media:'',video:p.type==='video'?p.media:'',category:'campus',createdAt:p.createdAt,likes:p.likes?.length || 0,liked:includesId(p.likes,req.user._id),saved:includesId(req.user.savedPosts,p._id),comments:(p.comments || []).map(commentView),legacy:true});
    data.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));res.json(data);
  });
  router.post('/feed',config.auth,async(req,res)=>{
    const {text,category='campus',image=''}=req.body;
    if(typeof text!=='string' || !text.trim() || text.length>2200 || !['campus','achievement','project','opportunity'].includes(category)) fail(400,'Write a post up to 2,200 characters and choose a category');
    const post=await CampusPost.create({user:req.user._id,text:text.trim(),category,image:httpUrl(image)});res.status(201).json({id:post.id});
  });
  router.patch('/feed/:id',config.auth,async(req,res)=>{
    const {post,legacy}=await ownPost(req.params.id,req.user);
    if(String(post.user._id)!==req.user.id)fail(403,'Only the author can edit this post');
    const {text}=req.body,max=legacy?2200:2200;
    if(typeof text!=='string' || !text.trim() || text.length>max)fail(400,'Write a post up to 2,200 characters');
    await (legacy?LegacyPost:CampusPost).updateOne({_id:post._id,user:req.user._id},{$set:{[legacy?'caption':'text']:text.trim()}});
    res.json({success:true});
  });
  router.delete('/feed/:id',config.auth,async(req,res)=>{
    const {post,legacy}=await ownPost(req.params.id,req.user);
    if(String(post.user._id)!==req.user.id)fail(403,'Only the author can remove this post');
    if(legacy)await LegacyPost.updateOne({_id:post._id,user:req.user._id},{$set:{isArchived:true}});
    else await CampusPost.deleteOne({_id:post._id,user:req.user._id});
    res.json({success:true});
  });
  router.put('/feed/:id/like',config.auth,async(req,res)=>{
    if(typeof req.body.liked!=='boolean') fail(400,'Like state must be true or false');
    const {post,legacy}=await ownPost(req.params.id,req.user);
    await (legacy?LegacyPost:CampusPost).updateOne({_id:post._id},req.body.liked?{$addToSet:{likes:req.user._id}}:{$pull:{likes:req.user._id}});res.json({liked:req.body.liked});
  });
  router.put('/feed/:id/save',config.auth,async(req,res)=>{
    if(typeof req.body.saved!=='boolean') fail(400,'Save state must be true or false');
    const {post,legacy}=await ownPost(req.params.id,req.user);
    if(legacy) await User.updateOne({_id:req.user._id},req.body.saved?{$addToSet:{savedPosts:post._id}}:{$pull:{savedPosts:post._id}});
    else await CampusPost.updateOne({_id:post._id},req.body.saved?{$addToSet:{savedBy:req.user._id}}:{$pull:{savedBy:req.user._id}});
    res.json({saved:req.body.saved});
  });
  router.post('/feed/:id/comments',config.auth,async(req,res)=>{
    const {post,legacy}=await ownPost(req.params.id,req.user);
    const text=req.body.text,maxLength=legacy?300:500;
    if(typeof text!=='string' || !text.trim() || text.trim().length>maxLength) fail(400,`Write a comment up to ${maxLength} characters`);
    if(legacy) {
      const comment=await LegacyComment.create({user:req.user._id,post:post._id,targetId:post._id,targetType:'post',text:text.trim()});
      const updated=await LegacyPost.updateOne({_id:post._id,isArchived:{$ne:true}},{$push:{comments:comment._id}});
      if(!updated.matchedCount) {await LegacyComment.deleteOne({_id:comment._id});fail(404,'Post not found');}
    } else await CampusPost.updateOne({_id:post._id},{$push:{comments:{user:req.user._id,text:text.trim(),createdAt:new Date()}}});
    res.status(201).json({success:true});
  });
  router.get('/people',config.auth,async(req,res)=>{
    const users=await User.find({_id:{$ne:req.user._id},isPrivate:false}).select('name username image department bio followers').limit(30).lean();
    res.json(users.map(u=>({...authorView(u),bio:u.bio,following:req.user.following.map(String).includes(String(u._id)),followers:u.followers.length})));
  });
  router.put('/people/:id/follow',config.auth,async(req,res)=>{
    validateId(req.params.id);if(req.params.id===req.user.id) fail(400,'You cannot follow yourself');
    if(typeof req.body.following!=='boolean') fail(400,'Follow state must be true or false');
    const target=await User.findById(req.params.id);if(!target) fail(404,'Member not found');
    if(target.isPrivate && req.body.following) {
      if(!includesId(req.user.following,target._id)) fail(403,'Follow private profiles through the original app request flow');
      return res.json({following:true});
    }
    if(req.body.following) await Follow.findOneAndUpdate({from:req.user._id,to:target._id},{$set:{status:'accepted'}},{upsert:true});
    else {
      await Follow.deleteOne({from:req.user._id,to:target._id});
      await Notification.deleteMany({toUser:target._id,fromUser:req.user._id,type:{$in:['follow','follow_request']}});
    }
    await Promise.all([User.updateOne({_id:req.user._id},req.body.following?{$addToSet:{following:target._id}}:{$pull:{following:target._id}}),User.updateOne({_id:target._id},req.body.following?{$addToSet:{followers:req.user._id}}:{$pull:{followers:req.user._id}})]);res.json({following:req.body.following});
  });
  router.get('/notices',config.auth,async(req,res)=>res.json(await Notice.find({$or:[{department:''},{department:req.user.department}]}).sort({createdAt:-1}).limit(100).lean()));
}
