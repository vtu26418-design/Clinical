import bcrypt from 'bcrypt';
import User from '../../models/User.js';
import Event from '../../models/Event.js';
import {Audit,Notice} from '../models.js';
import {ROLES,campusRole,publicUser,canManageEvent} from '../policy.js';
import {fail,validateId,httpUrl} from '../security.js';
export function registerManagement(router,config) {
  const admin=(req,_res,next)=>{if(campusRole(req.user)!=='admin') fail(403,'Administrator access required');next();};
  router.get('/management',config.auth,async(req,res)=>{
    if(campusRole(req.user)==='student') fail(403,'Staff access required');
    const all=await Event.find().lean(),events=all.filter(e=>canManageEvent(req.user,e));
    res.json({events:events.map(e=>({...e,id:String(e._id)})),roles:ROLES,users:campusRole(req.user)==='admin'?(await User.find().limit(200)).map(publicUser):[],audit:campusRole(req.user)==='admin'?await Audit.find().sort({createdAt:-1}).limit(30).lean():[]});
  });
  router.patch('/management/users/:id',config.auth,admin,async(req,res)=>{
    validateId(req.params.id);const {campusRole:role,department='',club=''}=req.body;
    if(!ROLES.includes(role) || typeof department!=='string' || typeof club!=='string' || department.length>120 || club.length>120) fail(400,'Choose a valid role and scope');
    if(['club_organizer','department_coordinator'].includes(role) && !department.trim()) fail(400,'A department is required for this role');
    if(role==='club_organizer' && !club.trim()) fail(400,'A club is required for a club organizer');
    if(req.user.id===req.params.id && role!=='admin') fail(409,'Ask another administrator to change your own administrator role');
    const user=await User.findByIdAndUpdate(req.params.id,{$set:{campusRole:role,role:role==='admin'?'admin':'student',department:department.trim(),club:club.trim()}},{returnDocument:'after'});
    if(!user) fail(404,'User not found');await Audit.create({actor:req.user._id,action:'role.assign',target:user.id,details:role});res.json(publicUser(user));
  });
  router.post('/management/users',config.auth,admin,async(req,res)=>{
    const {name,email,username,password,department='',studentId=''}=req.body;
    if(typeof name!=='string' || !name.trim() || typeof email!=='string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || typeof username!=='string' || !/^[a-z0-9_.]{3,30}$/.test(username) || typeof password!=='string' || password.length<12 || password.length>200) fail(400,'Enter valid account details and a password of at least 12 characters');
    if(Buffer.byteLength(password,'utf8')>72) fail(400,'Use a password of at most 72 UTF-8 bytes. Non-ASCII characters may use more than one byte.');
    const user=await User.create({name:name.trim(),email:email.toLowerCase().trim(),username,password:await bcrypt.hash(password,12),department,studentId,role:'student',campusRole:'student',isVerified:true});
    await Audit.create({actor:req.user._id,action:'user.create',target:user.id});res.status(201).json(publicUser(user));
  });
  router.post('/notices',config.auth,async(req,res)=>{
    const role=campusRole(req.user);if(!['admin','department_coordinator','college_event_manager','placement_officer'].includes(role)) fail(403,'Staff publishing access required');
    const {title,body='',category='General',department='',url=''}=req.body;
    if(typeof title!=='string' || !title.trim() || title.length>160 || typeof body!=='string' || body.length>5000) fail(400,'Enter a notice title and content');
    if(role==='department_coordinator' && department!==req.user.department) fail(403,'You can only publish for your department');
    const notice=await Notice.create({title:title.trim(),body,category,department,url:httpUrl(url),createdBy:req.user._id});res.status(201).json({id:notice.id});
  });
}
