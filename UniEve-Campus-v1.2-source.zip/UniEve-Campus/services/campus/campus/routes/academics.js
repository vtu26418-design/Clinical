import {AcademicLink} from '../models.js';
import {encryptToken,decryptToken,fail} from '../security.js';

export function registerAcademics(router,config) {
  router.get('/university/sources',async(_req,res)=>res.json(await config.academic.request('','/campus/sources')));
  router.get('/university/news',async(_req,res)=>res.json(await config.academic.request('','/campus/news')));
  async function managedLink(user,academicId) {
    if(!config.linkKey) fail(503,'The persistent academic encryption key is missing');
    const result=await config.academic.bootstrap({campusId:String(user._id),email:user.email,name:user.name,department:user.department || ''},academicId);
    if(result.user?.email?.toLowerCase()!==user.email || !result.token || !result.user.id) fail(403,'Academic workspace identity does not match your campus account');
    let link;try {link=await AcademicLink.findOneAndUpdate({user:user._id},{$set:{academicId:result.user.id,email:user.email,sealedToken:encryptToken(result.token,config.linkKey),managed:true},$setOnInsert:{linkedAt:new Date()}},{upsert:true,returnDocument:'after'}).select('+sealedToken');} catch(error){if(error.code!==11000)throw error;link=await AcademicLink.findOne({user:user._id}).select('+sealedToken');if(!link || link.academicId!==result.user.id)throw error;}
    return {link,token:result.token};
  }
  async function linkFor(user) {
    const link=await AcademicLink.findOne({user:user._id}).select('+sealedToken');
    if(config.bridgeEnabled && (!link || link.managed)) return managedLink(user);
    if(!link) fail(409,'Connect your academic account in Settings to load your student data');
    return {link,token:decryptToken(link.sealedToken,config.linkKey)};
  }
  router.get('/academics/status',config.auth,async(req,res)=>{
    let link=await AcademicLink.findOne({user:req.user._id});
    if(config.bridgeEnabled && (!link || link.managed)) {
      try {({link}=await linkFor(req.user));}
      catch(error) {if(error.status===409)return res.json({connected:false,automatic:true,migrationRequired:true,message:error.message});throw error;}
    }
    res.json({connected:!!link,managed:!!link?.managed,automatic:config.bridgeEnabled,email:link?.email,linkedAt:link?.linkedAt});
  });
  router.post('/academics/link',config.auth,async(req,res)=>{
    const {email,password}=req.body;
    if(typeof email!=='string' || typeof password!=='string' || password.length>200) fail(400,'Enter your academic account email and password');
    if(email.trim().toLowerCase()!==req.user.email) fail(403,'Only your own academic account can be linked');
    if(!config.linkKey) fail(503,'The administrator must configure the persistent academic-link encryption key');
    let result;try {result=await config.academic.login(req.user.email,password);} catch {fail(401,'Could not verify your academic account credentials');}
    if(result.user?.email?.toLowerCase()!==req.user.email || !result.token || !result.user.id) fail(403,'Academic identity does not match your campus account');
    if(config.bridgeEnabled) {await managedLink(req.user,result.user.id);return res.json({connected:true,managed:true,email:req.user.email});}
    await AcademicLink.findOneAndUpdate({user:req.user._id},{$set:{academicId:result.user.id,email:req.user.email,sealedToken:encryptToken(result.token,config.linkKey),linkedAt:new Date()}},{upsert:true});
    res.json({connected:true,email:req.user.email});
  });
  router.delete('/academics/link',config.auth,async(req,res)=>{const link=await AcademicLink.findOne({user:req.user._id});if(link?.managed)fail(409,'Your academic workspace belongs to your campus account. Sign out to end access.');await AcademicLink.deleteOne({user:req.user._id});res.json({connected:false});});
  router.patch('/academics/notifications/read',config.auth,async(req,res)=>{
    const {token}=await linkFor(req.user);
    res.json(await config.academic.request(token,'/notifications/read-all','PATCH',{}));
  });
  router.get('/academics/overview',config.auth,async(req,res)=>{
    const {token}=await linkFor(req.user);
    const paths={profile:'/profile',summary:'/attendance/summary',records:'/attendance',timetable:'/timetable',subjects:'/subjects',snapshot:'/campus/snapshot',notifications:'/notifications'};
    const results=await Promise.allSettled(Object.values(paths).map(path=>config.academic.request(token,path)));
    const data={},errors={};Object.keys(paths).forEach((key,i)=>{if(results[i].status==='fulfilled') data[key]=results[i].value;else errors[key]=results[i].reason.message;});
    if(!data.profile) fail(502,errors.profile || 'Academic profile unavailable');
    const snapshot=data.snapshot && !Array.isArray(data.snapshot)?data.snapshot:{};
    if(snapshot.profile) data.profile={...data.profile,...snapshot.profile};
    if(Array.isArray(snapshot.attendanceSummary))data.summary=snapshot.attendanceSummary;
    if(Array.isArray(snapshot.attendanceRecords))data.records=snapshot.attendanceRecords;
    data.academic=snapshot.academic || {};delete data.snapshot;
    res.json({...data,errors,lastSyncedAt:data.profile.lastSyncedAt || null,source:data.profile.source || 'academic-service'});
  });
  router.post('/academics/portal',config.auth,async(req,res)=>{
    const {token}=await linkFor(req.user);
    const {portalUsername,portalPassword}=req.body;
    if(typeof portalUsername!=='string' || typeof portalPassword!=='string' || !portalPassword || portalPassword.length>200) fail(400,'Enter your authorized portal login');
    const result=await config.academic.request(token,'/profile/portal-credentials','PUT',{portalUsername,portalPassword});
    res.json(result);
  });
  router.post('/academics/sync',config.auth,async(req,res)=>{
    fail(410,'The parent-portal sync is retired. Load a fresh AMS challenge in Settings to sync your own records.');
  });
  router.post('/academics/ams/challenge',config.auth,async(req,res)=>{
    const {token}=await linkFor(req.user);
    res.json(await config.academic.request(token,'/campus/ams/challenge','POST',{}));
  });
  router.post('/academics/ams/sync',config.auth,async(req,res)=>{
    const {token}=await linkFor(req.user);
    const {challengeId,answer}=req.body || {};
    if(typeof challengeId!=='string' || challengeId.length>100 || typeof answer!=='string' || !answer.trim() || answer.length>30)fail(400,'Enter the official challenge answer');
    res.json(await config.academic.request(token,'/campus/ams/sync','POST',{challengeId,answer}));
  });
}
