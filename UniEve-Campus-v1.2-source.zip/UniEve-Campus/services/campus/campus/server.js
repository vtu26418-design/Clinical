import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import path from 'node:path';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {rateLimit} from 'express-rate-limit';
import User from '../models/User.js';
import Event from '../models/Event.js';
import Registration from '../models/EventRegistration.js';
import {Session,AcademicLink} from './models.js';
import {hashToken,fail} from './security.js';
import {academicClient} from './services/academic.js';
import {razorpayProvider} from './services/payment.js';
import {registerAuth} from './routes/auth.js';
import {registerAcademics} from './routes/academics.js';
import {registerEvents} from './routes/events.js';
import {registerSocial} from './routes/social.js';
import {registerPlacements} from './routes/placements.js';
import {registerManagement} from './routes/management.js';
import {registerDownloads} from './routes/downloads.js';

export function createCampusApp(options={}) {
  const production=options.production ?? process.env.NODE_ENV==='production';
  const cookieSecure=options.cookieSecure ?? (process.env.CAMPUS_COOKIE_SECURE===undefined?production:process.env.CAMPUS_COOKIE_SECURE==='true');
  const config={production,cookieSecure,bridgeEnabled:process.env.CAMPUS_BRIDGE_ENABLED==='true',origins:(process.env.CAMPUS_ORIGINS || 'http://localhost:5180,http://127.0.0.1:5180').split(','),linkKey:process.env.CAMPUS_LINK_KEY,webhookSecret:process.env.RAZORPAY_WEBHOOK_SECRET,payment:razorpayProvider(process.env.RAZORPAY_KEY_ID,process.env.RAZORPAY_KEY_SECRET),academic:academicClient(process.env.ACADEMIC_API_URL || 'http://127.0.0.1:8000/api/v1',process.env.CAMPUS_SERVICE_KEY),...options};
  if(production && !cookieSecure && config.origins.some(origin=>!['localhost','127.0.0.1','[::1]'].includes(new URL(origin).hostname))) throw new Error('HTTP session cookies are allowed only for localhost development origins. Use secure cookies for hosted deployment.');
  const app=express();app.disable('x-powered-by');
  app.use((req,res,next)=>{res.set({'X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Frame-Options':'DENY'});if(req.path.startsWith('/api/')) res.set('Cache-Control','no-store');next();});
  app.use('/api/campus/payments/webhook',express.raw({type:'application/json',limit:'256kb'}));
  app.use(express.json({limit:'1mb'}));
  const router=express.Router();
  router.use(rateLimit({windowMs:60000,limit:120,message:{message:'Too many requests. Wait a minute before retrying.'},standardHeaders:'draft-8',legacyHeaders:false}));
  router.use('/login',rateLimit({windowMs:15*60000,limit:options.loginLimit || 15,message:{message:'Too many sign-in attempts. Please wait before retrying.'},standardHeaders:'draft-8',legacyHeaders:false}));
  config.auth=(req,_res,next)=>{if(!req.user || !req.session) fail(401,'Sign in to your campus account');next();};
  router.use(async(req,_res,next)=>{
    if(req.path==='/payments/webhook') return next();
    const cookie=(req.headers.cookie || '').split(';').map(s=>s.trim()).find(s=>s.startsWith('campus_session='));
    const token=cookie?.slice('campus_session='.length);
    if(token && /^[a-f0-9]{64}$/.test(token)) {
      req.session=await Session.findOne({tokenHash:hashToken(token),expiresAt:{$gt:new Date()}});
      if(req.session) req.user=await User.findById(req.session.user);
    }
    if(!['GET','HEAD','OPTIONS'].includes(req.method)) {
      if(!config.origins.includes(req.headers.origin)) fail(403,'Request origin is not allowed');
      if(req.session && req.headers['x-csrf-token']!==req.session.csrfToken) fail(403,'Security token missing. Refresh the page and retry.');
    }
    next();
  });
  router.get('/health',async(_req,res)=>{await mongoose.connection.db.command({ping:1});res.json({status:'ok',database:'connected'});});
  registerAuth(router,config);registerAcademics(router,config);registerEvents(router,config);registerSocial(router,config);registerPlacements(router,config);registerManagement(router,config);
  app.use('/api/campus',router);
  registerDownloads(router,{directory:options.downloadDirectory,dist:process.env.CAMPUS_WEB_DIST || path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../../web/dist')});
  app.use('/api',(_req,res)=>res.status(404).json({message:'Endpoint not found'}));
  const dist=process.env.CAMPUS_WEB_DIST || path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../../web/dist');
  if(fs.existsSync(path.join(dist,'index.html'))) {app.use(express.static(dist));app.get('/{*path}',(_req,res)=>res.sendFile(path.join(dist,'index.html')));}
  app.use((error,_req,res,_next)=>{
    const status=error.status || (error.code===11000?409:error.name==='ValidationError'?400:500);
    if(status>=500) console.error('Campus API error:',error.name);
    res.status(status).json({message:status===500?'The request could not be completed. Please retry.':error.code===11000?'This record already exists':error.message});
  });
  return app;
}
if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  dotenv.config({path:process.env.CAMPUS_ENV_FILE || path.resolve(path.dirname(fileURLToPath(import.meta.url)),'.env')});
  const mongoUri=process.env.MONGODB_URI;if(!mongoUri) throw new Error('Set MONGODB_URI in campus/.env');
  await mongoose.connect(mongoUri);
  // Enforce uniqueness before accepting registrations or account links.
  await Promise.all([User.init(),Event.init(),Registration.init(),Session.init(),AcademicLink.init()]);
  // Initialize absent counters for pre-existing events without changing their source fields.
  for(const e of await Event.collection.find({registrationCount:{$exists:false}}).toArray()) {
    const count=await Registration.countDocuments({event:e._id,status:{$in:['registered','attended','payment_pending']}});
    await Event.updateOne({_id:e._id,registrationCount:{$exists:false}},{$set:{registrationCount:count}});
  }
  const app=createCampusApp();app.listen(Number(process.env.CAMPUS_PORT || 4100),process.env.CAMPUS_HOST || '127.0.0.1',()=>console.log('UniEve Campus API started'));
}
