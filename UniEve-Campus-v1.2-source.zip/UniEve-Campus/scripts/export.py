"""Export one self-contained source project and its built PWA, never private state."""
import argparse, hashlib, json, re, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EXCLUDED={'.git','.private','node_modules','dist','__pycache__','.venv','.pytest_cache','uploads','artifacts','downloads','logs','target'}

def allowed(path):
 relative=path.relative_to(ROOT)
 return not path.is_symlink() and not any(part in EXCLUDED for part in relative.parts) and path.name not in {'.progress.md','.env'} and not path.name.startswith('.env.') and path.suffix not in {'.log','.pyc','.zip'}

def export(destination):
 destination.mkdir(parents=True,exist_ok=True)
 source=destination/'UniEve-Campus-v1.2-source.zip'
 with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for path in sorted(ROOT.rglob('*')):
   if path.is_file() and (allowed(path) or path==ROOT/'.env.example'):
    archive.write(path,'UniEve-Campus/'+path.relative_to(ROOT).as_posix())
 dist=ROOT/'web/dist'
 if not (dist/'index.html').is_file():raise RuntimeError('Build web first: npm --prefix web run build')
 mobile=destination/'UniEve-Campus-v1.2-mobile-web.zip'
 with zipfile.ZipFile(mobile,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for path in sorted(dist.rglob('*')):
   if path.is_file():archive.write(path,'UniEve-Campus-Mobile-Web/'+path.relative_to(dist).as_posix())
  archive.writestr('UniEve-Campus-Mobile-Web/README.md','# UniEve Campus V1.2 PWA\n\nBuilt static preview. Serve at an HTTPS origin for phone installation; connected accounts need the combined source backend under the same origin. This is not an APK. Private university access remains unverified.\n')
 guide=destination/'UniEve-Campus-v1.2-setup.md';guide.write_bytes((ROOT/'README.md').read_bytes())
 # Archive-level guard: no private files, cache copies, symlink dependency trees,
 # machine secrets or the supplied student's identifier/password-shaped literal.
 for package in (source,mobile):
  with zipfile.ZipFile(package) as archive:
   for name in archive.namelist():
    if any(part in EXCLUDED-{'dist'} for part in Path(name).parts):raise RuntimeError('Excluded member in export')
    data=archive.read(name)
    if re.search(rb'vtu' + rb'263[0-9]{2}|' + rb'Lo' + rb'@[0-9]{8}',data,re.I):raise RuntimeError('Private account pattern in export')
 manifest={'version':'1.2.0','project':'UniEve-Campus','files':[]}
 for path in (source,mobile,guide):
  manifest['files'].append({'name':path.name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 target=destination/'UniEve-Campus-v1.2-manifest.json';target.write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps(manifest,indent=2))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT.parent/'artifacts');export(parser.parse_args().output)
