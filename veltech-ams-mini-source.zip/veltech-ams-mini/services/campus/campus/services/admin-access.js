import {hasAdminPermission} from '../../../../shared/admin-access.mjs';
import {campusRole} from '../policy.js';
import {fail} from '../security.js';
export function adminAccessGuard(req,_res,next){
 if(!req.user || campusRole(req.user)!=='admin')return next();
 const path=req.path,read=['GET','HEAD','OPTIONS'].includes(req.method);let permission;
 if(path.startsWith('/academic-admin/'))permission=['/academic-admin/audit-logs','/academic-admin/sms-logs'].includes(path)?'audit':read?'academics.read':'academics.write';
 else if(path==='/academic-rules' && !read || path.startsWith('/academic-rules/'))permission='academics.rules';
 else if(path.startsWith('/community/reports/admin'))permission='moderation';
 else if(path==='/app-feedback/manage' || path.startsWith('/app-feedback/') && !read)permission='support';
 else if(path.startsWith('/faculty-exams'))permission='examinations';
 else if(path.startsWith('/academic-calendar/manage') || path.startsWith('/academic-calendar') && !read || path.startsWith('/timetable-rooms') && !read)permission='calendar';
 else if(path.startsWith('/notices') && !read)permission='notices';
 else if(path==='/events' && !read || path.startsWith('/check-in'))permission='events';
 else if(path.startsWith('/placements') && !read && !/\/(?:save|application)$/.test(path))permission='placements';
 else if(path==='/forms' && !read || /^\/forms\/[a-f0-9]{24}(?:\/responses(?:\/export)?|\/export)?$/.test(path) && (!read || path.includes('/responses') || path.endsWith('/export')))permission='forms';
 if(permission && !hasAdminPermission(req.user,permission))fail(403,'This administrator account is not assigned that permission.');
 next();
}
