import {Placement,Audit} from '../models.js';
import {canManagePlacements} from '../policy.js';
import {fail,validateId,httpUrl} from '../security.js';
export function registerPlacements(router,config) {
  router.get('/placements',config.auth,async(req,res)=>{
    const placements=await Placement.find().sort({createdAt:-1}).limit(200).lean();
    res.json(placements.map(p=>({id:String(p._id),company:p.company,title:p.title,type:p.type,location:p.location,stipend:p.stipend,eligibility:p.eligibility,description:p.description,deadline:p.deadline,url:p.url,saved:p.savedBy.map(String).includes(req.user.id),application:p.applications.find(a=>String(a.user)===req.user.id)?.status || null})));
  });
  router.post('/placements',config.auth,async(req,res)=>{
    if(!canManagePlacements(req.user)) fail(403,'Placement staff access is required');
    const {company,title,type,location='',stipend='',eligibility='',description='',deadline,url=''}=req.body;
    if(typeof company!=='string' || !company.trim() || company.length>120 || typeof title!=='string' || !title.trim() || title.length>150 || !['campus','off-campus'].includes(type)) fail(400,'Enter a company, role and placement type');
    if(deadline && !Number.isFinite(new Date(deadline).getTime())) fail(400,'Choose a valid deadline');
    for(const field of [location,stipend,eligibility,description]) if(typeof field!=='string' || field.length>5000) fail(400,'Invalid placement details');
    const placement=await Placement.create({company:company.trim(),title:title.trim(),type,location,stipend,eligibility,description,deadline:deadline || null,url:httpUrl(url),createdBy:req.user._id});
    await Audit.create({actor:req.user._id,action:'placement.create',target:placement.id});res.status(201).json({id:placement.id});
  });
  router.put('/placements/:id/save',config.auth,async(req,res)=>{
    validateId(req.params.id);if(typeof req.body.saved!=='boolean') fail(400,'Save state must be true or false');
    const found=await Placement.findOneAndUpdate({_id:req.params.id},req.body.saved?{$addToSet:{savedBy:req.user._id}}:{$pull:{savedBy:req.user._id}});
    if(!found) fail(404,'Opportunity not found');res.json({saved:req.body.saved});
  });
  router.put('/placements/:id/application',config.auth,async(req,res)=>{
    validateId(req.params.id);const status=req.body.status;
    if(!['interested','applied'].includes(status)) fail(400,'Choose interested or applied');
    const p=await Placement.findById(req.params.id);if(!p) fail(404,'Opportunity not found');
    await Placement.updateOne({_id:p._id,'applications.user':{$ne:req.user._id}},{$push:{applications:{user:req.user._id,status,updatedAt:new Date()}}});
    await Placement.updateOne({_id:p._id,'applications.user':req.user._id},{$set:{'applications.$.status':status,'applications.$.updatedAt':new Date()}});
    res.json({status,message:'Application tracking updated. Submit your application with the employer separately.'});
  });
}
