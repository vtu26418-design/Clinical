import User from '../../models/User.js';
import Event from '../../models/Event.js';
import Registration from '../../models/EventRegistration.js';
import {Audit,AcademicLink} from '../models.js';
import {AdminAccount,AdminLoginEvent} from '../models/admin-records.js';
import {publicUser,campusRole} from '../policy.js';
import {hasAdminAction,isAdminOwner} from '../../../../shared/admin-access.mjs';
import {requireAdminAction} from '../services/admin-access.js';
import {syncAdminAccount} from '../services/admin-records.js';
import {decryptToken,fail,validateId} from '../security.js';
const admin=(req,_res,next)=>{if(campusRole(req.user)!=='admin')fail(403,'Administrator access required.');next();};
export function registerAdminDirectory(router,config){
 router.get('/admin/overview',config.auth,admin,async(req,res)=>{
  await syncAdminAccount(req.user);const can=key=>hasAdminAction(req.user,key,'view');
  const counts={};
  if(can('accounts')){counts.members=await User.countDocuments();counts.students=await User.countDocuments({role:'student'});counts.faculty=await User.countDocuments({role:'faculty'});}
  if(can('administrators'))counts.administrators=await User.countDocuments({role:'admin'});
  if(can('events')){counts.activeEvents=await Event.countDocuments({archivedAt:null});counts.registrations=await Registration.countDocuments({status:{$in:['registered','attended']}});counts.attended=await Registration.countDocuments({status:'attended'});}
  const audit=can('audit')?await Audit.find().sort({createdAt:-1}).limit(12).lean():[];
  res.json({counts,audit,mailConfigured:!!config.mail?.configured,owner:isAdminOwner(req.user),account:publicUser(req.user)});
 });
 router.get('/admin/directory',config.auth,admin,async(req,res)=>{
  const canAccounts=hasAdminAction(req.user,'accounts','view'),canAdmins=hasAdminAction(req.user,'administrators','view');
  if(!canAccounts && !canAdmins)fail(403,'Directory viewing permission is required.');
  const role=req.query.role || 'all',q=String(req.query.q || '').trim();if(!['all','student','faculty','admin'].includes(role) || q.length>120)fail(400,'Choose a valid directory filter.');
  if(role==='admin' && !canAdmins || ['student','faculty'].includes(role) && !canAccounts)fail(403,'This account type is outside your directory access.');
  const visible=canAccounts && canAdmins?{}:{role:canAdmins?'admin':{$ne:'admin'}};
  const query={$and:[visible,...(role==='all'?[]:[{role}]),...(!isAdminOwner(req.user)?[{$or:[{role:{$ne:'admin'}},{_id:req.user._id},{adminCreatedBy:req.user._id}]}]:[])]};
  if(q){const escaped=q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');query.$and.push({$or:['name','username','email','studentId','department','portalPrincipal'].map(key=>({[key]:{$regex:escaped,$options:'i'}}))});}
  const page=Math.max(1,Math.min(10000,Number(req.query.page) || 1)),limit=50;
  const [users,total]=await Promise.all([User.find(query).sort({name:1,_id:1}).skip((page-1)*limit).limit(limit),User.countDocuments(query)]);
  res.json({users:users.map(publicUser),total,page,pages:Math.ceil(total/limit)});
 });
 router.get('/admin/directory/:id/academic',config.auth,admin,async(req,res)=>{
  requireAdminAction(req.user,'accounts','view');requireAdminAction(req.user,'academics.read','view');
  const user=await User.findById(validateId(req.params.id));if(!user || user.role!=='student')fail(404,'Student account not found.');
  const link=await AcademicLink.findOne({user:user._id}).select('+sealedToken');if(!link)fail(409,'This student has no connected academic records.');
  let token;try{token=decryptToken(link.sealedToken,config.linkKey);}catch{fail(409,'The student academic link must be renewed.');}
  const data=await config.academic.request(token,'/campus/workspace');
  await Audit.create({actor:req.user._id,action:'student.academic-view',target:user.id});res.json(data);
 });
 router.get('/admin/access-history',config.auth,admin,async(req,res)=>{
  requireAdminAction(req.user,'audit','view');
  const rows=await AdminLoginEvent.find().sort({at:-1}).limit(100).populate('user','name username email').lean();
  res.json({entries:rows.map(row=>({id:String(row._id),action:row.action,at:row.at,account:row.user?{id:String(row.user._id),name:row.user.name,username:row.user.username,email:row.user.email}:null}))});
 });
}
