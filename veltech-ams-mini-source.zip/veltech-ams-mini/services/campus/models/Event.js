import mongoose from "mongoose";

const eventSchema = new mongoose.Schema(
  {

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User", 
      required: true,
    },

    title: {
      type: String,
      required: true,
      trim: true,
    },

    description: {
      type: String,
      default: "",
    },

    image: {
      type: String,
      required: true,
    },

    date: {
      type: Date,
      required: true,
    },

    time: {
      type: String, 
      required: true,
    },

    location: {
      type: String,
      required: true,
    },

    attendees: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User", 
      },
    ],

    category: {
      type: String,
      default: "General",
    },

    status: {
      type: String,
      enum: ["upcoming", "completed", "cancelled"],
      default: "upcoming",
    },
    scope: { type: String, enum: ['legacy','club','department','college'], default: 'legacy' },
    department: { type: String, default: '' },
    club: { type: String, default: '' },
    capacity: { type: Number, default: 500, min: 1 },
    registrationCount: { type: Number, default: 0, min: 0 },
    pricePaise: { type: Number, default: 0, min: 0 },
    currency: { type: String, default: 'INR', enum: ['INR'] },
    organizerName: { type: String, default: '' },
    deadline: { type: Date, default: null },
    startsAt: { type: Date, default: null },
    archivedAt: { type: Date, default: null },
    ticketHistory: { type: Boolean, default: false },
    video: { type: String, default: '' },
    rules: {type:[String],default:[]},registrationInstructions:{type:String,default:''},eligibility:{type:String,default:''},contactEmail:{type:String,default:''},
  },
  {
    timestamps: true,
    minimize: false,
  }
);

eventSchema.index({ date: 1 });

const eventModel =
  mongoose.models.Event || mongoose.model("Event", eventSchema);

export default eventModel;
