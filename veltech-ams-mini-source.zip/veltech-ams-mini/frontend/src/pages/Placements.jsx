import {BriefcaseBusiness} from 'lucide-react';
import {PageHeader,Badge} from '../components/UI';
import './academic.css';
export default function Placements(){
 return <><PageHeader title="Placements" description="Campus career opportunities."/><section className="panel placement-developing"><div><span className="document-icon"><BriefcaseBusiness size={30}/></span><div><Badge status="in-progress">Developing</Badge></div><h2>Placements are on the way</h2><p className="muted">This section is being developed. Published placement opportunities will appear here when the placement office makes them available.</p></div></section></>;
}
