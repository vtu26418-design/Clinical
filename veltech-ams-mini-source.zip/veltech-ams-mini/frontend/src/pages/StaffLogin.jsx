import {Link} from 'react-router-dom';
import SignInAreas from '../components/SignInAreas';
import AuthScreen from './AuthScreen';
export default function StaffLogin({area,onSuccess}){
 return <main className="portal-login-layout staff-login"><section className="portal-login-intro staff-login-copy"><Link className="brand" to="/login/student"><img src="/assets/original-logo.png" alt="veltech-ams-mini"/><span>veltech<span>ams-mini</span></span></Link><div><span className="eyebrow">VEL TECH · {area==='admin'?'ADMINISTRATION':'FACULTY'}</span><h1>{area==='admin'?'Manage your connected campus.':'Your teaching day, connected.'}</h1><p>{area==='admin'?'Manage campus accounts, events, academic rules and college updates.':'Manage your assigned forms, examinations and campus activities.'}</p></div><small>Developed by VEL STUDENTS</small></section><section className="portal-login-form"><div><SignInAreas/><AuthScreen key={area} compact loginArea={area} onSuccess={onSuccess}/></div></section></main>;
}
