import {useEffect,useState} from 'react';
import {useAppPreferences} from '../context/AppPreferences';
const key='veltech:launch:v22-logo-refresh';
function alreadyOpened(){try{return sessionStorage.getItem(key)==='seen';}catch{return false;}}
export default function AppLaunch({children}){
 const {preferences}=useAppPreferences(),[pending,setPending]=useState(()=>!alreadyOpened());
 const reduced=preferences.motion==='reduced' || globalThis.matchMedia?.('(prefers-reduced-motion:reduce)').matches;
 const visible=pending && preferences.openingAnimation;
 useEffect(()=>{
  if(!pending)return;
  if(!preferences.openingAnimation){setPending(false);return;}
  try{sessionStorage.setItem(key,'seen');}catch{}
  const timer=setTimeout(()=>setPending(false),reduced?180:2600);
  return()=>clearTimeout(timer);
 },[pending,preferences.openingAnimation,reduced]);
 return <><div className="app-launch-content" inert={visible} aria-hidden={visible || undefined}>{children}</div>{visible?<div className="app-launch" role="status" aria-label="Opening Veltech mini" data-motion={reduced?'reduced':'full'}><div className="app-launch-mark" aria-hidden="true">{reduced?<img className="app-launch-static" src="/assets/original-logo.png" alt=""/>:['left','right','cap','centre'].map(part=><img key={part} className={`app-launch-part part-${part}`} src={`/assets/logo/${part}.png`} alt="" decoding="sync"/>)}</div><strong>veltech mini</strong></div>:null}</>;
}
