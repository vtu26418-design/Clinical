import {ADMIN_PERMISSIONS,hasAdminPermission} from '../../../shared/admin-access.mjs';
export default function AdminPermissionPicker({actor,value=[],onChange}){
 const available=Object.keys(ADMIN_PERMISSIONS).filter(key=>hasAdminPermission(actor,key));
 return <fieldset className="admin-permission-picker"><legend>Administrator permissions</legend><p>Choose the areas this administrator can manage. Academic viewing and editing are separate.</p><div>{Object.entries(ADMIN_PERMISSIONS).filter(([key])=>available.includes(key)).map(([key,label])=><label key={key}><input type="checkbox" checked={value.includes(key)} onChange={e=>onChange(e.target.checked?[...value,key]:value.filter(item=>item!==key))}/><span>{label}</span></label>)}</div></fieldset>;
}
