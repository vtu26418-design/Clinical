import {NavLink} from 'react-router-dom';
export default function SignInAreas(){return <nav className="sign-in-areas" aria-label="Sign-in area">{[['student','Student'],['faculty','Faculty'],['admin','Admin']].map(([key,label])=><NavLink key={key} to={'/login/'+key}>{label}</NavLink>)}</nav>;}
