import {useEffect,useId,useRef,useState} from 'react';
import {ArrowRight,BookOpen,CalendarDays,GraduationCap,Orbit,RefreshCw,Sparkles} from 'lucide-react';
import {useCampus} from '../context/CampusContext';
import {useAppPreferences} from '../context/AppPreferences';
import {Avatar} from './UI';

const symbols=[GraduationCap,BookOpen,CalendarDays,Orbit,Sparkles,BookOpen];

function WelcomeScreen({stage,profile,syncStatus,loading,onComplete,preferences}){
 const title=useId(),screen=useRef(null);
 const [reduced,setReduced]=useState(()=>preferences.motion==='reduced' || matchMedia('(prefers-reduced-motion:reduce)').matches);
 const animated=preferences.openingAnimation && !reduced;
 const [logoReady,setLogoReady]=useState(!animated),[canContinue,setCanContinue]=useState(false);
 const identified=stage==='syncing' && !!profile?.id && logoReady;
 const name=profile?.officialProfile?.name || profile?.name || '';
 const photo=profile?.officialProfile?.photo || profile?.photo || profile?.image;
 const detail=[profile?.officialProfile?.studentId || profile?.studentId,profile?.officialProfile?.department || profile?.department].filter(Boolean).join(' · ');
 const sourceWorking=syncStatus?.state==='syncing';
 const label=stage==='signing-in'?'Signing you in':stage==='restoring'?'Opening your workspace':loading || sourceWorking?(['faculty','admin'].includes(profile?.accountRole)?'Preparing your workspace':'Syncing your college details'):'Your workspace is ready';

 useEffect(()=>{
  const media=matchMedia('(prefers-reduced-motion:reduce)'),change=()=>setReduced(preferences.motion==='reduced' || media.matches);
  change();media.addEventListener('change',change);return()=>media.removeEventListener('change',change);
 },[preferences.motion]);
 useEffect(()=>{const timer=setTimeout(()=>setLogoReady(true),animated?650:0);return()=>clearTimeout(timer);},[animated]);
 useEffect(()=>{
  if(stage!=='syncing')return;
  const reveal=setTimeout(()=>setCanContinue(true),3500),limit=setTimeout(onComplete,8000);
  return()=>{clearTimeout(reveal);clearTimeout(limit);};
 },[stage,onComplete]);
 useEffect(()=>{
  // Release the welcome screen after the first usable records. The existing
  // background worker continues any remaining AMS sections without new requests.
  if(!identified || loading || (sourceWorking && !profile?.officialProfile?.name && !['faculty','admin'].includes(profile?.accountRole)))return;
  const timer=setTimeout(onComplete,animated?650:0);return()=>clearTimeout(timer);
 },[identified,loading,sourceWorking,name,photo,profile?.officialProfile?.name,profile?.accountRole,onComplete,animated]);
 useEffect(()=>{
  const previous=document.activeElement,overflow=document.body.style.overflow;
  document.body.style.overflow='hidden';screen.current?.focus({preventScroll:true});
  const trap=event=>{
   if(event.key!=='Tab')return;
   event.preventDefault();const button=screen.current?.querySelector('button');(button || screen.current)?.focus();
  };
  const node=screen.current;node?.addEventListener('keydown',trap);
  return()=>{document.body.style.overflow=overflow;node?.removeEventListener('keydown',trap);if(previous?.isConnected)previous.focus({preventScroll:true});else document.getElementById('main')?.focus({preventScroll:true});};
 },[]);

 return <section ref={screen} className={`login-welcome ${identified?'has-identity':'has-logo'}`} data-stage={stage} data-animated={animated?'true':'false'} data-background={preferences.backgroundAnimation?'on':'off'} role="dialog" aria-modal="true" aria-labelledby={title} tabIndex={-1}>
  <div className="welcome-atmosphere" aria-hidden="true"><i/><i/><i/><div className="welcome-grid"/>{symbols.map((Icon,index)=><span key={index} className={`welcome-symbol symbol-${index}`}><Icon size={index%2?30:42} strokeWidth={1}/></span>)}</div>
  <div className="welcome-topline" aria-hidden="true"><span/>VEL TECH · YOUR CAMPUS, CONNECTED</div>
  <div className="welcome-content">
   <div className="welcome-mark" aria-hidden="true"><div className="welcome-halo"/><div className="welcome-orbit"/><div className="welcome-orbit outer"/><div className="welcome-logo"><img src="/assets/original-logo.png" alt=""/></div>{identified?<div className="welcome-portrait"><Avatar name={name} src={photo}/></div>:null}<span className="welcome-spark spark-one"/><span className="welcome-spark spark-two"/></div>
   <div className="welcome-identity" key={identified?'person':'brand'}><p className="welcome-eyebrow">{identified?'WELCOME BACK':'ONE CAMPUS. TOGETHER.'}</p><h1 id={title}>{identified?(name || 'Your college workspace'):'veltech'}{!identified?<span>ams mini</span>:null}</h1><p className="welcome-detail">{identified?(detail || 'Your college day, all together.'):'Your college day, all together.'}</p></div>
   <div className="welcome-sync" role="status" aria-live="polite"><div className="welcome-sync-label"><RefreshCw size={15}/><span>{label}</span><span className="welcome-dots" aria-hidden="true"><i/><i/><i/></span></div><div className="welcome-progress" aria-hidden="true"><span/></div></div>
   <div className="welcome-actions">{canContinue && stage==='syncing'?<button type="button" onClick={onComplete}>Continue to workspace<ArrowRight size={16}/></button>:null}</div>
  </div>
  <footer className="welcome-credit">Developed by VEL STUDENTS</footer>
 </section>;
}

export default function LoginWelcome(){
 const {welcomeStage,finishWelcome,sessionState,mode,data,loading}=useCampus();
 const {preferences}=useAppPreferences();
 const stage=welcomeStage || (sessionState==='checking'?'restoring':'');
 if(!stage)return null;
 // Demo or previously signed-out identities never enter the login animation.
 const profile=mode==='connected' && sessionState==='ready'?data.profile:null;
 return <WelcomeScreen stage={stage} profile={profile} syncStatus={data.syncStatus || data.academic?.syncStatus} loading={loading} onComplete={finishWelcome} preferences={preferences}/>;
}
