import test from 'node:test';
import assert from 'node:assert/strict';
import {academicDownloadName} from '../src/lib/download.js';
test('academic files get the extension for their verified MIME type without trusting a misleading title',()=>{
 assert.equal(academicDownloadName('Tuition receipt.pdf','image/png'),'Tuition receipt.png');
 assert.equal(academicDownloadName('Transcript','application/pdf'),'Transcript.pdf');
 assert.equal(academicDownloadName('../My/record.pdf','application/pdf'),'.._My_record.pdf');
});
test('unrecognized file types are not given a fabricated academic extension',()=>{
 assert.equal(academicDownloadName('Document','application/octet-stream'),'Document');
});
