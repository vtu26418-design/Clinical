# Student, faculty and administrator sign-in

Choose the appropriate tab on the sign-in page:

| Account | Address | Credentials |
| --- | --- | --- |
| Student | `/#/login/student` | Your own AMS username and password; complete verification if AMS requires it |
| Faculty | `/#/login/faculty` | Provisioned faculty email/username and application password |
| Admin | `/#/login/admin` | Provisioned administrator email/username and application password |

`/#/login` opens Student. The staff endpoints validate the password and persisted account role before creating an HttpOnly session. A student cannot become faculty or admin by changing the URL or submitted role. Staff sign-in opens Forms or Management and does not require a student AMS account.

The Windows Setup script provisions the first administrator when the selected database has none. Use **Management → Roles & accounts** to provision faculty accounts and assign appropriate department/club permissions. There are no shared default production passwords and no public faculty/admin registration.

Recovery requires your configured SMTP/Brevo provider and a verified recovery address. It changes the application password; university AMS passwords are managed by the university. Valid campus sessions restore after refresh or an app-shell update. Genuine AMS expiry is separate from campus sign-in, and upstream verification cannot be bypassed.
