export const ADMIN_PERMISSIONS={events:'Events and check-in',accounts:'Student and faculty accounts',administrators:'Create and manage limited admins',placements:'Placements',notices:'College notices',moderation:'Community reports',forms:'Faculty forms and evidence',support:'App issues and feedback',calendar:'Calendar and room overrides',examinations:'Faculty examinations','academics.read':'View academic workspaces','academics.write':'Edit app academic records','academics.rules':'Batch percentage rules',audit:'Audit history'};
const admin=user=>!!user && user.isActive!==false && [user.role,user.accountRole,user.campusRole].includes('admin');
export const isAdminOwner=user=>admin(user) && (user.isAdminOwner===true || user.adminPermissions==null);
export const adminPermissionsFor=user=>!admin(user)?[]:isAdminOwner(user)?Object.keys(ADMIN_PERMISSIONS):Array.isArray(user.adminPermissions)?Object.keys(ADMIN_PERMISSIONS).filter(key=>user.adminPermissions.includes(key)):[];
export const hasAdminPermission=(user,permission)=>{const keys=adminPermissionsFor(user);return keys.includes(permission) || permission==='academics.read' && keys.includes('academics.write');};
export const canAccessAcademics=user=>hasAdminPermission(user,'academics.read') || hasAdminPermission(user,'academics.write') || hasAdminPermission(user,'academics.rules');
export function workspaceStartPage(user){
 if(!admin(user))return (user?.accountRole || user?.role)==='faculty'?'forms':'home';
 if(['events','accounts','administrators','placements','notices','moderation','support','audit'].some(key=>hasAdminPermission(user,key)))return 'management';
 if(canAccessAcademics(user))return 'academic-admin';
 if(hasAdminPermission(user,'calendar'))return 'academic-calendar';
 if(hasAdminPermission(user,'examinations'))return 'faculty-exams';
 return hasAdminPermission(user,'forms')?'forms':'management';
}
