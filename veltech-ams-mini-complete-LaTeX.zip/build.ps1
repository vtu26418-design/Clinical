$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command pdflatex -ErrorAction SilentlyContinue)) {
    throw 'Install MiKTeX or TeX Live with pdfLaTeX, or upload this ZIP to Overleaf.'
}
for ($reportPass = 1; $reportPass -le 3; $reportPass++) {
    & pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error main.tex
    if ($LASTEXITCODE -ne 0) { throw "LaTeX pass $reportPass failed. See main.log." }
}
Write-Host 'Report ready: main.pdf. Edit your details near the top of main.tex.'
