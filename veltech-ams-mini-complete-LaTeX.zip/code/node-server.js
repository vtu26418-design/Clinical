if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  dotenv.config({path:process.env.CAMPUS_ENV_FILE || path.resolve(path.dirname(fileURLToPath(import.meta.url)),'.env')});
  const mongoUri=process.env.MONGODB_URI;if(!mongoUri) throw new Error('Set MONGODB_URI in campus/.env');
  await mongoose.connect(mongoUri);
  // Enforce uniqueness before accepting registrations or account links.
  await Promise.all([User.init(),Event.init(),Registration.init(),Session.init(),AcademicLink.init(),IdentityChallenge.init(),IdentityProof.init(),CampusMedia.init(),Follow.init(),AcademicCalendarEntry.init(),TimetableRoomOverride.init(),AppFeedback.init(),initializeNotificationModels()]);
  // Other initialization and scheduled jobs omitted from this excerpt.
  const app=createCampusApp({mail});app.listen(Number(process.env.CAMPUS_PORT || 4100),process.env.CAMPUS_HOST || '127.0.0.1',()=>console.log('veltech-ams-mini API started'));
}
