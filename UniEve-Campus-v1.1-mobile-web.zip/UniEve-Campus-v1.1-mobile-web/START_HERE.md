# UniEve Campus V1.1

Preview the fictional demo: `cd web` then `python3 -m http.server 5180 --bind 127.0.0.1`. Open http://127.0.0.1:5180 on that machine.

For live data, use the source ZIP and follow SETUP_GUIDE.md. The static preview cannot connect campus accounts or serve source downloads.

Install on Android Chrome or iPhone Safari after hosting this PWA at an HTTPS origin with the campus API on the same origin. This is a web app, not an APK. AMS requires your manual CAPTCHA answer. Device snapshots are optional and passphrase-encrypted.
