import {useEffect,useId,useMemo,useRef,useState} from 'react';
import {ChevronDown,Download,TrendingUp,GraduationCap,FileText} from 'lucide-react';
import {prepareResults,resultSemesters,resultMetrics,resultReportGroups,resultTrend} from '../lib/academic-results';
import {academicNumber} from '../lib/gpa';
import {downloadFile,csv} from '../lib/download';
import {Field,Button,EmptyState} from './UI';
import GpaCalculator from './GpaCalculator';
import '../academic-results.css';

const marks={testMark1:'Test 1',testMark2:'Test 2',testMark3:'Test 3',midTestMark1:'Mid-test 1',midTestMark2:'Mid-test 2',labMark:'Lab',assignmentMark:'Assignment',internalMark:'Final internal'};
const reportName=row=>row.resultType || row.sourceReport || 'Results';
const format=value=>value===null?'—':value.toFixed(2);

function PerformanceGraph({points,title}){
 const plot=useRef(null),gradient=useId().replaceAll(':',''),instructions=useId();
 const [width,setWidth]=useState(600),[active,setActive]=useState(()=>Math.max(0,points.findLastIndex(point=>point.value!==null)));
 const available=points.filter(point=>point.value!==null),hasValues=available.length>0;
 useEffect(()=>{
  if(!plot.current)return;
  const observer=new ResizeObserver(([entry])=>setWidth(Math.max(160,Math.round(entry.contentRect.width))));
  observer.observe(plot.current);return()=>observer.disconnect();
 },[hasValues]);
 const left=36,right=width-14,top=16,bottom=184,maximum=Math.ceil(Math.max(1,...available.map(point=>point.value))/2)*2;
 const x=index=>points.length<2?(left+right)/2:left+index*(right-left)/(points.length-1),y=value=>bottom-value/maximum*(bottom-top);
 const current=points[active] || points[0],segments=[];
 for(let index=0;index<points.length;index++){
  if(points[index].value===null)continue;
  if(index===0 || points[index-1].value===null)segments.push([]);
  segments.at(-1).push({x:x(index),y:y(points[index].value)});
 }
 function selectPointer(event){
  const rect=event.currentTarget.getBoundingClientRect(),position=(event.clientX-rect.left)/rect.width*width;
  setActive(points.length<2?0:Math.max(0,Math.min(points.length-1,Math.round((position-left)/(right-left)*(points.length-1)))));
 }
 function selectKey(event){
  const actions={ArrowLeft:Math.max(0,active-1),ArrowRight:Math.min(points.length-1,active+1),Home:0,End:points.length-1};
  if(Object.hasOwn(actions,event.key)){event.preventDefault();setActive(actions[event.key]);}
 }
 const valueText=current?`${current.label}: ${current.value===null?'numeric value unavailable':`${format(current.value)} grade points`}`:'';
 return <figure className="performance-graph">
  <figcaption><span><TrendingUp size={18}/>{title}</span><small>Source grade points</small></figcaption>
  {hasValues?<>
   <div className="performance-readout"><div><strong>{format(current?.value??null)}</strong><span>{current?.label}</span></div><small>{current?.detail || 'Explicit source grade points'}{current?.value===null?' · Numeric value unavailable':''}</small></div>
   <div ref={plot} className="performance-plot" tabIndex={0} role="slider" aria-label={`${title}; selected data point`} aria-orientation="horizontal" aria-valuemin={1} aria-valuemax={points.length} aria-valuenow={active+1} aria-valuetext={valueText} aria-describedby={instructions} onKeyDown={selectKey} onPointerMove={selectPointer} onPointerDown={selectPointer}>
    <svg viewBox={`0 0 ${width} 222`} role="img" aria-label={title}>
     <title>{title}</title><desc>Only explicit source grade points are plotted. Incomplete semester calculations leave gaps.</desc>
     <defs><linearGradient id={gradient} x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#0a66c2" stopOpacity=".2"/><stop offset="100%" stopColor="#0a66c2" stopOpacity=".015"/></linearGradient></defs>
     {[0,.25,.5,.75,1].map(value=><g key={value}><line x1={left} x2={right} y1={y(value*maximum)} y2={y(value*maximum)} stroke="#e2eaf3" strokeDasharray="3 5"/><text x={left-9} y={y(value*maximum)+4} textAnchor="end" fontSize="10" fill="#72849b">{Number((value*maximum).toFixed(1))}</text></g>)}
     {segments.map((segment,index)=>{const line=segment.map((point,i)=>`${i?'L':'M'}${point.x},${point.y}`).join(' ');return <g key={index}>{segment.length>1?<path d={`${line} L${segment.at(-1).x},${bottom} L${segment[0].x},${bottom} Z`} fill={`url(#${gradient})`}/>:null}<path d={line} fill="none" stroke="#0a66c2" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round"/></g>;})}
     {points.map((point,index)=>point.value!==null?<circle key={index} cx={x(index)} cy={y(point.value)} r={index===active?5:3} fill={index===active?'#0a66c2':'white'} stroke="#0a66c2" strokeWidth="2"/>:null)}
     {current?<line x1={x(active)} x2={x(active)} y1={top} y2={bottom} stroke="#0a66c2" strokeOpacity=".35" strokeDasharray="3 4"/>:null}
     {points.map((point,index)=>index%Math.max(1,Math.ceil(points.length/(width<340?3:6)))===0 || index===points.length-1?<text key={index} x={x(index)} y="208" textAnchor={index===0?'start':index===points.length-1?'end':'middle'} fontSize="10" fill="#62758c">{point.shortLabel || point.label.slice(0,12)}</text>:null)}
    </svg>
   </div>
   <div className="performance-legend"><span><i/>Numeric source values</span><small id={instructions}>Hover, tap or use arrow keys</small></div>
   {points.some(point=>point.value===null)?<p className="performance-note">Gaps indicate missing credits or grade points, or repeated course attempts. No value is estimated.</p>:null}
  </>:<div className="performance-unavailable"><span><TrendingUp size={26}/></span><strong>A numeric trend is not available</strong><p>AMS has not supplied complete credits and numeric grade points for this selection. Letter grades are shown in the reports below.</p></div>}
 </figure>;
}

function ResultReport({group,view,index}){
 return <details className="academic-report" open={index===0}>
  <summary><span className="academic-report-icon"><FileText size={17}/></span><span className="academic-report-title"><strong>{group.report}</strong><small>{group.semester?`Semester ${group.semester}`:'Semester not provided'}{group.session?` · ${group.session}`:''}</small></span><span className="academic-report-count">{group.rows.length} {group.rows.length===1?'record':'records'}</span><ChevronDown size={17} className="academic-report-chevron"/></summary>
  <div className="table-scroll"><table className="academic-detail-table"><caption className="sr-only">{group.report}, {group.semester?`Semester ${group.semester}`:'semester not provided'}{group.session?`, ${group.session}`:''}</caption><thead><tr><th>Course</th>{view==='grades'?<><th>Result</th><th>Grade</th><th>Credits</th><th>Grade points</th></>:<th>Source marks</th>}</tr></thead><tbody>{group.rows.map((row,index)=><tr key={`${row.courseCode}:${index}`}><td><strong>{row.courseName || row.courseCode || 'Course not provided'}</strong><small>{row.courseCode}</small></td>{view==='grades'?<><td>{row.status || '—'}</td><td><b className="result-grade">{row.grade}</b></td><td>{row.credits??'—'}</td><td>{row.gradePoints??'—'}</td></>:<td><div className="result-marks">{Object.entries(marks).filter(([key])=>row[key]!==undefined).map(([key,label])=><small key={key}><span>{label}</span><strong>{row[key]}</strong></small>)}</div></td>}</tr>)}</tbody></table></div>
 </details>;
}

export default function ResultsDashboard({results=[],credits=[],gradeScale=[],creditSummary=[],mode='connected',accountKey=''}){
 const [semester,setSemester]=useState('all'),[view,setView]=useState('grades'),[exam,setExam]=useState('all'),[kind,setKind]=useState('all');
 const prepared=useMemo(()=>prepareResults(results,credits,gradeScale),[results,credits,gradeScale]);
 const pool=view==='grades'?prepared.grades:prepared.assessments;
 const reports=[...new Set(pool.map(reportName))],reportRows=kind==='all'?pool:pool.filter(row=>reportName(row)===kind);
 const semesters=resultSemesters(reportRows),semesterRows=semester==='all'?reportRows:reportRows.filter(row=>String(row.semester)===semester);
 const exams=[...new Set(semesterRows.map(row=>row.examinationSession).filter(Boolean))];
 const selected=exam==='all'?semesterRows:semesterRows.filter(row=>row.examinationSession===exam),groups=resultReportGroups(selected);
 const overall=resultMetrics(prepared.grades),current=resultMetrics(selected);
 const officialCgpa=creditSummary.find(row=>/^(cgpa|cumulative grade point average)$/i.test(String(row.label || '').trim()));
 const sourceCgpa=academicNumber(officialCgpa?.value),calculated=overall.complete?overall.value:null;
 const graph=resultTrend(selected,semester),distribution=[...selected.reduce((counts,row)=>{if(row.grade)counts.set(String(row.grade),(counts.get(String(row.grade)) || 0)+1);return counts;},new Map())];
 function changeView(value){setView(value);setSemester('all');setExam('all');setKind('all');}
 const exportRows=()=>downloadFile(`ams-results-${view}-${semester}.csv`,csv([['Course code','Course name','Semester','Report','Exam session','Grade','Credits','Grade points','Result','Source report','Source',...Object.values(marks)],...selected.map(row=>[row.courseCode,row.courseName,row.semester,reportName(row),row.examinationSession,row.grade,row.credits,row.gradePoints,row.status,row.sourceReport,row.source,...Object.keys(marks).map(key=>row[key])])]),'text/csv');
 return <div className="results-dashboard">
  <div className="results-overall"><div><span><GraduationCap size={16}/>{sourceCgpa!==null?'CGPA · AMS':'Source course average'}</span><strong>{format(sourceCgpa??calculated)}</strong><small>{sourceCgpa!==null?'As published by AMS':calculated!==null?'Credit-weighted, listed completed courses':'Needs complete source credits and grade points'}</small></div><div><span>Final results</span><strong>{prepared.grades.length}</strong><small>{resultSemesters(prepared.grades).length} source semesters · {new Set(prepared.grades.map(reportName)).size} report types</small></div><div><span>{view==='grades'?'Selected course average':'Assessment & internal'}</span><strong>{view==='grades'?format(current.value):prepared.assessments.length}</strong><small>{view==='grades'?`${current.included} courses · ${current.credits} credits${current.excluded?' · partial coverage':''}`:'Source marks kept in separate reports'}</small></div></div>
  <div className="academic-view-switch" role="group" aria-label="Result record category"><button type="button" aria-pressed={view==='grades'} onClick={()=>changeView('grades')}>Final results<span>{prepared.grades.length}</span></button><button type="button" aria-pressed={view==='assessments'} onClick={()=>changeView('assessments')}>Assessment & internal<span>{prepared.assessments.length}</span></button></div>
  <div className="results-filters"><Field label="Source report"><select value={kind} onChange={event=>{setKind(event.target.value);setSemester('all');setExam('all');}}><option value="all">{view==='grades'?'All final result reports':'All assessment reports'}</option>{reports.map(report=><option key={report} value={report}>{report} ({pool.filter(row=>reportName(row)===report).length})</option>)}</select></Field><Field label="Semester"><select value={semester} onChange={event=>{setSemester(event.target.value);setExam('all');}}><option value="all">All source semesters</option>{semesters.map(label=><option key={label} value={label}>Semester {label}</option>)}</select></Field>{exams.length?<Field label="Examination session"><select value={exam} onChange={event=>setExam(event.target.value)}><option value="all">All examination sessions</option>{exams.map(session=><option key={session} value={session}>{session}</option>)}</select></Field>:null}</div>
  {view==='grades'?<><PerformanceGraph key={JSON.stringify([kind,semester,exam,graph.map(point=>point.label)])} points={graph} title={semester==='all'?'Semester performance':`Semester ${semester} · course performance`}/>{!graph.some(point=>point.value!==null) && distribution.length?<div className="result-distribution"><span>Source grade distribution</span><div>{distribution.map(([grade,count])=><span key={grade}><b>{grade}</b>{count} {count===1?'record':'records'}</span>)}</div></div>:null}</>:<p className="academic-report-explanation">Tests, assignments, lab marks and final internals retain their individual source reports and semester labels.</p>}
  <div className="academic-record-heading"><div><h3>{view==='grades'?'Final result reports':'Assessment reports'}</h3><p>{selected.length} records · {groups.length} {groups.length===1?'report division':'report divisions'}</p></div><Button variant="secondary" disabled={!selected.length} onClick={exportRows}><Download size={15}/>Export CSV</Button></div>
  {groups.length?<div className="academic-report-list">{groups.map((group,index)=><ResultReport key={group.key} group={group} view={view} index={index}/>)}</div>:<EmptyState title="No results in this selection" description="Choose another semester or source report."/>}
  <p className="page-footnote">Reports retain the semester, report type and examination session supplied by AMS. Calculations use source credits and published grade points; incomplete or repeated attempts are excluded. Your official transcript remains authoritative.</p>
  <GpaCalculator results={prepared.grades} mode={mode} accountKey={accountKey}/>
 </div>;
}
