"""Persist source rows in the authenticated student's document, retaining partial data."""
from datetime import datetime, timezone
from bson import ObjectId


def store_academic_rows(db, student_id, data):
    own={'_id':ObjectId(student_id)}
    existing=db.users.find_one(own) or {}
    now=datetime.now(timezone.utc).isoformat()
    updates={};accepted={'summary':0,'records':0,'results':0}
    specs=(('summary','amsAttendanceSummary',('subjectCode',)),
           ('records','amsClassRecords',('subjectCode','date','period')),
           ('results','results',('courseCode','semester','resultType','examinationSession')))
    for kind, field, keys in specs:
        incoming=data.get(kind) or []
        if not incoming:
            continue
        merged={tuple(row.get(k,'') for k in keys):row for row in existing.get(field,[]) if isinstance(row,dict)}
        grouped={}
        for row in incoming:
            key=tuple(row.get(k,'') for k in keys)
            grouped.setdefault(key,[]).append(row)
        for key, rows in grouped.items():
            unique={tuple(sorted(row.items())) for row in rows}
            if len(unique)>1:
                if kind!='records':
                    continue  # Contradictory totals/grades cannot replace confirmed source data.
                value={**rows[0],'status':'unknown'}
            else:
                value=rows[0]
            merged[key]={**value,'source':'ams','sourceUpdatedAt':now}
            accepted[kind]+=1
        updates[field]=list(merged.values())[-4000:]
    if updates:
        db.users.update_one(own,{'$set':updates})
    return accepted
