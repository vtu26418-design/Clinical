import {useCallback,useEffect,useRef,useState} from 'react';
import {request} from '../lib/api';
import {useCampus} from '../context/CampusContext';
export function useLiveResource(path,enabled=true){
 const {mode,data}=useCampus(),owner=`${mode}:${data.profile.id || ''}`,pending=useRef(null),current=useRef(owner);current.current=owner;
 const [value,setValue]=useState(null),[error,setError]=useState(''),[loading,setLoading]=useState(false);
 const reload=useCallback(()=>{
  if(!enabled || mode!=='connected')return Promise.resolve(null);
  if(pending.current?.owner===owner && pending.current.path===path)return pending.current.promise;
  pending.current?.abort.abort();const abort=new AbortController();setLoading(true);
  const promise=request(path,{signal:abort.signal}).then(result=>{if(current.current===owner && !abort.signal.aborted){setValue(result);setError('');}return result;}).catch(failure=>{if(current.current===owner && !abort.signal.aborted)setError(failure.message);return null;}).finally(()=>{if(pending.current?.promise===promise){pending.current=null;if(current.current===owner)setLoading(false);}});
  pending.current={owner,path,abort,promise};return promise;
 },[path,enabled,mode,owner]);
 useEffect(()=>{setValue(null);setError('');void reload();if(!enabled)return;
  const visible=()=>{if(document.visibilityState==='visible')void reload();},timer=setInterval(visible,20000);document.addEventListener('visibilitychange',visible);window.addEventListener('focus',visible);
  return()=>{clearInterval(timer);document.removeEventListener('visibilitychange',visible);window.removeEventListener('focus',visible);pending.current?.abort.abort();pending.current=null;};
 },[reload,enabled]);
 return {value,error,loading,reload};
}
