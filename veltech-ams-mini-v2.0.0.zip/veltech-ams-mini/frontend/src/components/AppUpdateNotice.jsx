import {useEffect,useState} from 'react';
import {RefreshCw} from 'lucide-react';
export default function AppUpdateNotice(){
 const [worker,setWorker]=useState(null);
 useEffect(()=>{const ready=e=>setWorker(e.detail);window.addEventListener('campus-update-available',ready);navigator.serviceWorker?.getRegistration().then(r=>{if(r?.waiting)setWorker(r.waiting);}).catch(()=>{});return()=>window.removeEventListener('campus-update-available',ready);},[]);
 if(!worker)return null;
 return <aside className="app-update-notice" role="status"><span>An updated version is ready.</span><button onClick={()=>{navigator.serviceWorker.addEventListener('controllerchange',()=>location.reload(),{once:true});worker.postMessage({type:'SKIP_WAITING'});}}><RefreshCw size={15}/>Reload update</button></aside>;
}
