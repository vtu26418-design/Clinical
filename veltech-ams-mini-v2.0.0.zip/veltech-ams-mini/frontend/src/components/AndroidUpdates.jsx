import {useEffect,useState} from 'react';
import {Download,RefreshCw,Smartphone} from 'lucide-react';
import {request} from '../lib/api';
import {androidInstallation,androidReleaseState} from '../lib/app-release';
import {Button,Badge,Feedback} from './UI';
export default function AndroidUpdates(){
 const [release,setRelease]=useState(null),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const launch=(()=>{try{const saved=sessionStorage.getItem('campus:android-launch');if(location.search.includes('androidVersionCode=')){sessionStorage.setItem('campus:android-launch',JSON.stringify({referrer:document.referrer,search:location.search}));return {referrer:document.referrer,search:location.search};}return saved?JSON.parse(saved):{referrer:document.referrer,search:location.search};}catch{return {referrer:document.referrer,search:location.search};}})();
 const installation=androidInstallation({...launch,packageId:release?.packageId});
 async function check(){setBusy(true);setError('');try{setRelease(await request('/app-release'));}catch(e){setError(e.message);}finally{setBusy(false);}}
 useEffect(()=>{check();},[]);
 return <div className="android-updates"><div className="connection-heading"><span className="connection-icon"><Smartphone size={23}/></span><div><h3>Android app</h3><p>{androidReleaseState(release,installation)}</p></div><Badge status={installation.installed?'present':'neutral'}>{installation.installed?'Installed':'Android'}</Badge></div>{release?.available?<><p>Latest release: {release.versionName} · {(release.bytes/1048576).toFixed(1)} MB</p>{release.notes?<p>{release.notes}</p>:null}<div className="app-install-actions"><a className="button primary" href={release.url} download={`veltech-ams-mini-${release.versionName}.apk`}><Download size={16}/>{installation.installed?'Download latest update':'Download Android app'}</a><Button variant="secondary" busy={busy} onClick={check}><RefreshCw size={15}/>Check for updates</Button></div><p className="page-footnote">Open the downloaded APK to install. Android asks for confirmation. Your sign-in stays saved.</p></>:<Button variant="secondary" busy={busy} onClick={check}><RefreshCw size={15}/>Check Android release</Button>}<Feedback error={error}/></div>;
}
