import {Avatar} from './UI';
import {homeFacts} from '../lib/schedule';
export default function StudentBand({profile,onProfile}){
 return <section className="panel premium-student-band"><button className="student-photo-button" onClick={onProfile} aria-label="Open student details"><Avatar name={profile.name} src={profile.photo || profile.image} size="large"/><span>Student details ↗</span></button><dl className="student-ten-facts">{homeFacts(profile).map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value || 'Not provided'}</dd></div>)}</dl></section>;
}
