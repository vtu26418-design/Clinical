import '../event-editor.css';
import {GraduationCap,CalendarDays,ChevronRight} from 'lucide-react';
import {useCampus} from '../context/CampusContext';
import {useLiveResource} from '../hooks/useLiveResource';
import {Button} from './UI';
import {calendarWeekday} from '../lib/academic-calendar';
export default function CampusReminders({navigate}){
 const {data,today,mode}=useCampus(),exams=useLiveResource('/academics/faculty-exams',mode==='connected'),seats=useLiveResource('/academics/exam-seating',mode==='connected'),schedules=useLiveResource('/schedules',mode==='connected');
 const end=new Date(today+'T12:00:00Z');end.setUTCDate(end.getUTCDate()+7);const until=end.toISOString().slice(0,10);
 const rows=(exams.value?.examinations || []).filter(e=>e.date>=today && e.date<=until).toSorted((a,b)=>`${a.date}${a.startTime || ''}`.localeCompare(`${b.date}${b.startTime || ''}`));
 const examsUnique=rows.filter((e,i)=>rows.findIndex(r=>`${r.date}:${r.courseCode}:${r.startTime}`===`${e.date}:${e.courseCode}:${e.startTime}`)===i).slice(0,3);
 const calendar=(data.calendarPolicies || []).filter(p=>p.date>=today && p.date<=until && ['holiday','follow-day','special'].includes(p.mode)).toSorted((a,b)=>a.date.localeCompare(b.date)).slice(0,2);
 const publications=(schedules.value?.schedules || []).filter(s=>s.validTo>=today).toSorted((a,b)=>(a.validFrom<today?today:a.validFrom).localeCompare(b.validFrom<today?today:b.validFrom)).slice(0,2);
 if(!examsUnique.length && !calendar.length && !publications.length)return null;
 return <section className="campus-reminders panel" aria-label="Upcoming academic reminders">{calendar.map(p=><div className="campus-reminder" key={'calendar:'+p.id}><CalendarDays size={23}/><div><small>{p.date===today?'TODAY':'UPCOMING CALENDAR'} · {calendarWeekday(p.date)} · {p.date}</small><strong>{p.label}</strong><span>{p.mode==='holiday'?'Holiday · No classes':p.mode==='follow-day'?`${p.followDay} timetable`:'Special classes'}{p.reason?' · '+p.reason:''}</span></div><Button variant="ghost" onClick={()=>navigate('timetable')}>View<ChevronRight size={16}/></Button></div>)}{examsUnique.map((e,i)=>{const seat=seats.value?.seating?.find(s=>s.exam.id && e.id?s.exam.id===e.id:s.exam.date===e.date && s.exam.courseCode===e.courseCode && s.exam.startTime===e.startTime && s.exam.endTime===e.endTime);return <div className="campus-reminder" key={e.id || i}><GraduationCap size={24}/><div><small>{e.date===today?'TODAY':'UPCOMING EXAM'} · {calendarWeekday(e.date)} · {e.date}</small><strong>{e.title || e.name || e.courseName}</strong><span>{e.courseCode} · {e.startTime || e.time}{seat?` · Room ${seat.ownSeat.room} · Seat ${seat.ownSeat.seat}`:e.room?' · '+e.room:''}</span></div><Button variant="ghost" onClick={()=>navigate('academics','examinations')}>View<ChevronRight size={16}/></Button></div>;})}{publications.map(s=><div className="campus-reminder" key={s.id}><CalendarDays size={23}/><div><small>{s.kind.toUpperCase()} SCHEDULE</small><strong>{s.title}</strong><span>{s.validFrom} – {s.validTo}</span></div><Button variant="ghost" onClick={()=>navigate('schedules')}>View<ChevronRight size={16}/></Button></div>)}</section>;
}
