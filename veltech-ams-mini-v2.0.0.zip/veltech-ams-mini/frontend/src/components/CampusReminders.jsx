import '../event-editor.css';
import {GraduationCap,CalendarDays,ChevronRight} from 'lucide-react';
import {useCampus} from '../context/CampusContext';
import {useLiveResource} from '../hooks/useLiveResource';
import {Button} from './UI';
export default function CampusReminders({navigate}){
 const {data,today,mode}=useCampus(),exams=useLiveResource('/academics/faculty-exams',mode==='connected'),seats=useLiveResource('/academics/exam-seating',mode==='connected'),schedules=useLiveResource('/schedules',mode==='connected');
 const official=data.profile.officialProfile || {},end=new Date(today+'T12:00:00Z');end.setUTCDate(end.getUTCDate()+7);const until=end.toISOString().slice(0,10);
 const rows=[...(data.academic?.examinations || []),...(exams.value?.examinations || [])].filter(e=>e.date>=today && e.date<=until && (!e.section || !official.section || e.section===official.section) && (!e.semester || !official.semester || String(e.semester)===String(official.semester))).toSorted((a,b)=>`${a.date}${a.startTime || ''}`.localeCompare(`${b.date}${b.startTime || ''}`));
 const examsUnique=rows.filter((e,i)=>rows.findIndex(r=>`${r.date}:${r.courseCode}:${r.startTime}`===`${e.date}:${e.courseCode}:${e.startTime}`)===i).slice(0,3);
 const publications=(schedules.value?.schedules || []).slice(0,2);
 if(!examsUnique.length && !publications.length)return null;
 return <section className="campus-reminders panel" aria-label="Upcoming academic reminders">{examsUnique.map((e,i)=>{const seat=seats.value?.seating?.find(s=>s.exam.id===e.id || s.exam.date===e.date && s.exam.courseCode===e.courseCode);return <div className="campus-reminder" key={e.id || i}><GraduationCap size={24}/><div><small>{e.date===today?'TODAY':'UPCOMING EXAM'} · {e.date}</small><strong>{e.title || e.name || e.courseName}</strong><span>{e.courseCode} · {e.startTime || e.time}{seat?` · Room ${seat.ownSeat.room} · Seat ${seat.ownSeat.seat}`:e.room?' · '+e.room:''}</span></div><Button variant="ghost" onClick={()=>navigate('academics','examinations')}>View<ChevronRight size={16}/></Button></div>;})}{publications.map(s=><div className="campus-reminder" key={s.id}><CalendarDays size={23}/><div><small>{s.kind.toUpperCase()} SCHEDULE</small><strong>{s.title}</strong><span>{s.validFrom} – {s.validTo}</span></div><Button variant="ghost" onClick={()=>navigate('schedules')}>View<ChevronRight size={16}/></Button></div>)}</section>;
}
