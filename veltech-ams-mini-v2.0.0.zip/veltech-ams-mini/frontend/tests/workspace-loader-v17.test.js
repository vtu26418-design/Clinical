import test from 'node:test';import assert from 'node:assert/strict';
import {loadWorkspace} from '../src/lib/workspace-loader.js';
test('a slow section does not delay already available academic records',async()=>{
 let release;const slow=new Promise(resolve=>{release=resolve;});const values=[];
 const pending=loadWorkspace(['academic','feed'],p=>p==='academic'?Promise.resolve({source:'ams'}):slow,{isCurrent:()=>true,onValue:(path)=>values.push(path)});
 await new Promise(resolve=>setImmediate(resolve));assert.deepEqual(values,['academic']);release([]);await pending;assert.deepEqual(values,['academic','feed']);
});
test('late section completion and errors do not cross a signed out or switched account',async()=>{
 let release,current=true;const result=new Promise(resolve=>{release=resolve;});const values=[];
 const pending=loadWorkspace(['academic'],()=>result,{isCurrent:()=>current,onValue:p=>values.push(p)});current=false;release({source:'old'});await pending;assert.deepEqual(values,[]);
});
