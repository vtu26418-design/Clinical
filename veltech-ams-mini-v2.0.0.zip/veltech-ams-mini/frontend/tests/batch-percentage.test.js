import test from 'node:test';import assert from 'node:assert/strict';
const rules=await import('../src/lib/batch-percentage.js').catch(()=>null);
const profile={batch:'2023–2027',degree:'B.Tech',department:'Computer Science'};
const policy={batch:'2023-2027',programme:'B.Tech',factor:9,offset:0,regulation:'Fictional test regulation',sourceUrl:'https://www.veltech.edu.in/fixture.pdf',verifiedAt:'2026-10-21'};
test('percentage chooses the exact official batch and programme rather than a social edit or another cohort',()=>{
 assert.equal(typeof rules?.batchPercentage,'function');
 const value=rules.batchPercentage({cgpa:8,percentage:null,percentageSource:'unavailable'},profile,[policy]);assert.equal(value.value,72);assert.equal(value.source,'batch-rule');
 assert.equal(rules.batchPercentage({cgpa:8,percentage:null,percentageSource:'unavailable'},{...profile,batch:'2024-2028'},[policy]).value,75);
 assert.equal(rules.batchPercentage({cgpa:8,percentage:null,percentageSource:'unavailable'},{...profile,degree:'M.Tech'},[policy]).value,75);
});
test('published AMS percentage wins; missing/unverified/ambiguous policy cannot create an official-looking estimate',()=>{
 const published=rules.batchPercentage({cgpa:8,percentage:77,percentageSource:'published'},profile,[policy]);assert.equal(published.value,77);assert.equal(published.source,'published');
 for(const candidates of [[],[{...policy,verifiedAt:null}]]){const value=rules.batchPercentage({cgpa:8,percentage:null,percentageSource:'unavailable'},profile,candidates);assert.equal(value.value,75);assert.equal(value.source,'project-rule');}
 assert.equal(rules.batchPercentage({cgpa:8,percentage:null},profile,[policy,{...policy,factor:10}]).value,null);
});
test('offset formulas and zero are supported with finite valid ranges',()=>{
 assert.equal(rules.batchPercentage({cgpa:8,percentage:null},profile,[{...policy,offset:.5,factor:10}]).value,75);
 assert.equal(rules.batchPercentage({cgpa:0,percentage:null},profile,[{...policy,factor:10}]).value,0);
 assert.equal(rules.batchPercentage({cgpa:8.4,percentage:null},profile,[]).value,79);
 assert.equal(rules.batchPercentage({cgpa:.2,percentage:null},profile,[]).value,null);
 assert.equal(rules.batchPercentage({cgpa:9,percentage:null},profile,[{...policy,factor:50}]).value,null);
});
