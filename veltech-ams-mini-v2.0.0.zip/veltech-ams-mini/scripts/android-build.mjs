import {readFile, writeFile, access, rm, mkdir} from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {
  readConfig, androidRoot, projectDirectory, repositoryRoot, argumentsFor,
  assertPublicDomain, configDigest, BUILD_TOOLS_VERSION, GRADLE_VERSION,
} from './android-config.mjs';
import {deploymentResources} from './android-prepare.mjs';

try {
  const options = argumentsFor(process.argv.slice(2), {'--config': 'value', '--dry-run': 'flag', '--help': 'flag'});
  if (options['--help']) {
    console.log('Usage: node scripts/android-build.mjs [--config path] [--dry-run]\nWindows release build: requires the live HTTPS PWA, deployed Digital Asset Links, Android SDK, a private release key, and the generated project.');
  } else {
    const config = await readConfig(options['--config']);
    const output = path.join(androidRoot, 'out/veltech-ams-mini-release.apk');
    if (options['--dry-run']) {
      console.log(JSON.stringify({status: 'build-plan-only', deploymentUrl: config.deploymentUrl,
        project: projectDirectory, output, tools: {node: '>=22.12.0', java: '17 or 21',
          gradle: GRADLE_VERSION, androidPlatform: 36, buildTools: BUILD_TOOLS_VERSION},
        gates: ['Public HTTPS deployment and PWA assets', 'Generated project matches config',
          'Private release keystore', 'Live Digital Asset Links match the APK signing certificate',
          'Android SDK and successful Gradle build', 'APK signature verification'],
        note: 'No network, signing, SDK installation, or APK creation performed.'}, null, 2));
    } else {
      if (process.platform !== 'win32') throw new Error('The supplied release command targets Windows PowerShell. Follow docs/ANDROID.md on your Windows computer.');
      await assertPublicDomain(config);
      await deploymentResources(config);
      const generated = JSON.parse(await readFile(path.join(projectDirectory, 'velstudents-build.json'), 'utf8'));
      if (generated.configDigest !== configDigest(config)) throw new Error('Android config changed. Run node scripts/android-prepare.mjs before building.');
      const signingKey = path.join(androidRoot, 'private', config.signingKeyFile);
      await access(signingKey);
      const linksResponse = await fetch(`${config.deploymentUrl}/.well-known/assetlinks.json`, {
        redirect: 'error', signal: AbortSignal.timeout(20000),
      });
      if (linksResponse.status !== 200 || !linksResponse.headers.get('content-type')?.includes('application/json')) throw new Error('Deploy /.well-known/assetlinks.json as application/json with HTTP 200 and no redirect or login.');
      const links = await linksResponse.json();
      if (!Array.isArray(links)) throw new Error('Digital Asset Links must be a JSON array.');
      const allowedFingerprints = links.filter(link => link.relation?.includes('delegate_permission/common.handle_all_urls')
        && link.target?.namespace === 'android_app' && link.target?.package_name === config.packageId)
        .flatMap(link => link.target.sha256_cert_fingerprints || [])
        .filter(value => typeof value === 'string' && /^(?:[a-f0-9]{2}:){31}[a-f0-9]{2}$/i.test(value))
        .map(value => value.replaceAll(':', '').toUpperCase());
      if (!allowedFingerprints.length) throw new Error('The deployed Digital Asset Links file has no valid signing certificate for this packageId.');
      const receiptFile = path.join(androidRoot, 'out/signing-receipt.json');
      await mkdir(path.dirname(output), {recursive: true});
      await rm(output, {force: true});
      await rm(receiptFile, {force: true});
      const powershell = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32/WindowsPowerShell/v1.0/powershell.exe');
      const args = ['-NoProfile', '-File', path.join(repositoryRoot, 'scripts/android-build.ps1'),
        '-ProjectDirectory', projectDirectory, '-SigningKeyPath', signingKey,
        '-KeyAlias', config.signingKeyAlias, '-AllowedFingerprintCsv', allowedFingerprints.join(','),
        '-OutputFile', output, '-ReceiptFile', receiptFile];
      const code = await new Promise((resolve, reject) => {
        const child = spawn(powershell, args, {stdio: 'inherit', shell: false});
        child.once('error', reject); child.once('exit', resolve);
      });
      if (code !== 0) throw new Error(`Windows build failed (exit ${code}). Read the preceding build error; no release is confirmed.`);
      const receipt = JSON.parse((await readFile(receiptFile, 'utf8')).replace(/^\uFEFF/, ''));
      if (!allowedFingerprints.includes(receipt.certificateSha256)) throw new Error('The APK signing certificate does not match the deployed Digital Asset Links file.');
      const checksum = createHash('sha256').update(await readFile(output)).digest('hex');
      if (checksum !== receipt.apkSha256) throw new Error('The completed APK checksum does not match the signing receipt.');
      const certificateSha256=receipt.certificateSha256.match(/.{2}/g).join(':');
      await writeFile(receiptFile,JSON.stringify({...receipt,certificateSha256,packageId:config.packageId,versionName:config.versionName,versionCode:config.versionCode},null,2)+'\n');
      console.log(`Verified signed APK: ${output}\nSHA-256: ${checksum}\nTest this release on a real Android phone before sharing it.`);
    }
  }
} catch (error) { console.error(`Android release stopped: ${error.message}`); process.exitCode = 1; }
