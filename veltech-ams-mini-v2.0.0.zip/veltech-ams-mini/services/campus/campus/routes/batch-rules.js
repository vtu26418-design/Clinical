import {BatchRule} from '../models/batch-rule.js';
import {Audit} from '../models.js';
import {campusRole} from '../policy.js';
import {fail,validateId} from '../security.js';
const present=row=>({id:String(row._id),batch:row.batch,programme:row.programme,regulation:row.regulation,factor:row.factor,offset:row.offset,sourceUrl:row.sourceUrl,sourceClause:row.sourceClause,verifiedAt:row.verifiedAt});
const text=(value,max)=>typeof value==='string' && value.trim() && value.length<=max && !/[\u0000-\u001f\u007f]/.test(value)?value.trim():fail(400,'Enter complete batch rule details.');
const admin=user=>{if(campusRole(user)!=='admin')fail(403,'College administrator access is required.');};
export function registerBatchRules(router,config){
 router.get('/academic-rules',config.auth,async(_req,res)=>res.json({rules:(await BatchRule.find({}).sort({batch:-1,programme:1}).limit(1000).lean()).map(present)}));
 router.post('/academic-rules',config.auth,async(req,res)=>{
  admin(req.user);const b=req.body;if(!b || typeof b!=='object' || Array.isArray(b) || Object.keys(b).some(key=>!['batch','programme','regulation','factor','offset','sourceUrl','sourceClause','confirmed'].includes(key)))fail(400,'Use the batch rule fields.');
  const batch=text(b.batch,25).replace(/[–—]/g,'-').replace(/\s/g,''),programme=text(b.programme,100),regulation=text(b.regulation,150),sourceClause=text(b.sourceClause,250),sourceUrl=text(b.sourceUrl,1500);
  const match=batch.match(/^(20\d{2})-(20\d{2})$/);if(!match || +match[2]<=+match[1] || +match[2]-+match[1]>6)fail(400,'Enter the full admission–completion batch, such as 2023-2027.');
  if(typeof b.factor!=='number' || !Number.isFinite(b.factor) || b.factor<=0 || b.factor>100 || typeof b.offset!=='number' || !Number.isFinite(b.offset) || Math.abs(b.offset)>10)fail(400,'Enter a valid multiplier and offset.');
  let url;try{url=new URL(sourceUrl);}catch{fail(400,'Link the official university regulation.');}
  if(url.protocol!=='https:' || !['veltech.edu.in','www.veltech.edu.in','ams.veltech.edu.in'].includes(url.hostname) || url.username || url.password || b.confirmed!==true)fail(400,'Confirm the rule against its official Vel Tech source.');
  const rawProgramme=programme.toLowerCase().replace(/[^a-z]/g,'');const programmeKey=/^(?:btech|bacheloroftechnology)/.test(rawProgramme)?'btech':/^(?:mtech|masteroftechnology)/.test(rawProgramme)?'mtech':rawProgramme;if(!programmeKey)fail(400,'Enter a valid programme.');
  await BatchRule.init();const saved=await BatchRule.findOneAndUpdate({batch,programmeKey},{$set:{programme,regulation,factor:b.factor,offset:b.offset,sourceUrl:url.toString(),sourceClause,verifiedAt:new Date(),verifiedBy:req.user._id}},{upsert:true,returnDocument:'after',runValidators:true});
  await Audit.create({actor:req.user._id,action:'academic-rule.save',target:saved.id,details:`${batch} ${programme}`});res.json(present(saved));
 });
 router.delete('/academic-rules/:id',config.auth,async(req,res)=>{admin(req.user);const row=await BatchRule.findByIdAndDelete(validateId(req.params.id));if(!row)fail(404,'Batch rule not found.');await Audit.create({actor:req.user._id,action:'academic-rule.delete',target:row.id});res.json({deleted:true});});
}
