import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {academicClient} from '../services/academic.js';

test('academic source-login backpressure survives the service boundary',async()=>{
 const server=http.createServer((_req,res)=>{res.writeHead(503,{'Content-Type':'application/json','Retry-After':'3'});res.end(JSON.stringify({detail:'AMS sign-in is busy. Retry shortly.'}));}).listen(0,'127.0.0.1');
 await new Promise(resolve=>server.once('listening',resolve));
 const academic=academicClient(`http://127.0.0.1:${server.address().port}`,'synthetic-service-key');
 try {
  for(const action of [()=>academic.internal('/campus/portal-login/session',{}),()=>academic.request('synthetic-owner-token','/campus/ams/sync','POST',{}),()=>academic.bootstrap({campusId:'owner'})]){
   await assert.rejects(action,error=>error.status===503 && error.retryAfter===3 && error.message==='AMS sign-in is busy. Retry shortly.');
  }
 }finally{await new Promise(resolve=>server.close(resolve));}
});
