import mongoose from 'mongoose';
const {Schema}=mongoose;
const schema=new Schema({batch:{type:String,required:true},programme:{type:String,required:true},programmeKey:{type:String,required:true},regulation:{type:String,required:true},factor:{type:Number,required:true},offset:{type:Number,required:true,default:0},sourceUrl:{type:String,required:true},sourceClause:{type:String,required:true},verifiedAt:{type:Date,required:true},verifiedBy:{type:Schema.Types.ObjectId,ref:'User',required:true}},{timestamps:true});
schema.index({batch:1,programmeKey:1},{unique:true});
export const BatchRule=mongoose.models.CampusBatchRule || mongoose.model('CampusBatchRule',schema);
