import io,unittest,importlib
class SeatingParserTests(unittest.TestCase):
    def parser(self):
        try:module=importlib.import_module('app.services.exam_seating')
        except ModuleNotFoundError:self.fail('A bounded seating parser is required.')
        return module.parse_seating_file
    def test_csv_matches_exact_vtu_ids_and_keeps_room_seat_columns(self):
        result=self.parser()('seating.csv',b'VTU Number,Hall,Room,Seat,Reporting Time\nvtu00000,Main Block,A101,S12,09:00\nVTU00001,Main Block,A102,S13,09:00\n')
        self.assertEqual(result['rows'][0]['vtuNumber'],'VTU00000');self.assertEqual(result['rows'][0]['seat'],'S12');self.assertEqual(result['rows'][1]['room'],'A102')
    def test_duplicate_ids_and_spreadsheet_formula_fields_are_rejected(self):
        parse=self.parser()
        for content in [b'VTU,Room,Seat\nVTU00000,A1,S1\nVTU00000,A2,S2',b'VTU,Room,Seat\nVTU00000,=HYPERLINK("bad"),S1']:
            with self.assertRaises(ValueError):parse('seating.csv',content)
    def test_xlsx_is_read_without_executing_formulas(self):
        from openpyxl import Workbook
        parse=self.parser();book=Workbook();sheet=book.active;sheet.append(['VTU Number','Room','Seat']);sheet.append(['VTU00000','A101','S12']);data=io.BytesIO();book.save(data)
        self.assertEqual(parse('seating.xlsx',data.getvalue())['rows'][0]['room'],'A101')
        sheet['B2']='=1+1';data=io.BytesIO();book.save(data)
        with self.assertRaises(ValueError):parse('seating.xlsx',data.getvalue())
    def test_text_pdf_table_and_scanned_pdf_require_correct_review(self):
        from pypdf import PdfWriter
        from pypdf.generic import DecodedStreamObject,NameObject,DictionaryObject
        parse=self.parser();writer=PdfWriter();page=writer.add_blank_page(width=600,height=800)
        stream=DecodedStreamObject();stream.set_data(b'BT /F1 10 Tf 40 740 Td (VTU Number    Room    Seat) Tj 0 -20 Td (VTU00000      A101    S12) Tj ET')
        font=DictionaryObject({NameObject('/Type'):NameObject('/Font'),NameObject('/Subtype'):NameObject('/Type1'),NameObject('/BaseFont'):NameObject('/Helvetica')})
        page[NameObject('/Resources')]=DictionaryObject({NameObject('/Font'):DictionaryObject({NameObject('/F1'):font})})
        page[NameObject('/Contents')]=stream;data=io.BytesIO();writer.write(data)
        self.assertEqual(parse('seating.pdf',data.getvalue())['rows'][0]['seat'],'S12')
        blank=PdfWriter();blank.add_blank_page(width=600,height=800);data=io.BytesIO();blank.write(data)
        result=parse('scanned.pdf',data.getvalue());self.assertEqual(result['rows'],[]);self.assertTrue(result['warnings'])
    def test_oversized_wrong_format_and_active_pdf_are_rejected(self):
        from pypdf import PdfWriter
        parse=self.parser()
        with self.assertRaises(ValueError):parse('seating.csv',b'x'*(8*1024*1024+1))
        with self.assertRaises(ValueError):parse('seating.xlsx',b'not a spreadsheet')
        writer=PdfWriter();writer.add_blank_page(width=600,height=800);writer.add_js('app.alert("blocked")');data=io.BytesIO();writer.write(data)
        with self.assertRaises(ValueError):parse('seating.pdf',data.getvalue())
