import test from 'node:test';
import assert from 'node:assert/strict';
import {prepareResults,resultSemesters,resultMetrics} from '../src/lib/academic-results.js';
test('final grades and assessment reports remain separate and source semester labels survive',()=>{
 const data=prepareResults([{courseCode:'CS101',semester:'II',grade:'A',resultType:'Regular'},{courseCode:'CS101',semester:'SS2526',testMark1:'20',resultType:'Test marks'}],[],[]);
 assert.equal(data.grades.length,1);assert.equal(data.assessments.length,1);assert.deepEqual(resultSemesters(data.grades),['II']);
});
test('GPA uses explicitly sourced credits and grade definitions, without a built-in university conversion',()=>{
 const grades=[{courseCode:'CS101',semester:'II',grade:'A',resultType:'Regular'},{courseCode:'CS102',semester:'II',grade:'B',resultType:'Regular'}];
 const credits=[{courseCode:'CS101',semester:'II',credits:'4'},{courseCode:'CS102',semester:'II',credits:'2'}];
 const data=prepareResults(grades,credits,[{grade:'A',points:9},{grade:'B',points:8}]);
 assert.equal(resultMetrics(data.grades).value,52/6);assert.equal(resultMetrics(prepareResults(grades,credits,[]).grades).value,null);
});
test('conflicting credit definitions and repeated course attempts cannot fabricate a CGPA',()=>{
 const grades=[{courseCode:'CS101',semester:'II',grade:'A'},{courseCode:'CS101',semester:'II',grade:'B'}];
 const data=prepareResults(grades,[{courseCode:'CS101',credits:'3'},{courseCode:'CS101',credits:'4'}],[{grade:'A',points:9}]);
 assert.equal(resultMetrics(data.grades).complete,false);assert.equal(resultMetrics(data.grades).value,null);
});
