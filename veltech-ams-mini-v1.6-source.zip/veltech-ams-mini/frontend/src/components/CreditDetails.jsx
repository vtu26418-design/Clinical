import {Download} from 'lucide-react';
import {downloadFile,csv} from '../lib/download';
import {Button,EmptyState} from './UI';
const columns={semester:'Semester',category:'Category',courseCode:'Course code',courseName:'Course name',requiredCredits:'Required credits',credits:'Registered credits',earnedCredits:'Credits earned',grade:'Grade',gradePoints:'Grade points',creditPoints:'Credit points',status:'Status'};
export default function CreditDetails({rows=[],summary=[]}){
 const fields=Object.keys(columns).filter(key=>rows.some(row=>row[key]!==undefined));
 function save(){downloadFile('ams-credit-earned-details.csv',csv([[...fields.map(k=>columns[k])],...rows.map(row=>fields.map(k=>row[k])),[],['Summary','Value'],...summary.map(row=>[row.label,row.value])]),'text/csv');}
 return <div>{summary.length?<div className="credits-summary">{summary.map((row,i)=><div key={i}><small>{row.label}</small><strong>{row.value}</strong></div>)}</div>:null}<div className="section-title"><h3>{rows.length} source records</h3><Button variant="secondary" disabled={!rows.length&&!summary.length} onClick={save}><Download size={15}/>Export credit details</Button></div>{rows.length?<div className="table-scroll"><table className="academic-detail-table"><thead><tr>{fields.map(k=><th key={k}>{columns[k]}</th>)}</tr></thead><tbody>{rows.map((row,i)=><tr key={i}>{fields.map(k=><td key={k}>{row[k]??'—'}</td>)}</tr>)}</tbody></table></div>:<EmptyState title="Credit details are not available" description="Sync AMS to read the credit records published for your account."/>}</div>;
}
