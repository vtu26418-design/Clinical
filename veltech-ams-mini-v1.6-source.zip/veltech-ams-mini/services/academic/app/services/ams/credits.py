"""Explicit source credit ledgers, totals and published grade definitions."""
import re
from bs4 import BeautifulSoup
from app.services.ams.labeled_tables import labeled_rows,own_cells,normalized
_MAPPING={'coursecode':'courseCode','subjectcode':'courseCode','coursename':'courseName','subjectname':'courseName','semester':'semester','sem':'semester','credit':'credits','credits':'credits','coursecredits':'credits','registeredcredits':'credits','creditregistered':'credits','creditearned':'earnedCredits','creditsearned':'earnedCredits','earnedcredits':'earnedCredits','creditpoints':'creditPoints','creditpoint':'creditPoints','grade':'grade','gradepoints':'gradePoints','gradepoint':'gradePoints','category':'category','bucket':'category','minimumcredits':'requiredCredits','requiredcredits':'requiredCredits','creditrequired':'requiredCredits','status':'status'}
def parse_grade_scale(html):
 soup=BeautifulSoup(html or '','html.parser');rows=[]
 for node in soup.select('.grade-list,.grade-block,.legend-section'):
  container=node.find_parent(class_='legend-section') or node
  if not re.search(r'grade\s*points?',container.get_text(' ',strip=True),re.I):continue
  for grade,point in re.findall(r'\b([A-Z]{1,3}[+-]?)\s*[:=–-]\s*(\d{1,2}(?:\.\d+)?)(?![\d.]|\s*(?:[%–-]|to\b))\b',node.get_text(' ',strip=True)):
   row={'grade':grade,'points':float(point)}
   if row not in rows:rows.append(row)
 for table in soup.find_all('table'):
  for row,_,_ in labeled_rows(table,{'grade':'grade','gradepoints':'points','gradepoint':'points'},{'grade','points'}):
   if re.fullmatch(r'[A-Z]{1,3}[+-]?',row['grade']) and re.fullmatch(r'\d{1,2}(?:\.\d+)?',row['points']):
    item={'grade':row['grade'],'points':float(row['points'])}
    if item not in rows:rows.append(item)
 return rows[:50]
def parse_credit_details(html):
 soup=BeautifulSoup(html or '','html.parser');rows=[];summary=[]
 for table in soup.find_all('table'):
  for required in ({'courseCode'},{'category','earnedCredits'}):
   for row,_,_ in labeled_rows(table,_MAPPING,required):
    if not any(row.get(field) for field in ('credits','earnedCredits','requiredCredits','creditPoints')):continue
    if row.get('courseCode') and not re.fullmatch(r'[A-Za-z0-9._/-]{2,40}',row['courseCode']):continue
    if row not in rows:rows.append(row)
  for tr in table.find_all('tr'):
   if tr.find_parent('table') is not table:continue
   cells=own_cells(tr)
   if len(cells)!=2:continue
   label,value=(c.get_text(' ',strip=True) for c in cells)
   if normalized(label) in {'cgpa','gpa','sgpa','totalcredits','creditsearned','registeredcredits','requiredcredits','cumulativegradepointaverage'} and re.fullmatch(r'\d+(?:\.\d+)?',value):
    item={'label':label,'value':value}
    if item not in summary:summary.append(item)
 return {'credits':rows[:4000],'creditSummary':summary[:30]}
