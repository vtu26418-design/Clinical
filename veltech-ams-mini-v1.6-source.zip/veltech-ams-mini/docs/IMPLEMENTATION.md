# veltech-ams-mini V1.6 academic update

The combined project uses the original logo, a navy sidebar, blue accents, white content surfaces and phone bottom navigation. React/Vite serves the user interface; the campus Node API enforces community/event permissions and proxies owner-bound requests to the private Python/FastAPI AMS service. MongoDB Atlas remains the default Windows database.

Course metadata and sync telemetry share one owner record. A compatibility reader merges earlier split owner records without crossing student IDs. Results preserve source semester, report type and exam session, separate final grades from internal/assessment rows, and calculate only from explicit course credits and grade points. Credit totals by category are not treated as individual course weights. Unknown source layouts remain unavailable and do not erase prior successful rows.

Official college details remain private and read-only. Social names, departments, bios and links use separate fields and never change authorization. App recovery requires an emailed OTP; a derived college-email display alone does not verify a mailbox. Recovery never changes the university password.

Downloads stores actual app-triggered files in owner-scoped IndexedDB with finite limits and explicit removal. It has no access to another website's files or the system Downloads directory. The old Offline library screen is not mounted. The app shell can announce a waiting service-worker update; private API responses remain excluded from offline caching.

See VERIFICATION.md for current test evidence and the separate earlier live check. The latest credit/document/profile-layout live probe did not complete. Institution-side CAPTCHA, unsupported layouts, missing source records and provider/deployment configuration remain real dependencies. No private capture/debug hook is shipped.
