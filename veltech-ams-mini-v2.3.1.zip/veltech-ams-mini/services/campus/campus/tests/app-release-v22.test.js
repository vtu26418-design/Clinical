import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {createHash} from 'node:crypto';
import {registerAppRelease} from '../routes/app-release.js';
// Exercise the real route without starting a database or authentication system.
test('release endpoint refuses unsigned manifests and unrelated package identities',async()=>{
 const directory=await fs.mkdtemp(path.join(os.tmpdir(),'campus-release-v22-')),routes=new Map();
 registerAppRelease({get:(name,handler)=>routes.set(name,handler)},{directory});
 const data=Buffer.alloc(1200,1),sha256=createHash('sha256').update(data).digest('hex');
 const manifest={versionName:'2.2.0',versionCode:20200,sha256,packageId:'in.velstudents.veltechams',certificateSha256:Array(32).fill('AB').join(':')};
 const get=async()=>{let result;await routes.get('/app-release')({}, {set(){return this;},json(value){result=value;}});return result;};
 try{
  await fs.writeFile(path.join(directory,sha256+'.apk'),data);await fs.writeFile(path.join(directory,'release.json'),JSON.stringify(manifest));
  assert.equal((await get()).available,false,'Unsigned publication receipt must not produce a download');
  manifest.signatureVerified=true;manifest.alignmentVerified=true;await fs.writeFile(path.join(directory,'release.json'),JSON.stringify(manifest));assert.equal((await get()).available,true);
  manifest.packageId='in.unrelated.application';await fs.writeFile(path.join(directory,'release.json'),JSON.stringify(manifest));assert.equal((await get()).available,false);
 }finally{await fs.rm(directory,{recursive:true,force:true});}
});
test('stable domain-only APK link serves the latest local verified release without an external redirect',async()=>{
 const directory=await fs.mkdtemp(path.join(os.tmpdir(),'campus-release-domain-')),routes=new Map();
 registerAppRelease({get:(name,handler)=>routes.set(name,handler)},{directory});
 try{
  const handler=routes.get('/app-release/latest.apk');assert.equal(typeof handler,'function');
  const data=Buffer.alloc(1400,1),sha256=createHash('sha256').update(data).digest('hex');
  const manifest={signatureVerified:true,alignmentVerified:true,versionName:'2.3.0',versionCode:20300,sha256,packageId:'in.velstudents.veltechams',certificateSha256:Array(32).fill('AB').join(':')};
  await fs.writeFile(path.join(directory,sha256+'.apk'),data);await fs.writeFile(path.join(directory,'release.json'),JSON.stringify(manifest));
  let attachment,headers;
  await handler({query:{url:'https://untrusted.example/app.apk'}},{set(value){headers=value;return this;},type(){return this;},download(...args){attachment=args;}});
  assert.equal(attachment[0],path.join(directory,sha256+'.apk'));
  assert.equal(attachment[1],'veltech-ams-mini-2.3.0.apk');
  assert.equal(headers['Cache-Control'],'no-store');assert.equal(headers['X-APK-SHA256'],sha256);
 }finally{await fs.rm(directory,{recursive:true,force:true});}
});
