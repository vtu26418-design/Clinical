# Transparent hybrid artwork

The source mark retains the project cap, curved sides and calendar; its centre incorporates the university shield from the faculty-provided reference emblem. The outer college seal, labels and circle were omitted. Blue/teal/silver 3D art was generated from the two supplied references. `hybrid-3d-master.png` is the transparent master; the public cap/side/centre PNGs are technical alpha-component derivatives for the ordered CSS animation. Original project source remains unchanged at `public/assets/project-original-logo.png`.

University emblem reference provenance: extracted institutional emblem from the faculty-provided report cover. No claim of institutional endorsement is made.
