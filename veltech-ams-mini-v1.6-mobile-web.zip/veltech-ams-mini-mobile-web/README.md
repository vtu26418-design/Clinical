# veltech-ams-mini V1.6 PWA

Built static preview. Serve at an HTTPS origin for phone installation; connected accounts need the combined source backend under the same origin. This is not an APK. Private live access requires the combined backend and your own AMS session. See docs/VERIFICATION.md in the source ZIP for verified and unavailable sections.
